import React, { useState } from 'react';
import { 
  Compass, 
  HelpCircle, 
  Sparkles, 
  Activity, 
  Home, 
  Briefcase, 
  Heart 
} from 'lucide-react';

interface VastuZoneInfo {
  direction: string;
  anatomicalZone: string;
  element: string;
  ruler: string;
  idealFor: string;
  toiletImbalance: string;
  remedy: string;
}

const VASTU_ZONES_DATA: Record<string, VastuZoneInfo> = {
  North: {
    direction: 'North (Uttara) - 0° to 11.25°',
    anatomicalZone: 'Kidneys, Urinary Tract, Circulatory Fluids',
    element: 'Water',
    ruler: 'Mercury (Budh)',
    idealFor: 'Entrance, Treasury, Cash Storage, Fluid medication storage',
    toiletImbalance: 'Severe financial stagnation, kidney stones, fluid retention in the body.',
    remedy: 'Place a brass virtual entry strip under the toilet threshold, add blue glass bottles.'
  },
  'North-East': {
    direction: 'North-East (Ishanya) - 22.5° to 45°',
    anatomicalZone: 'Brain, Nervous System, Pineal Gland, Cognitive clarity',
    element: 'Water / Ether',
    ruler: 'Jupiter (Guru)',
    idealFor: 'Meditation, Prayer, Study room, Ayurvedic medicine preparation',
    toiletImbalance: 'Severe cognitive decline, migraines, chronic depression, paralysis.',
    remedy: 'A toilet here must be physically shut down or treated with extreme copper spiral rods. Strictly keep this zone empty and immaculate.'
  },
  East: {
    direction: 'East (Purva) - 90°',
    anatomicalZone: 'Liver, Eyes, Gallbladder, General vitality',
    element: 'Air / Wood',
    ruler: 'Sun (Surya)',
    idealFor: 'Socializing, living room, windows to capture therapeutic morning rays',
    toiletImbalance: 'Social isolation, liver sluggishness, persistent vitamin D deficiency.',
    remedy: 'Drill copper wire around the toilet floor boundary. Place a green plant on the toilet top.'
  },
  'South-East': {
    direction: 'South-East (Agneya) - 135°',
    anatomicalZone: 'Pelvic organs, Reproductive health, Hormonal balance, Blood pressure',
    element: 'Fire',
    ruler: 'Venus (Shukra)',
    idealFor: 'Kitchen, Electrical meters, Boiler systems',
    toiletImbalance: 'Reproductive problems, blood disorders, high emotional friction, loss of liquid cash.',
    remedy: 'Insert red jasper stones or install a red LED bulb that remains switched on 24/7.'
  },
  South: {
    direction: 'South (Dakshina) - 180°',
    anatomicalZone: 'Heart, Cardiovascular muscles, Sleep depth',
    element: 'Fire',
    ruler: 'Mars (Mangal)',
    idealFor: 'Master bedroom, sleeping with head pointing South to align body magnetic field',
    toiletImbalance: 'Insomnia, cardiovascular panic, high blood pressure, judicial struggles.',
    remedy: 'Mount a heavy copper sun plaque or paint a warm terracotta border under the toilet door.'
  },
  'South-West': {
    direction: 'South-West (Nairutya) - 225°',
    anatomicalZone: 'Bones, Skeletal structure, Lower digestive tract, Longevity',
    element: 'Earth',
    ruler: 'Rahu',
    idealFor: 'Heaviest structures, master bedroom, ancestors picture placement',
    toiletImbalance: 'Frequent bone fractures, severe IBS/indigestion, relationship breakups, instability.',
    remedy: 'Drill heavy lead wire into the boundary floor. Place yellow marble slabs inside the restroom.'
  },
  West: {
    direction: 'West (Paschima) - 270°',
    anatomicalZone: 'Lungs, Respiratory pathways, Skin integrity',
    element: 'Space / Metal',
    ruler: 'Saturn (Shani)',
    idealFor: 'Dining room, children study area, server closets',
    toiletImbalance: 'Persistent skin asthma, pulmonary congestion, lack of business profits.',
    remedy: 'Install white cement margins around the toilet floor, place a white selenite crystal bowl inside.'
  },
  'North-West': {
    direction: 'North-West (Vayavya) - 315°',
    anatomicalZone: 'Stomach, Thyroid gland, Emotional mental balance',
    element: 'Air',
    ruler: 'Moon (Chandra)',
    idealFor: 'Guest bedroom, raw inventory, grain storage, vehicle parking',
    toiletImbalance: 'Extreme mood swings, thyroid disorders, banking loan defaults, litigation.',
    remedy: 'Install aluminum strips around the threshold. Place a white conch shell in this direction.'
  }
};

export default function VastuTool() {
  const [selectedDirection, setSelectedDirection] = useState<string>('North-East');
  const [houseType, setHouseType] = useState<'home' | 'office' | 'clinic'>('home');

  return (
    <div id="vastu-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 dark:text-white">
      
      {/* Introduction Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <h2 className="font-serif text-3xl md:text-4xl font-extrabold text-emerald-950 dark:text-white">
          Medical Vastu & Directional Compass
        </h2>
        <p className="text-slate-600 dark:text-slate-400">
          Medical Vastu aligns the 16 cardinal compass directions with human anatomical organs. Learn how structural defects generate chronic clinical disorders, and deploy zero-demolition remedies.
        </p>
      </div>

      {/* Grid: Interactive Compass on Left, Anatomical Vastu Details on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        
        {/* Left Column: Visual Compass Selector */}
        <div className="lg:col-span-5 flex flex-col items-center bg-white dark:bg-slate-900 p-8 rounded-2xl shadow-xl border border-emerald-900/10 dark:border-white/5 space-y-6">
          <div className="text-center">
            <h3 className="font-serif text-base font-bold text-emerald-900 dark:text-emerald-400 uppercase tracking-wider">Compass Direction Checker</h3>
            <p className="text-[10px] text-slate-500">Click a cardinal node on the compass to analyze health implications.</p>
          </div>

          {/* Compass Graphic */}
          <div className="relative w-64 h-64 rounded-full border-4 border-emerald-900 dark:border-amber-500 bg-slate-50 dark:bg-slate-950/60 flex items-center justify-center shadow-lg shadow-emerald-900/10">
            {/* Center Pointer Dial */}
            <div className="absolute w-2 h-2 rounded-full bg-amber-500 z-10"></div>
            
            {/* Compass Dial Needle */}
            <div className={`absolute w-1 h-24 bg-red-500 rounded -top-2 origin-bottom transition-all duration-500`} 
                 style={{
                   transform: `rotate(${
                     selectedDirection === 'North' ? 0 :
                     selectedDirection === 'North-East' ? 45 :
                     selectedDirection === 'East' ? 90 :
                     selectedDirection === 'South-East' ? 135 :
                     selectedDirection === 'South' ? 180 :
                     selectedDirection === 'South-West' ? 225 :
                     selectedDirection === 'West' ? 270 : 315
                   }deg)`
                 }}
            ></div>

            {/* Cardinal Markers clickable buttons */}
            <button 
              id="compass-n"
              onClick={() => setSelectedDirection('North')}
              className={`absolute top-2 px-1.5 py-0.5 rounded text-[10px] font-bold ${selectedDirection === 'North' ? 'bg-red-500 text-white' : 'text-slate-600 dark:text-slate-400'}`}
            >
              N
            </button>
            <button 
              id="compass-ne"
              onClick={() => setSelectedDirection('North-East')}
              className={`absolute top-12 right-12 px-1.5 py-0.5 rounded text-[10px] font-bold ${selectedDirection === 'North-East' ? 'bg-amber-500 text-slate-900' : 'text-slate-600 dark:text-slate-400'}`}
            >
              NE
            </button>
            <button 
              id="compass-e"
              onClick={() => setSelectedDirection('East')}
              className={`absolute right-2 px-1.5 py-0.5 rounded text-[10px] font-bold ${selectedDirection === 'East' ? 'bg-red-500 text-white' : 'text-slate-600 dark:text-slate-400'}`}
            >
              E
            </button>
            <button 
              id="compass-se"
              onClick={() => setSelectedDirection('South-East')}
              className={`absolute bottom-12 right-12 px-1.5 py-0.5 rounded text-[10px] font-bold ${selectedDirection === 'South-East' ? 'bg-amber-500 text-slate-900' : 'text-slate-600 dark:text-slate-400'}`}
            >
              SE
            </button>
            <button 
              id="compass-s"
              onClick={() => setSelectedDirection('South')}
              className={`absolute bottom-2 px-1.5 py-0.5 rounded text-[10px] font-bold ${selectedDirection === 'South' ? 'bg-red-500 text-white' : 'text-slate-600 dark:text-slate-400'}`}
            >
              S
            </button>
            <button 
              id="compass-sw"
              onClick={() => setSelectedDirection('South-West')}
              className={`absolute bottom-12 left-12 px-1.5 py-0.5 rounded text-[10px] font-bold ${selectedDirection === 'South-West' ? 'bg-amber-500 text-slate-900' : 'text-slate-600 dark:text-slate-400'}`}
            >
              SW
            </button>
            <button 
              id="compass-w"
              onClick={() => setSelectedDirection('West')}
              className={`absolute left-2 px-1.5 py-0.5 rounded text-[10px] font-bold ${selectedDirection === 'West' ? 'bg-red-500 text-white' : 'text-slate-600 dark:text-slate-400'}`}
            >
              W
            </button>
            <button 
              id="compass-nw"
              onClick={() => setSelectedDirection('North-West')}
              className={`absolute top-12 left-12 px-1.5 py-0.5 rounded text-[10px] font-bold ${selectedDirection === 'North-West' ? 'bg-amber-500 text-slate-900' : 'text-slate-600 dark:text-slate-400'}`}
            >
              NW
            </button>
          </div>

          {/* Quick selection dropdown */}
          <div className="w-full text-xs">
            <label className="block text-slate-500 mb-1 font-semibold uppercase">Or Choose Direction</label>
            <select
              value={selectedDirection}
              onChange={(e) => setSelectedDirection(e.target.value)}
              className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white"
            >
              {Object.keys(VASTU_ZONES_DATA).map((dir) => (
                <option key={dir} value={dir} className="dark:bg-slate-900">{dir}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Right Column: Direction Anatomical Report Card */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-6 md:p-8 rounded-2xl shadow-xl border border-emerald-900/10 dark:border-white/5 space-y-6">
          {VASTU_ZONES_DATA[selectedDirection] && (
            <div className="space-y-6">
              
              <div className="flex justify-between items-start border-b border-slate-100 dark:border-white/10 pb-4">
                <div>
                  <h4 className="font-serif text-lg font-bold text-emerald-900 dark:text-amber-400 flex items-center gap-1.5">
                    <Activity className="w-5 h-5" /> Zone: {selectedDirection}
                  </h4>
                  <p className="text-[11px] text-slate-400 font-mono mt-0.5">{VASTU_ZONES_DATA[selectedDirection].direction}</p>
                </div>
                <span className="text-xs px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded-full border border-emerald-100/30">
                  Element: {VASTU_ZONES_DATA[selectedDirection].element}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm">
                <div className="p-4 bg-emerald-500/5 rounded-xl border border-emerald-500/10 space-y-1">
                  <span className="text-slate-500 dark:text-slate-400 font-bold uppercase text-[10px]">Governed Anatomical Organs</span>
                  <p className="font-semibold text-emerald-850 dark:text-emerald-300">{VASTU_ZONES_DATA[selectedDirection].anatomicalZone}</p>
                </div>
                <div className="p-4 bg-amber-500/5 rounded-xl border border-amber-500/10 space-y-1">
                  <span className="text-slate-500 dark:text-slate-400 font-bold uppercase text-[10px]">Planetary Ruler</span>
                  <p className="font-semibold text-amber-850 dark:text-amber-400">{VASTU_ZONES_DATA[selectedDirection].ruler}</p>
                </div>
              </div>

              <div className="space-y-2 text-xs sm:text-sm">
                <p><strong>Ideal Use-Case:</strong> {VASTU_ZONES_DATA[selectedDirection].idealFor}</p>
                <div className="p-4 bg-red-500/10 rounded-xl border border-red-500/20">
                  <strong className="text-red-700 dark:text-red-400 uppercase text-xs block mb-1">Restroom / Fire Imbalance Impact:</strong>
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed text-xs">{VASTU_ZONES_DATA[selectedDirection].toiletImbalance}</p>
                </div>
                <div className="p-4 bg-emerald-500/10 rounded-xl border border-emerald-500/20">
                  <strong className="text-emerald-950 dark:text-emerald-400 uppercase text-xs block mb-1">Siddha Non-Demolition Remedy:</strong>
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed text-xs">{VASTU_ZONES_DATA[selectedDirection].remedy}</p>
                </div>
              </div>

            </div>
          )}
        </div>
      </div>

      {/* Grid: Structured Vastu Guides (Home, Office, Clinical Practice) */}
      <div className="bg-slate-50 dark:bg-slate-900/40 p-6 md:p-8 rounded-2xl border border-slate-200/50 dark:border-white/5 space-y-6">
        <div className="flex flex-wrap justify-between items-center gap-4">
          <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white flex items-center gap-2">
            <Home className="w-5 h-5 text-amber-500" /> Space Optimization Manuals
          </h3>
          <div className="flex bg-white dark:bg-slate-800 p-1 rounded-lg text-xs font-semibold shadow-inner border border-slate-100">
            {(['home', 'office', 'clinic'] as const).map((type) => (
              <button
                key={type}
                id={`vastu-guide-tab-${type}`}
                onClick={() => setHouseType(type)}
                className={`px-3 py-1.5 rounded-md capitalize transition-all ${
                  houseType === type 
                    ? 'bg-emerald-900 dark:bg-emerald-600 text-white' 
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {type} Vastu
              </button>
            ))}
          </div>
        </div>

        {houseType === 'home' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs sm:text-sm">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-white/5 space-y-2">
              <h4 className="font-bold text-emerald-800 dark:text-emerald-400">Master Bedroom</h4>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-xs">
                Ensure bedroom is in the South-West (Nairutya). This brings deep skeletal relaxation and lowers blood pressure. Avoid bedroom in North-East.
              </p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-white/5 space-y-2">
              <h4 className="font-bold text-emerald-800 dark:text-emerald-400">Kitchen Fire Location</h4>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-xs">
                Fire must occupy the South-East (Agni Kone). This ensures metabolic power, high digestion efficiency, and positive mood cycles in residents.
              </p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-white/5 space-y-2">
              <h4 className="font-bold text-emerald-800 dark:text-emerald-400">Water Tank Location</h4>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-xs">
                Overhead water containers belong in North-West or West coordinates. Placing heavy tanks on North-East generates cerebral stagnation and limits memory.
              </p>
            </div>
          </div>
        )}

        {houseType === 'office' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs sm:text-sm">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-white/5 space-y-2">
              <h4 className="font-bold text-emerald-800 dark:text-emerald-400">CEO Seating Axis</h4>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-xs">
                The manager or chief executive should sit in the South-West zone facing North or East. This expands commercial negotiation capacity.
              </p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-white/5 space-y-2">
              <h4 className="font-bold text-emerald-800 dark:text-emerald-400">Accounts & Ledger Storage</h4>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-xs">
                Ledgers, invoice reports, and financial files must reside in the North sector. Mercury is the lord of North and commercial transactions.
              </p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-white/5 space-y-2">
              <h4 className="font-bold text-emerald-800 dark:text-emerald-400">Server & Electrical Hub</h4>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-xs">
                Server systems, main switches, and Wi-Fi routers must be positioned in the South-East. This keeps technical communication lag-free.
              </p>
            </div>
          </div>
        )}

        {houseType === 'clinic' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs sm:text-sm">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-white/5 space-y-2">
              <h4 className="font-bold text-emerald-800 dark:text-emerald-400">Patient Consulting Area</h4>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-xs">
                Doctor consultation desk belongs in North-East or East. This optimizes diagnostic analysis and allows clinical healing frequencies to manifest.
              </p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-white/5 space-y-2">
              <h4 className="font-bold text-emerald-800 dark:text-emerald-400">Medicine Dispersary</h4>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-xs">
                Store pharmaceutical drugs and health herbs in the North-North-East (NNE) zone. Governed by Dhanvantari, this boosts drug efficacy.
              </p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-white/5 space-y-2">
              <h4 className="font-bold text-emerald-800 dark:text-emerald-400">Therapy / Rejuvenation Beds</h4>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-xs">
                Rejuvenation massage chairs and inpatient beds must point with their head-ends South. Aligns patient cardiac field with Earth flows.
              </p>
            </div>
          </div>
        )}
      </div>

    </div>
  );
}
