import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import AstrologyTool from './components/AstrologyTool';
import NumerologyTool from './components/NumerologyTool';
import VastuTool from './components/VastuTool';
import MentalHealthScreener from './components/MentalHealthScreener';
import CoursePortal from './components/CoursePortal';
import ProductShop from './components/ProductShop';
import DoctorConsultation from './components/DoctorConsultation';
import BlogSection from './components/BlogSection';
import AiMentorBot from './components/AiMentorBot';
import CookieConsent from './components/CookieConsent';
import UserProfileView from './components/UserProfileView';
import AdminDashboard from './components/AdminDashboard';
import { CartItem } from './types';
import { Mail, Phone, MapPin } from 'lucide-react';

export default function App() {
  const [currentTab, setTab] = useState<string>('home');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [darkMode, setDarkMode] = useState<boolean>(false);

  // Sync dark mode class with root document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const handleOpenCart = () => {
    setTab('shop');
  };

  // Quick total cart items count
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-[#050B18] text-white font-sans overflow-hidden relative selection:bg-gold/30 selection:text-gold transition-colors duration-300">
      
      {/* Mesh Gradient Background Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] rounded-full frosted-glow-emerald opacity-50 blur-[120px] pointer-events-none z-0"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[45vw] h-[45vw] rounded-full frosted-glow-gold opacity-20 blur-[100px] pointer-events-none z-0"></div>
      
      {/* Relative wrapper to sit above background effects */}
      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Dynamic Header Navbar */}
        <Navbar 
          currentTab={currentTab} 
          setTab={setTab} 
          cartCount={cartCount} 
          openCart={handleOpenCart} 
          darkMode={darkMode} 
          toggleDarkMode={toggleDarkMode} 
        />

        {/* Main Layout Workspace Content */}
        <main className="flex-grow relative z-10">
          {currentTab === 'home' && <HeroSection setTab={setTab} />}
          {currentTab === 'astrology' && <AstrologyTool />}
          {currentTab === 'numerology' && <NumerologyTool />}
          {currentTab === 'vastu' && <VastuTool />}
          {currentTab === 'mental-health' && <MentalHealthScreener />}
          {currentTab === 'courses' && <CoursePortal />}
          {currentTab === 'shop' && <ProductShop cart={cart} setCart={setCart} />}
          {currentTab === 'consultation' && <DoctorConsultation />}
          {currentTab === 'blog' && <BlogSection />}
          {currentTab === 'profile' && <UserProfileView />}
          {currentTab === 'admin' && <AdminDashboard />}
        </main>

        {/* Persistent AI Assistant Bot in bottom-right corner */}
        <AiMentorBot />

        {/* Persistent Glass-morphism Cookie Consent Banner */}
        <CookieConsent />

        {/* Cohesive, Premium Footer */}
        <footer className="relative z-10 bg-[#050B18]/65 backdrop-blur-md text-white border-t border-white/10 pt-16 pb-8 text-xs sm:text-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
            
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg gold-gradient p-[1px] flex items-center justify-center">
                  <div className="w-full h-full bg-[#050B18] rounded-[7px] flex items-center justify-center text-gold font-bold font-serif text-sm">
                    HM
                  </div>
                </div>
                <h2 className="font-serif text-base font-bold tracking-wider text-gold">HRCM MENTOR</h2>
              </div>
              <p className="text-slate-400 leading-relaxed text-xs">
                Integrating cosmic architecture, planetary alignment, bio-electrical shielding, and modern psychiatric counseling into a single clinical practice.
              </p>
            </div>

            <div className="space-y-4">
              <h4 className="font-serif text-gold font-bold tracking-wider uppercase text-xs">Clinical Centers</h4>
              <ul className="space-y-2 text-slate-400 text-xs">
                <li>• Astro-Numerology Lab</li>
                <li>• Medical Vastu Research Div</li>
                <li>• Panchang Astronomical Corp</li>
                <li>• Siddha Wellness Registry</li>
              </ul>
            </div>

            <div className="space-y-4">
              <h4 className="font-serif text-gold font-bold tracking-wider uppercase text-xs">Legal & Medical</h4>
              <p className="text-slate-400 leading-relaxed text-[11px]">
                All diagnostic and remediative methods are non-demolition, bio-magnetically grounded, and compliant with educational standards. Not a replacement for emergency healthcare.
              </p>
            </div>

            <div className="space-y-4">
              <h4 className="font-serif text-gold font-bold tracking-wider uppercase text-xs">Contact Founder</h4>
              <div className="space-y-2 text-slate-400 text-xs">
                <p className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-gold" /> Ghaziabad, Uttar Pradesh, India
                </p>
                <p className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-gold" /> +91 7906596613
                </p>
                <p className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-gold" /> choudharynabink@gmail.com
                </p>
              </div>
            </div>

          </div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-white/5 mt-12 pt-6 text-center text-[11px] text-slate-500">
            <p>© {new Date().getFullYear()} HRCM MENTOR. All Rights Reserved. Calibrated by Nabin K. Choudhary.</p>
          </div>
        </footer>
      </div>
    </div>
  );
}
