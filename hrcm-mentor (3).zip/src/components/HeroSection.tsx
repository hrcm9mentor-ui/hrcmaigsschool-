import React from 'react';
import { 
  Sparkles, 
  UserCheck, 
  ChevronRight, 
  Calendar, 
  Compass, 
  FileCheck, 
  Activity, 
  ShieldAlert,
  ArrowUpRight,
  Heart
} from 'lucide-react';
import { FOUNDER_INFO, DAILY_PANCHANG } from '../data';

interface HeroSectionProps {
  setTab: (tab: string) => void;
}

export default function HeroSection({ setTab }: HeroSectionProps) {
  return (
    <div id="hero-container" className="relative overflow-hidden bg-transparent">
      
      {/* Background design accents */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl -z-10"></div>

      {/* Main Hero Stage */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-20 md:py-28">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Narrative Column */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/5 text-emerald-400 text-xs font-semibold uppercase tracking-widest border border-white/10">
              <Sparkles className="w-3.5 h-3.5 text-gold animate-spin" />
              <span>World-Class Medical + Spiritual Wisdom</span>
            </div>

            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white leading-tight">
              Integrating Ancient <span className="text-gold">Cosmic Laws</span> with Modern <span className="text-emerald-400">Clinical Science</span>
            </h1>

            <p className="text-base sm:text-lg text-gray-300 max-w-xl leading-relaxed">
              HRCM MENTOR, founded by master scientist-astrologer <strong>{FOUNDER_INFO.name}</strong>, delivers certified Chaldean Numerology, medical-direction Vastu corrections, planetary energetic analysis, and clinically grounded mental wellness solutions.
            </p>

            {/* CTA Bento buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-4 max-w-lg">
              <button
                id="hero-cta-consultation"
                onClick={() => setTab('consultation')}
                className="group flex items-center justify-between px-5 py-4 bg-emerald-dark hover:bg-emerald-600 text-white rounded-xl font-bold text-sm tracking-wide shadow-xl shadow-emerald-950/40 hover:scale-105 transition-all cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-gold" />
                  Book Clinical Consultation
                </span>
                <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </button>

              <button
                id="hero-cta-courses"
                onClick={() => setTab('courses')}
                className="group flex items-center justify-between px-5 py-4 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-200 hover:text-white rounded-xl font-bold text-sm transition-all cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-gold" />
                  Join Master Courses
                </span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                id="hero-cta-shop"
                onClick={() => setTab('shop')}
                className="group flex items-center justify-between px-5 py-4 bg-gold hover:bg-amber-400 text-[#050B18] rounded-xl font-bold text-sm shadow-lg shadow-amber-500/10 hover:scale-105 transition-all cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <Activity className="w-4 h-4" />
                  Shop Certified Rudraksha
                </span>
                <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </button>

              <button
                id="hero-cta-panchang"
                onClick={() => setTab('astrology')}
                className="group flex items-center justify-between px-5 py-4 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-200 hover:text-white rounded-xl font-bold text-sm transition-all cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <Compass className="w-4 h-4 text-emerald-400" />
                  Daily Panchang & Muhurat
                </span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            <div className="pt-2">
              <button
                id="hero-cta-mental-test"
                onClick={() => setTab('mental-health')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-red-500/10 text-red-300 hover:bg-red-500/20 rounded-xl font-bold text-sm transition-all border border-red-500/20 cursor-pointer"
              >
                <Heart className="w-4 h-4 fill-red-500 text-red-500 animate-pulse" />
                Free Diagnostic Mental Health Screening (PHQ-9 & GAD-7)
              </button>
            </div>
          </div>

          {/* Right Visual / Panchang Snapshot Bento Card */}
          <div className="lg:col-span-5">
            <div className="relative frosted-card rounded-3xl p-6 md:p-8 space-y-6">
              
              {/* Top Founder Seal */}
              <div className="flex items-center gap-4 pb-4 border-b border-white/10">
                <div className="w-14 h-14 rounded-full bg-white/5 flex items-center justify-center font-serif text-white font-bold border-2 border-gold overflow-hidden shadow-inner">
                  <span className="text-xl">NK</span>
                </div>
                <div>
                  <h4 className="font-serif font-bold text-white leading-tight">
                    {FOUNDER_INFO.name}
                  </h4>
                  <p className="text-xs text-gray-400">
                    Scientific Astrologer & Medical Vastu Acharya
                  </p>
                  <p className="text-[10px] font-mono text-gold font-bold uppercase mt-0.5">
                    Ghaziabad, Uttar Pradesh, India
                  </p>
                </div>
              </div>

              {/* Fast-loading Daily Panchang Dashboard Snapshot */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-serif text-sm font-bold uppercase tracking-wider text-gold flex items-center gap-1.5">
                    <Compass className="w-4 h-4 text-gold" />
                    Panchang • {DAILY_PANCHANG.date}
                  </h3>
                  <span className="text-[10px] font-mono bg-emerald-dark/40 border border-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full">
                    Auspicious Alignment
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/5 text-xs">
                    <p className="text-gray-400 text-[10px]">Tithi</p>
                    <p className="font-semibold text-white mt-0.5">{DAILY_PANCHANG.tithi}</p>
                  </div>
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/5 text-xs">
                    <p className="text-gray-400 text-[10px]">Nakshatra</p>
                    <p className="font-semibold text-white mt-0.5">{DAILY_PANCHANG.nakshatra}</p>
                  </div>
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/5 text-xs">
                    <p className="text-gray-400 text-[10px]">Abhijit Muhurat</p>
                    <p className="font-semibold text-emerald-300 font-mono mt-0.5">{DAILY_PANCHANG.abhijit}</p>
                  </div>
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/5 text-xs">
                    <p className="text-gray-400 text-[10px]">Rahu Kaal (Avoid)</p>
                    <p className="font-semibold text-red-400 font-mono mt-0.5">{DAILY_PANCHANG.rahukaal}</p>
                  </div>
                </div>

                {/* Micro-Astrology Quick Alert */}
                <div className="bg-gold/10 p-4 rounded-2xl border border-gold/20 text-xs text-gold space-y-1.5">
                  <div className="flex items-center gap-1.5 font-bold">
                    <ShieldAlert className="w-4 h-4 text-gold" />
                    <span>Clinical + Spiritual Note:</span>
                  </div>
                  <p className="leading-relaxed text-slate-300">
                    Vedic scriptures show planetary transits influence cell polarization. Aligning sleeping axes & wearing pure 5-Mukhi Rudraksha shields cardiac pathways.
                  </p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

    </div>
  );
}
