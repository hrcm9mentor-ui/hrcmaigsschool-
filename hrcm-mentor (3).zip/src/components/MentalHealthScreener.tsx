import React, { useState } from 'react';
import { 
  HeartHandshake, 
  ShieldAlert, 
  Smile, 
  Activity, 
  Frown, 
  AlertCircle, 
  Plus, 
  Trash2,
  BookmarkCheck,
  Volume2
} from 'lucide-react';

// PHQ-9 Questions
const PHQ9_QUESTIONS = [
  "Little interest or pleasure in doing things?",
  "Feeling down, depressed, or hopeless?",
  "Trouble falling or staying asleep, or sleeping too much?",
  "Feeling tired or having little energy?",
  "Poor appetite or overeating?",
  "Feeling bad about yourself — or that you are a failure or have let yourself or your family down?",
  "Trouble concentrating on things, such as reading the newspaper or watching television?",
  "Moving or speaking so slowly that other people could have noticed? Or the opposite — being so fidgety or restless that you have been moving around a lot more than usual?",
  "Thoughts that you would be better off dead, or of hurting yourself in some way?"
];

// GAD-7 Questions
const GAD7_QUESTIONS = [
  "Feeling nervous, anxious, or on edge?",
  "Not being able to stop or control worrying?",
  "Worrying too much about different things?",
  "Trouble relaxing?",
  "Being so restless that it is hard to sit still?",
  "Becoming easily annoyed or irritable?",
  "Feeling afraid, as if something awful might happen?"
];

const SCORING_OPTIONS = [
  { label: "Not at all", value: 0 },
  { label: "Several days", value: 1 },
  { label: "More than half the days", value: 2 },
  { label: "Nearly every day", value: 3 }
];

interface MoodLog {
  id: string;
  mood: string;
  note: string;
  score: number;
  date: string;
}

export default function MentalHealthScreener() {
  const [activeCalculator, setActiveCalculator] = useState<'phq9' | 'gad7' | 'mood'>('phq9');

  // PHQ9 States
  const [phq9Answers, setPhq9Answers] = useState<number[]>(new Array(9).fill(0));
  const [phq9Completed, setPhq9Completed] = useState(false);

  // GAD7 States
  const [gad7Answers, setGad7Answers] = useState<number[]>(new Array(7).fill(0));
  const [gad7Completed, setGad7Completed] = useState(false);

  // Mood Tracker States
  const [moodLogs, setMoodLogs] = useState<MoodLog[]>([
    { id: '1', mood: 'Peaceful', note: 'Feeling balanced after morning South-East fire kitchen alignment.', score: 8, date: 'July 20, 2026' },
    { id: '2', mood: 'Sluggish', note: 'Woke up with minor brain fog. Adjusted my bed direction to point South.', score: 4, date: 'July 19, 2026' }
  ]);
  const [newMood, setNewMood] = useState('Peaceful');
  const [moodNote, setMoodNote] = useState('');
  const [moodEnergy, setMoodEnergy] = useState<number>(7);

  // PHQ-9 scoring
  const phq9Total = phq9Answers.reduce((sum, val) => sum + val, 0);
  const getPhq9Range = (score: number) => {
    if (score <= 4) return { label: "Minimal Depression", color: "text-emerald-700 bg-emerald-50 dark:bg-emerald-950", advice: "Your scores indicate standard emotional stability. Continue daily mindful pranayama." };
    if (score <= 9) return { label: "Mild Depression", color: "text-amber-700 bg-amber-50 dark:bg-amber-950", advice: "Minor mood sluggishness indicated. Focus on clearing North-East home coordinates." };
    if (score <= 14) return { label: "Moderate Depression", color: "text-orange-700 bg-orange-50 dark:bg-orange-950", advice: "Moderate fatigue is present. Consider enrolling in our Mental Health awareness course." };
    if (score <= 19) return { label: "Moderately Severe", color: "text-red-700 bg-red-50 dark:bg-red-950", advice: "Highly advised to schedule a consulting session with our mental health counselling experts." };
    return { label: "Severe Depression", color: "text-red-800 bg-red-100 dark:bg-red-950", advice: "Immediate professional intervention is strongly advised. Read our crisis contact panel below." };
  };

  // GAD-7 scoring
  const gad7Total = gad7Answers.reduce((sum, val) => sum + val, 0);
  const getGad7Range = (score: number) => {
    if (score <= 4) return { label: "Minimal Anxiety", color: "text-emerald-700 bg-emerald-50 dark:bg-emerald-950", advice: "Your nervous responses are within standard guidelines." };
    if (score <= 9) return { label: "Mild Anxiety", color: "text-amber-700 bg-amber-50 dark:bg-amber-950", advice: "Incorporate deep breathing techniques, inhale twice followed by a slow prolonged exhale." };
    if (score <= 14) return { label: "Moderate Anxiety", color: "text-orange-700 bg-orange-50 dark:bg-orange-950", advice: "Wear a certified 5 Mukhi Nepal Rudraksha to lower sympathetic reactivity." };
    return { label: "Severe Anxiety", color: "text-red-700 bg-red-50 dark:bg-red-950", advice: "Consult our clinical doctors or counselling partners to establish a recovery path." };
  };

  const handleLogMood = (e: React.FormEvent) => {
    e.preventDefault();
    if (!moodNote) return;
    const log: MoodLog = {
      id: Math.random().toString(36).substring(2, 10),
      mood: newMood,
      note: moodNote,
      score: moodEnergy,
      date: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
    };
    setMoodLogs([log, ...moodLogs]);
    setMoodNote('');
  };

  const handleDeleteMood = (id: string) => {
    setMoodLogs(moodLogs.filter(log => log.id !== id));
  };

  return (
    <div id="mental-health-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 dark:text-white">
      
      {/* Introduction Header & Disclaimer */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <h2 className="font-serif text-3xl md:text-4xl font-extrabold text-emerald-950 dark:text-white">
          Clinical Mental Health & Coping Center
        </h2>
        <p className="text-slate-600 dark:text-slate-400">
          Our validated clinical screening calculators evaluate depression and anxiety indicators according to international medical standards.
        </p>

        {/* Mandatory Clinical Disclaimer */}
        <div id="clinical-disclaimer" className="p-4 bg-amber-500/10 text-amber-800 dark:text-amber-400 rounded-2xl border border-amber-500/30 text-xs text-left max-w-2xl mx-auto flex gap-3">
          <ShieldAlert className="w-6 h-6 flex-shrink-0 text-amber-500 animate-pulse" />
          <p className="leading-relaxed">
            <strong>Mandatory Medical Disclaimer:</strong> These tools are educational screening tools only and do not replace professional medical diagnosis, clinical psychiatric evaluation, or treatment. If you are experiencing distress, consult a medical doctor immediately.
          </p>
        </div>
      </div>

      {/* Selector tabs */}
      <div className="flex justify-center bg-slate-100 dark:bg-slate-900 p-1 rounded-lg text-xs sm:text-sm font-semibold max-w-md mx-auto">
        <button
          id="btn-tab-phq9"
          onClick={() => setActiveCalculator('phq9')}
          className={`flex-1 py-2 rounded-md transition-all ${activeCalculator === 'phq9' ? 'bg-emerald-900 dark:bg-emerald-600 text-white shadow' : 'text-slate-600 dark:text-slate-400 hover:text-slate-950'}`}
        >
          Depression (PHQ-9)
        </button>
        <button
          id="btn-tab-gad7"
          onClick={() => setActiveCalculator('gad7')}
          className={`flex-1 py-2 rounded-md transition-all ${activeCalculator === 'gad7' ? 'bg-emerald-900 dark:bg-emerald-600 text-white shadow' : 'text-slate-600 dark:text-slate-400 hover:text-slate-950'}`}
        >
          Anxiety (GAD-7)
        </button>
        <button
          id="btn-tab-mood"
          onClick={() => setActiveCalculator('mood')}
          className={`flex-1 py-2 rounded-md transition-all ${activeCalculator === 'mood' ? 'bg-emerald-900 dark:bg-emerald-600 text-white shadow' : 'text-slate-600 dark:text-slate-400 hover:text-slate-950'}`}
        >
          Daily Mood Tracker
        </button>
      </div>

      {/* Primary Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Interactive Screeners */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-6 md:p-8 rounded-2xl shadow-xl border border-emerald-900/10 dark:border-white/5">
          
          {activeCalculator === 'phq9' && (
            <div className="space-y-6">
              <div className="border-b border-slate-100 dark:border-white/10 pb-4">
                <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white">PHQ-9 (Patient Health Questionnaire)</h3>
                <p className="text-xs text-slate-500">Over the last 2 weeks, how often have you been bothered by any of the following problems?</p>
              </div>

              {!phq9Completed ? (
                <div className="space-y-6">
                  {PHQ9_QUESTIONS.map((question, qIdx) => (
                    <div key={qIdx} className="space-y-2">
                      <p className="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-200">{qIdx + 1}. {question}</p>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {SCORING_OPTIONS.map((opt) => (
                          <button
                            key={opt.value}
                            type="button"
                            id={`phq9-q-${qIdx}-opt-${opt.value}`}
                            onClick={() => {
                              const updated = [...phq9Answers];
                              updated[qIdx] = opt.value;
                              setPhq9Answers(updated);
                            }}
                            className={`p-2 rounded-xl text-center border text-xs font-medium transition-all ${
                              phq9Answers[qIdx] === opt.value
                                ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-300 font-bold'
                                : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                            }`}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}

                  <button
                    id="submit-phq9"
                    onClick={() => setPhq9Completed(true)}
                    className="w-full py-3 gold-gradient text-white rounded-lg font-bold text-sm uppercase tracking-wider"
                  >
                    Calculate Depression Score
                  </button>
                </div>
              ) : (
                <div className="space-y-6 text-center py-6">
                  <div className="inline-flex flex-col items-center justify-center w-24 h-24 rounded-full border-4 border-emerald-500 bg-emerald-50 dark:bg-emerald-950">
                    <span className="text-[10px] text-slate-500 uppercase font-bold">Score</span>
                    <span className="text-3xl font-bold text-emerald-900 dark:text-emerald-400">{phq9Total}</span>
                  </div>

                  <div className={`p-4 rounded-xl font-semibold border ${getPhq9Range(phq9Total).color}`}>
                    <p className="text-sm">Severity Profile: <strong>{getPhq9Range(phq9Total).label}</strong></p>
                    <p className="text-xs mt-1 leading-relaxed font-normal">{getPhq9Range(phq9Total).advice}</p>
                  </div>

                  <div className="flex gap-2">
                    <button
                      id="reset-phq9"
                      onClick={() => { setPhq9Answers(new Array(9).fill(0)); setPhq9Completed(false); }}
                      className="flex-1 py-2.5 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-bold"
                    >
                      Retake Screener
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeCalculator === 'gad7' && (
            <div className="space-y-6">
              <div className="border-b border-slate-100 dark:border-white/10 pb-4">
                <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white">GAD-7 (Generalized Anxiety Screener)</h3>
                <p className="text-xs text-slate-500">Over the last 2 weeks, how often have you been bothered by any of the following problems?</p>
              </div>

              {!gad7Completed ? (
                <div className="space-y-6">
                  {GAD7_QUESTIONS.map((question, qIdx) => (
                    <div key={qIdx} className="space-y-2">
                      <p className="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-200">{qIdx + 1}. {question}</p>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {SCORING_OPTIONS.map((opt) => (
                          <button
                            key={opt.value}
                            type="button"
                            id={`gad7-q-${qIdx}-opt-${opt.value}`}
                            onClick={() => {
                              const updated = [...gad7Answers];
                              updated[qIdx] = opt.value;
                              setGad7Answers(updated);
                            }}
                            className={`p-2 rounded-xl text-center border text-xs font-medium transition-all ${
                              gad7Answers[qIdx] === opt.value
                                ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-300 font-bold'
                                : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                            }`}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}

                  <button
                    id="submit-gad7"
                    onClick={() => setGad7Completed(true)}
                    className="w-full py-3 gold-gradient text-white rounded-lg font-bold text-sm uppercase tracking-wider"
                  >
                    Calculate Anxiety Score
                  </button>
                </div>
              ) : (
                <div className="space-y-6 text-center py-6">
                  <div className="inline-flex flex-col items-center justify-center w-24 h-24 rounded-full border-4 border-emerald-500 bg-emerald-50 dark:bg-emerald-950">
                    <span className="text-[10px] text-slate-500 uppercase font-bold">Score</span>
                    <span className="text-3xl font-bold text-emerald-900 dark:text-emerald-400">{gad7Total}</span>
                  </div>

                  <div className={`p-4 rounded-xl font-semibold border ${getGad7Range(gad7Total).color}`}>
                    <p className="text-sm">Severity Profile: <strong>{getGad7Range(gad7Total).label}</strong></p>
                    <p className="text-xs mt-1 leading-relaxed font-normal">{getGad7Range(gad7Total).advice}</p>
                  </div>

                  <div className="flex gap-2">
                    <button
                      id="reset-gad7"
                      onClick={() => { setGad7Answers(new Array(7).fill(0)); setGad7Completed(false); }}
                      className="flex-1 py-2.5 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-bold"
                    >
                      Retake Screener
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeCalculator === 'mood' && (
            <div className="space-y-6">
              <div className="border-b border-slate-100 dark:border-white/10 pb-4">
                <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white">Daily Mood & Energy Log</h3>
                <p className="text-xs text-slate-500">Track and correlate your daily emotional waves with your sleeping direction and physical symptoms.</p>
              </div>

              <form onSubmit={handleLogMood} className="space-y-4 text-xs sm:text-sm">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Current Mood state</label>
                    <select
                      value={newMood}
                      onChange={(e) => setNewMood(e.target.value)}
                      className="w-full p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white"
                    >
                      <option value="Happy" className="dark:bg-slate-900">🌸 Happy & Vital</option>
                      <option value="Peaceful" className="dark:bg-slate-900">🍃 Calm & Grounded</option>
                      <option value="Anxious" className="dark:bg-slate-900">⚡ Anxious & Scattered</option>
                      <option value="Sluggish" className="dark:bg-slate-900">💤 Sluggish & Heavy</option>
                      <option value="Focused" className="dark:bg-slate-900">💎 Focused & Clear</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Vitality Score (1-10)</label>
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={moodEnergy}
                      onChange={(e) => setMoodEnergy(parseInt(e.target.value))}
                      className="w-full h-2 rounded-lg appearance-none cursor-pointer bg-slate-200 dark:bg-slate-700 accent-emerald-600 mt-3"
                    />
                    <span className="text-xs text-slate-500 font-mono block text-right mt-1">Level: {moodEnergy}/10</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Observation Notes (Remedies / Sleep Direction)</label>
                  <textarea
                    required
                    value={moodNote}
                    onChange={(e) => setMoodNote(e.target.value)}
                    placeholder="e.g. Woke up refreshed, head was facing South. Noticed lowered mental noise today."
                    rows={3}
                    className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  id="log-mood-btn"
                  className="w-full py-2 bg-emerald-900 dark:bg-emerald-600 hover:bg-emerald-800 text-white font-bold rounded-lg text-xs uppercase"
                >
                  Save Daily Log
                </button>
              </form>

              {/* Saved Mood Logs List */}
              <div className="space-y-3 pt-4">
                <h4 className="font-serif text-sm font-bold uppercase tracking-wider text-slate-500">Log History</h4>
                <div className="space-y-3">
                  {moodLogs.map((log) => (
                    <div key={log.id} className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-white/5 flex justify-between gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-emerald-800 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950 px-2.5 py-0.5 rounded-full">{log.mood}</span>
                          <span className="text-[10px] text-slate-400 font-mono">{log.date}</span>
                        </div>
                        <p className="text-xs text-slate-700 dark:text-slate-300 italic">"{log.note}"</p>
                        <p className="text-[10px] text-slate-500">Vitality index: {log.score}/10</p>
                      </div>
                      <button
                        onClick={() => handleDeleteMood(log.id)}
                        className="text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20 p-2 rounded-full self-center"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

        </div>

        {/* Right Column: Emergency Help & Wellness Tips */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Mental Wellness Tips */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-xl border border-emerald-900/10 dark:border-white/5 space-y-4">
            <h3 className="font-serif text-base font-bold text-emerald-950 dark:text-white flex items-center gap-1.5">
              <BookmarkCheck className="w-5 h-5 text-emerald-600" /> Mental Wellness Guidelines
            </h3>
            <ul className="text-xs space-y-3 text-slate-600 dark:text-slate-300 leading-relaxed">
              <li className="flex items-start gap-2">
                <span className="text-amber-500 font-bold">•</span>
                <span><strong>South Sleep Rule</strong>: Never sleep with your head facing North. Sleeping with head South aligns the biological cells with Earth's magnetosphere, lowering blood pressure and panic states.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-500 font-bold">•</span>
                <span><strong>Vagal Diaphragmatic Breath</strong>: Double inhale rapidly through your nose, and slowly exhale completely through pursed lips. This triggers instant vagus nerve activation, slowing racing heartbeats.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-500 font-bold">•</span>
                <span><strong>North-East Clearance</strong>: Keep the North-East Ishanya zone of your bedroom completely empty. Decluttering this coordinate releases mental blockage and cognitive fatigue.</span>
              </li>
            </ul>
          </div>

          {/* Emergency Crisis Contact Numbers */}
          <div className="bg-red-500/10 rounded-2xl p-6 border border-red-500/20 space-y-4 text-xs">
            <div className="flex items-center gap-2 text-red-700 dark:text-red-400 font-bold">
              <AlertCircle className="w-5 h-5" />
              <span>National Crisis Help Information</span>
            </div>
            <p className="text-slate-700 dark:text-slate-300 leading-relaxed text-xs">
              If you or someone you know is in severe distress or experiencing thoughts of self-harm, please reach out to these professional 24/7 helpline responders:
            </p>

            <div className="space-y-3">
              <div className="p-3 bg-white dark:bg-slate-900 rounded-lg border border-red-500/20">
                <p className="font-bold text-red-600">Vandrevala Foundation Helpline</p>
                <p className="font-mono font-bold text-slate-800 dark:text-slate-200 mt-0.5">Call: +91 9999 666 555</p>
                <p className="text-[10px] text-slate-500">Free, compassionate psychiatric support 24/7 across India.</p>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 rounded-lg border border-red-500/20">
                <p className="font-bold text-red-600">AASRA Helpline</p>
                <p className="font-mono font-bold text-slate-800 dark:text-slate-200 mt-0.5">Call: +91 98204 66726</p>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 rounded-lg border border-red-500/20">
                <p className="font-bold text-red-600">NIMHANS Mental Health Helpline</p>
                <p className="font-mono font-bold text-slate-800 dark:text-slate-200 mt-0.5">Call: 080-46110007</p>
                <p className="text-[10px] text-slate-500">Government-sponsored specialized mental health clinical response.</p>
              </div>
            </div>
          </div>

        </div>
      </div>

    </div>
  );
}
