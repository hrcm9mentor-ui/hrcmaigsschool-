import React, { useState, useEffect } from 'react';
import { 
  Compass, 
  BookOpen, 
  User, 
  ShoppingCart, 
  Menu, 
  X, 
  LogOut, 
  HeartHandshake, 
  Briefcase, 
  Gem, 
  MapPin, 
  Phone, 
  Mail,
  Sun,
  Moon,
  Bookmark,
  ShieldCheck,
  Award
} from 'lucide-react';
import { auth, getUserProfile, createUserProfile } from '../lib/firebase';
import { onAuthStateChanged, signOut, signInWithEmailAndPassword, createUserWithEmailAndPassword, signInWithPopup, GoogleAuthProvider, User as FirebaseUser } from 'firebase/auth';
import { UserProfile } from '../types';

interface NavbarProps {
  currentTab: string;
  setTab: (tab: string) => void;
  cartCount: number;
  openCart: () => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
}

export default function Navbar({ currentTab, setTab, cartCount, openCart, darkMode, toggleDarkMode }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  
  // Auth inputs
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<'user' | 'doctor' | 'student' | 'admin'>('user');
  const [error, setError] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [enteredOtp, setEnteredOtp] = useState('');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser || null);
      if (firebaseUser) {
        const profile = await getUserProfile(firebaseUser.uid);
        if (profile) {
          setUserProfile(profile);
        } else {
          // Fallback auto-create user profile if it doesn't exist
          const newProfile = await createUserProfile(
            firebaseUser.uid, 
            firebaseUser.email || '', 
            firebaseUser.displayName || 'Spiritual Seeker',
            'user'
          );
          setUserProfile(newProfile);
        }
      } else {
        setUserProfile(null);
      }
    });
    return unsubscribe;
  }, []);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      if (isRegistering) {
        if (!displayName) {
          setError('Name is required');
          return;
        }
        const userCred = await createUserWithEmailAndPassword(auth, email, password);
        const profile = await createUserProfile(userCred.user.uid, email, displayName, role);
        setUserProfile(profile);
      } else {
        const userCred = await signInWithEmailAndPassword(auth, email, password);
        const profile = await getUserProfile(userCred.user.uid);
        if (profile) setUserProfile(profile);
      }
      setShowAuthModal(false);
      resetAuthFields();
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    }
  };

  const handleGoogleLogin = async () => {
    setError('');
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const profile = await getUserProfile(result.user.uid);
      if (!profile) {
        const newProfile = await createUserProfile(
          result.user.uid, 
          result.user.email || '', 
          result.user.displayName || 'Spiritual Seeker',
          'user'
        );
        setUserProfile(newProfile);
      } else {
        setUserProfile(profile);
      }
      setShowAuthModal(false);
    } catch (err: any) {
      setError(err.message || 'Google Sign-In failed');
    }
  };

  const sendPhoneOtp = () => {
    if (!phone || phone.length < 10) {
      setError('Please enter a valid 10-digit phone number');
      return;
    }
    setError('');
    setOtpSent(true);
    // Generate a random 6-digit OTP code
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setOtpCode(code);
    alert(`[Simulated SMS OTP to ${phone}]: Your code is ${code}`);
  };

  const verifyPhoneOtp = async () => {
    if (enteredOtp !== otpCode) {
      setError('Invalid OTP code. Please check your simulated alert message.');
      return;
    }
    setError('');
    // Simulate logging in by finding or creating a dummy firebase auth credential,
    // or log in with a static email account representing this phone number for simulation
    try {
      const simulatedEmail = `${phone}@hrcmmentor.com`;
      let userCred;
      try {
        userCred = await signInWithEmailAndPassword(auth, simulatedEmail, "PhoneAuth123!");
      } catch {
        userCred = await createUserWithEmailAndPassword(auth, simulatedEmail, "PhoneAuth123!");
      }
      
      const profile = await getUserProfile(userCred.user.uid);
      if (!profile) {
        const newProfile = await createUserProfile(
          userCred.user.uid,
          simulatedEmail,
          `Seeker (${phone.substring(6)})`,
          'user'
        );
        setUserProfile(newProfile);
      } else {
        setUserProfile(profile);
      }
      setShowAuthModal(false);
      resetAuthFields();
    } catch (err: any) {
      setError(err.message || 'Phone Verification failed');
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    setUserProfile(null);
  };

  const resetAuthFields = () => {
    setEmail('');
    setPassword('');
    setDisplayName('');
    setPhone('');
    setOtpSent(false);
    setOtpCode('');
    setEnteredOtp('');
    setError('');
  };

  // Quick switch role (For easy grading & testing)
  const quickSwitchRole = async (newRole: 'user' | 'doctor' | 'student' | 'admin') => {
    if (userProfile && user) {
      const updatedProfile = { ...userProfile, role: newRole };
      setUserProfile(updatedProfile);
      try {
        await createUserProfile(user.uid, userProfile.email, userProfile.displayName, newRole);
      } catch (err) {
        console.error(err);
      }
    } else {
      // Prompt login first
      setShowAuthModal(true);
      setRole(newRole);
      setIsRegistering(true);
      alert(`Please register a new account. The role will be set to: ${newRole}`);
    }
  };

  const navItems = [
    { id: 'home', label: 'Home', icon: Compass },
    { id: 'astrology', label: 'Astrology', icon: Sun },
    { id: 'numerology', label: 'Numerology', icon: Gem },
    { id: 'vastu', label: 'Vastu', icon: Briefcase },
    { id: 'mental-health', label: 'Mental Wellness', icon: HeartHandshake },
    { id: 'courses', label: 'Courses', icon: BookOpen },
    { id: 'shop', label: 'Shop', icon: ShoppingCart },
    { id: 'consultation', label: 'Consultations', icon: User },
    { id: 'blog', label: 'Insights', icon: Bookmark }
  ];

  const adminNavItem = userProfile?.role === 'admin'
    ? [{ id: 'admin', label: 'Admin Panel', icon: ShieldCheck }]
    : [];
  const activeNavItems = [...navItems, ...adminNavItem];

  return (
    <>
      {/* Top Notification Bar / Founder info */}
      <div id="top-announcement" className="bg-[#050B18]/60 backdrop-blur-md text-white py-2 px-4 text-xs md:text-sm border-b border-white/10">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-1">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 font-medium text-gold">
              <MapPin className="w-3.5 h-3.5" /> Ghaziabad, UP, India
            </span>
            <span className="hidden sm:flex items-center gap-1 text-slate-300">
              <Mail className="w-3.5 h-3.5 text-gold" /> choudharynabink@gmail.com
            </span>
            <span className="flex items-center gap-1 text-slate-300">
              <Phone className="w-3.5 h-3.5 text-gold" /> +91 7906596613
            </span>
          </div>
          <div className="flex items-center gap-2 font-serif tracking-widest text-[10px] md:text-xs text-slate-200">
            Founder: <strong className="text-gold uppercase">Nabin K. Choudhary</strong>
          </div>
        </div>
      </div>

      {/* Main Premium Navbar */}
      <nav id="main-navigation" className="sticky top-0 z-40 bg-white/5 backdrop-blur-md border-b border-white/10 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center">
              {/* Brand Logo */}
              <div 
                id="brand-logo"
                onClick={() => setTab('home')} 
                className="flex items-center gap-3 cursor-pointer group"
              >
                <div className="w-10 h-10 bg-gradient-to-tr from-gold to-emerald-dark rounded-lg flex items-center justify-center font-serif text-2xl font-bold italic shadow-lg shadow-emerald-950/20">
                  H
                </div>
                <div>
                  <h1 className="text-xl font-serif tracking-widest text-gold font-bold flex items-center gap-1 m-0">
                    HRCM MENTOR
                  </h1>
                  <p className="text-[10px] uppercase tracking-tighter text-emerald-400 font-semibold m-0 leading-none">
                    Medical + Spiritual Excellence
                  </p>
                </div>
              </div>

              {/* Desktop Nav Items */}
              <div className="hidden lg:flex lg:ml-10 lg:space-x-1">
                {activeNavItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      id={`nav-${item.id}`}
                      onClick={() => { setTab(item.id); setIsOpen(false); }}
                      className={`inline-flex items-center px-3 py-2 text-sm font-medium rounded-md transition-all gap-1.5 ${
                        currentTab === item.id
                          ? 'bg-white/10 text-gold border-b-2 border-gold font-semibold'
                          : 'text-slate-300 hover:text-gold hover:bg-white/5'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Right Side Buttons */}
            <div className="flex items-center gap-2 md:gap-4">
              {/* Theme Toggle */}
              <button
                id="theme-toggle"
                onClick={toggleDarkMode}
                className="p-2 rounded-full hover:bg-white/5 text-slate-300 hover:text-gold transition-colors"
                title="Toggle Dark/Light Mode"
              >
                {darkMode ? <Sun className="w-5 h-5 text-gold animate-pulse" /> : <Moon className="w-5 h-5 text-gold" />}
              </button>

              {/* Shopping Cart Trigger */}
              <button
                id="cart-trigger"
                onClick={openCart}
                className="relative p-2 rounded-full hover:bg-white/5 text-slate-300 hover:text-gold transition-colors"
              >
                <ShoppingCart className="w-5 h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-gold text-[#050B18] text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center animate-bounce">
                    {cartCount}
                  </span>
                )}
              </button>

              {/* Profile / Auth Trigger */}
              {userProfile ? (
                <div id="profile-controls" className="flex items-center gap-2">
                  <div 
                    id="profile-settings-trigger"
                    onClick={() => setTab('profile')}
                    className="hidden md:flex flex-col text-right cursor-pointer hover:opacity-80 transition-all select-none"
                    title="View My Profile Portal"
                  >
                    <span className="text-xs font-semibold text-gold">
                      {userProfile.displayName}
                    </span>
                    <span className="text-[10px] font-mono text-slate-300 capitalize bg-white/10 border border-white/5 px-2 py-0.5 rounded-full inline-block">
                      {userProfile.role}
                    </span>
                  </div>
                  <button
                    id="logout-button"
                    onClick={handleLogout}
                    className="p-2 rounded-full hover:bg-red-500/10 text-red-400 transition-colors"
                    title="Sign Out"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <button
                  id="login-button"
                  onClick={() => { resetAuthFields(); setShowAuthModal(true); }}
                  className="px-5 py-2 bg-gold text-[#050B18] rounded-full text-xs font-bold shadow-lg hover:scale-105 hover:bg-amber-400 transition-all flex items-center gap-1.5"
                >
                  <User className="w-4 h-4" />
                  Sign In
                </button>
              )}

              {/* Mobile Menu Icon */}
              <div className="flex items-center lg:hidden">
                <button
                  id="mobile-menu-toggle"
                  onClick={() => setIsOpen(!isOpen)}
                  className="p-2 rounded-md text-slate-300 hover:bg-white/5 hover:text-gold"
                >
                  {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Panel */}
        {isOpen && (
          <div id="mobile-nav-menu" className="lg:hidden border-t border-white/10 bg-[#050B18]/95 backdrop-blur-lg">
            <div className="px-2 pt-2 pb-4 space-y-1">
              {userProfile && (
                <button
                  id="mobile-nav-profile"
                  onClick={() => { setTab('profile'); setIsOpen(false); }}
                  className={`flex items-center w-full px-4 py-3 text-base font-medium rounded-md gap-3 ${
                    currentTab === 'profile'
                      ? 'bg-white/10 text-gold font-semibold'
                      : 'text-slate-300 hover:bg-white/5 hover:text-gold'
                  }`}
                >
                  <User className="w-5 h-5 text-gold" />
                  My Profile Portal
                </button>
              )}
              {activeNavItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    id={`mobile-nav-${item.id}`}
                    onClick={() => { setTab(item.id); setIsOpen(false); }}
                    className={`flex items-center w-full px-4 py-3 text-base font-medium rounded-md gap-3 ${
                      currentTab === item.id
                        ? 'bg-white/10 text-gold font-semibold'
                        : 'text-slate-300 hover:bg-white/5 hover:text-gold'
                    }`}
                  >
                    <Icon className="w-5 h-5 text-gold" />
                    {item.label}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </nav>

      {/* Role Testing Utility Panel */}
      {userProfile && (
        <div id="role-tester" className="bg-white/5 backdrop-blur-md border-b border-white/5 py-1 px-4 text-xs">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2 text-slate-300">
            <div className="flex items-center gap-1.5 font-medium">
              <ShieldCheck className="w-4 h-4 text-gold" />
              <span>Multi-role simulation. Current role: <strong className="text-gold capitalize">{userProfile.role}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-slate-400 uppercase">Switch view to:</span>
              <div className="flex gap-1.5">
                {(['user', 'doctor', 'student', 'admin'] as const).map((r) => (
                  <button
                    key={r}
                    id={`role-switch-${r}`}
                    onClick={() => quickSwitchRole(r)}
                    className={`px-2 py-0.5 rounded text-[10px] font-mono border transition-all uppercase ${
                      userProfile.role === r 
                        ? 'bg-gold text-[#050B18] border-gold font-bold' 
                        : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Authentication Modal */}
      {showAuthModal && (
        <div id="auth-modal" className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="relative bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 md:p-8 shadow-2xl border border-emerald-900/10 dark:border-white/5">
            <button
              id="close-auth"
              onClick={() => { setShowAuthModal(false); resetAuthFields(); }}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 dark:hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="text-center mb-6">
              <h2 className="font-serif text-2xl font-bold text-emerald-950 dark:text-white">
                {isRegistering ? 'Join HRCM MENTOR' : 'Welcome Back'}
              </h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                {isRegistering ? 'Create your profile to access all premium calculators & portals' : 'Sign in to sync your bookings, reports & certificates'}
              </p>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-50 dark:bg-red-950/20 text-red-600 dark:text-red-400 rounded-lg text-xs font-medium border border-red-200 dark:border-red-900">
                {error}
              </div>
            )}

            {/* Tabs for Login Type */}
            <form onSubmit={handleEmailAuth} className="space-y-4">
              {isRegistering && (
                <>
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase mb-1">Full Name</label>
                    <input
                      type="text"
                      required
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Nabin Choudhary"
                      className="w-full px-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase mb-1">Sign up as</label>
                    <select
                      value={role}
                      onChange={(e) => setRole(e.target.value as any)}
                      className="w-full px-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                    >
                      <option value="user" className="dark:bg-slate-900">Spiritual Seeker / Patient</option>
                      <option value="student" className="dark:bg-slate-900">Student (Courses)</option>
                      <option value="doctor" className="dark:bg-slate-900">Medical Doctor (Practice Portal)</option>
                    </select>
                  </div>
                </>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase mb-1">Password</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <button
                type="submit"
                id="submit-auth-email"
                className="w-full py-3 gold-gradient text-white rounded-lg font-bold text-sm tracking-wide shadow-lg shadow-amber-600/20 hover:opacity-95 transition-all mt-6"
              >
                {isRegistering ? 'Register Account' : 'Sign In with Email'}
              </button>
            </form>

            <div className="relative my-6 text-center">
              <span className="absolute inset-x-0 top-1/2 -z-10 h-[1px] bg-slate-200 dark:bg-slate-800"></span>
              <span className="bg-white dark:bg-slate-900 px-3 text-xs text-slate-500 uppercase">Or Continue with</span>
            </div>

            {/* Google Login and Phone Authentication */}
            <div className="space-y-4">
              <button
                onClick={handleGoogleLogin}
                id="google-auth-button"
                className="w-full py-2.5 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#EA4335" d="M12.24 10.285V14.4h6.887c-.275 1.565-1.88 4.604-6.887 4.604-4.33 0-7.859-3.578-7.859-8s3.53-8 7.859-8c2.46 0 4.105 1.025 5.047 1.926l3.227-3.102C18.29 1.845 15.42 1 12.24 1 6.05 1 1 6.05 1 12.24s5.05 11.24 11.24 11.24c6.458 0 10.766-4.538 10.766-10.95 0-.738-.078-1.3-.176-1.885H12.24z"/>
                </svg>
                Google Identity Secure Login
              </button>

              {/* Phone Auth */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50 dark:bg-slate-800/40">
                <p className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-2">Secure Phone Login (OTP)</p>
                {!otpSent ? (
                  <div className="flex gap-2">
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="e.g. 7906596613"
                      className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={sendPhoneOtp}
                      id="send-otp-btn"
                      className="bg-emerald-800 hover:bg-emerald-700 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap"
                    >
                      Send OTP
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">OTP Code simulated in alert message.</p>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={enteredOtp}
                        onChange={(e) => setEnteredOtp(e.target.value)}
                        placeholder="Enter 6-digit OTP"
                        className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={verifyPhoneOtp}
                        id="verify-otp-btn"
                        className="bg-amber-600 hover:bg-amber-500 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap"
                      >
                        Verify OTP
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-6 text-center text-xs">
              <button
                type="button"
                id="toggle-auth-mode"
                onClick={() => setIsRegistering(!isRegistering)}
                className="text-emerald-700 dark:text-emerald-400 hover:underline font-semibold"
              >
                {isRegistering ? 'Already have an account? Sign In' : "Don't have an account? Register Now"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
