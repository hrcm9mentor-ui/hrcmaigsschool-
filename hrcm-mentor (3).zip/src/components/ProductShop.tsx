import React, { useState, useMemo, useEffect } from 'react';
import { 
  ShoppingCart, 
  Trash2, 
  Star, 
  Tag, 
  CheckCircle, 
  Search, 
  SlidersHorizontal,
  BookmarkCheck,
  FileCheck,
  X,
  CreditCard,
  Lock,
  Smartphone,
  Building,
  Wallet,
  RotateCw,
  ArrowRight,
  ShieldCheck,
  QrCode,
  AlertCircle,
  Heart
} from 'lucide-react';
import { INITIAL_PRODUCTS } from '../data';
import { Product, CartItem, Order } from '../types';
import { auth, createOrder, getUserOrders, addToWishlist, removeFromWishlist, getUserWishlist } from '../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';

interface ProductShopProps {
  cart: CartItem[];
  setCart: React.Dispatch<React.SetStateAction<CartItem[]>>;
}

export default function ProductShop({ cart, setCart }: ProductShopProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Active product details view
  const [detailedProduct, setDetailedProduct] = useState<Product | null>(null);
  
  // Track wishlisted product IDs
  const [wishlistIds, setWishlistIds] = useState<Set<string>>(new Set());
  
  // Active product reviews input
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewSuccess, setReviewSuccess] = useState(false);

  // Coupons
  const [couponInput, setCouponInput] = useState('');
  const [activeCouponDiscount, setActiveCouponDiscount] = useState<number>(0);
  const [couponError, setCouponError] = useState('');
  const [couponSuccess, setCouponSuccess] = useState('');

  // Orders lists (seeded with a sample order, synced with Firebase if available)
  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'ord_sample123',
      userId: 'user-1',
      userName: 'Amit Sharma',
      items: [
        { productId: 'prod-rudraksha-5', name: 'Premium 5 Mukhi Nepal Rudraksha', price: 1250, quantity: 1, category: 'rudraksha', imageUrl: 'https://images.unsplash.com/photo-1609137144813-94c65363406e?auto=format&fit=crop&q=80&w=600' }
      ],
      total: 1250,
      status: 'shipped',
      paymentId: 'pay_mock_902ba',
      createdAt: '2026-07-15T08:00:00Z',
      address: 'Noida Sector 62, Uttar Pradesh, India'
    }
  ]);

  // Checkout overlay states
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [shippingAddress, setShippingAddress] = useState('');
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  const [placedOrderId, setPlacedOrderId] = useState('');

  // Filtered products list
  const filteredProducts = useMemo(() => {
    return INITIAL_PRODUCTS.filter((prod) => {
      const matchCat = selectedCategory === 'all' || prod.category === selectedCategory;
      const matchSearch = prod.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          prod.description.toLowerCase().includes(searchTerm.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [selectedCategory, searchTerm]);

  // Cart math
  const cartSubtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const cartTotal = useMemo(() => {
    const discounted = cartSubtotal * (1 - activeCouponDiscount);
    return Math.round(discounted);
  }, [cartSubtotal, activeCouponDiscount]);

  const handleAddToCart = (prod: Product) => {
    const existing = cart.find(item => item.product.id === prod.id);
    if (existing) {
      setCart(cart.map(item => item.product.id === prod.id ? { ...item, quantity: item.quantity + 1 } : item));
    } else {
      setCart([...cart, { product: prod, quantity: 1 }]);
    }
    alert(`${prod.name} added to cart.`);
  };

  const handleUpdateQty = (prodId: string, delta: number) => {
    const updated = cart.map(item => {
      if (item.product.id === prodId) {
        const newQty = item.quantity + delta;
        return newQty > 0 ? { ...item, quantity: newQty } : item;
      }
      return item;
    }).filter(item => item.quantity > 0);
    setCart(updated);
  };

  const handleRemoveItem = (prodId: string) => {
    setCart(cart.filter(item => item.product.id !== prodId));
  };

  // Apply discount coupon NABIN10 (10% off)
  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    setCouponSuccess('');
    if (couponInput.toUpperCase() === 'NABIN10') {
      setActiveCouponDiscount(0.10);
      setCouponSuccess('Coupon applied: 10% instant discount!');
    } else if (couponInput.toUpperCase() === 'GHAZIABAD') {
      setActiveCouponDiscount(0.15);
      setCouponSuccess('Coupon applied: 15% regional founder discount!');
    } else {
      setCouponError('Invalid coupon code. Try NABIN10 or GHAZIABAD.');
    }
  };

  // Submit product review
  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!detailedProduct || !reviewComment) return;

    const newReview = {
      userName: auth.currentUser?.displayName || 'Spiritual Seeker',
      rating: reviewRating,
      comment: reviewComment,
      date: new Date().toISOString().split('T')[0]
    };

    detailedProduct.reviews = [newReview, ...detailedProduct.reviews];
    setReviewSuccess(true);
    setReviewComment('');
    setReviewRating(5);
    setTimeout(() => setReviewSuccess(false), 3000);
  };

  // Toggle product wishlist status
  const handleToggleWishlist = async (prod: Product) => {
    if (!auth.currentUser) {
      alert("Please sign in to save products to your persistent wishlist.");
      return;
    }

    const userId = auth.currentUser.uid;
    const isWishlisted = wishlistIds.has(prod.id);

    try {
      if (isWishlisted) {
        await removeFromWishlist(userId, prod.id);
        setWishlistIds((prev) => {
          const updated = new Set(prev);
          updated.delete(prod.id);
          return updated;
        });
      } else {
        await addToWishlist(userId, {
          productId: prod.id,
          name: prod.name,
          price: prod.price,
          category: prod.category,
          imageUrl: prod.imageUrl
        });
        setWishlistIds((prev) => {
          const updated = new Set(prev);
          updated.add(prod.id);
          return updated;
        });
      }
    } catch (err) {
      console.error("Error toggling wishlist:", err);
      alert("Could not update wishlist database state. Please try again.");
    }
  };

  // Razorpay secure integration states
  const [showRazorpayPortal, setShowRazorpayPortal] = useState(false);
  const [razorpayMethod, setRazorpayMethod] = useState<'card' | 'upi' | 'netbanking' | 'wallet'>('card');
  const [paymentStep, setPaymentStep] = useState<'input' | 'otp' | 'processing' | 'success'>('input');
  
  // Card credentials
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardName, setCardName] = useState('');
  
  // UPI parameters
  const [upiId, setUpiId] = useState('');
  const [qrCodeScanned, setQrCodeScanned] = useState(false);
  const [qrTimer, setQrTimer] = useState(300); // 5 mins
  
  // Netbanking details
  const [selectedBank, setSelectedBank] = useState('SBI');
  
  // Wallet channels
  const [selectedWallet, setSelectedWallet] = useState('PhonePe');

  // Interactive verification codes
  const [otpInput, setOtpInput] = useState('');
  const [otpError, setOtpError] = useState('');
  
  // Progress status & SDK parameters
  const [paymentProgress, setPaymentProgress] = useState('');
  const [sdkAvailable, setSdkAvailable] = useState(false);
  const [useRealSdk, setUseRealSdk] = useState(false);

  // Sync order history and detect Razorpay SDK availability
  useEffect(() => {
    if ((window as any).Razorpay) {
      setSdkAvailable(true);
    }
    
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const dbOrders = await getUserOrders(user.uid);
          if (dbOrders && dbOrders.length > 0) {
            setOrders(dbOrders);
          }
          
          const userWishlist = await getUserWishlist(user.uid);
          setWishlistIds(new Set(userWishlist.map((w) => w.productId)));
        } catch (err) {
          console.error("Error retrieving historical user details:", err);
        }
      } else {
        setWishlistIds(new Set());
      }
    });
    return unsubscribe;
  }, []);

  // Countdown timer for simulated UPI QR
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (showRazorpayPortal && razorpayMethod === 'upi' && !qrCodeScanned && qrTimer > 0) {
      timer = setInterval(() => {
        setQrTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [showRazorpayPortal, razorpayMethod, qrCodeScanned, qrTimer]);

  const formatQrTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '');
    const formatted = value.match(/.{1,4}/g)?.join(' ') || '';
    setCardNumber(formatted.substring(0, 19));
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 2) {
      value = value.substring(0, 2) + '/' + value.substring(2, 4);
    }
    setCardExpiry(value.substring(0, 5));
  };

  const handleCvvChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '');
    setCardCvv(value.substring(0, 4));
  };

  const getCardBrand = (number: string) => {
    const clean = number.replace(/\s/g, '');
    if (clean.startsWith('4')) return 'Visa';
    if (clean.startsWith('5')) return 'Mastercard';
    if (clean.startsWith('3')) return 'American Express';
    return 'Generic';
  };

  // Extract shared order placement to database
  const completeOrderPlacement = async (paymentId: string) => {
    setIsPlacingOrder(true);
    try {
      const ordId = `ord_${Math.random().toString(36).substring(2, 12)}`;
      const newOrder: Order = {
        id: ordId,
        userId: auth.currentUser?.uid || 'guest-user',
        userName: auth.currentUser?.displayName || 'Spiritual Seeker',
        items: cart.map(item => ({
          productId: item.product.id,
          name: item.product.name,
          price: item.product.price,
          quantity: item.quantity,
          category: item.product.category,
          imageUrl: item.product.imageUrl
        })),
        total: cartTotal,
        status: 'pending',
        paymentId: paymentId,
        createdAt: new Date().toISOString(),
        couponCode: activeCouponDiscount > 0 ? 'MEMBER_OFFER' : undefined,
        address: shippingAddress
      };

      try {
        await createOrder(newOrder);
      } catch (fErr) {
        console.warn("Firestore order persistence bypassed.", fErr);
      }

      setOrders([newOrder, ...orders]);
      setPlacedOrderId(ordId);
      setCart([]); // Clear shopping cart
      setShowCheckoutModal(false);
      setShowRazorpayPortal(false);
      setShippingAddress('');
    } catch (err) {
      console.error("Order completion failed:", err);
    } finally {
      setIsPlacingOrder(false);
    }
  };

  // Launch standard native Razorpay SDK (if loaded and compatible)
  const handleRealRazorpayPayment = () => {
    if (!(window as any).Razorpay) {
      alert("Razorpay SDK was blocked or failed to load. Initiating secure simulator gateway instead.");
      setUseRealSdk(false);
      setShowCheckoutModal(false);
      setShowRazorpayPortal(true);
      return;
    }

    const options = {
      key: "rzp_test_dummykey",
      amount: cartTotal * 100,
      currency: "INR",
      name: "Certified Cosmic Remedies",
      description: "Secure Remedies & Astro Bookstore",
      image: "https://images.unsplash.com/photo-1605289982774-9a6fef564df8?auto=format&fit=crop&q=80&w=200",
      handler: function (response: any) {
        completeOrderPlacement(response.razorpay_payment_id || `pay_rzp_${Math.random().toString(36).substring(2, 10)}`);
      },
      prefill: {
        name: auth.currentUser?.displayName || "Spiritual Seeker",
        email: auth.currentUser?.email || "seeker@example.com",
        contact: ""
      },
      notes: {
        address: shippingAddress
      },
      theme: {
        color: "#064e3b" // Emerald
      }
    };

    try {
      const rzp = new (window as any).Razorpay(options);
      rzp.on('payment.failed', function (resp: any) {
        alert("Transaction Aborted: " + resp.error.description);
      });
      rzp.open();
      setShowCheckoutModal(false);
    } catch (err: any) {
      console.warn("Razorpay SDK crashed inside iframe context. Redirecting to simulator:", err);
      setUseRealSdk(false);
      setShowCheckoutModal(false);
      setShowRazorpayPortal(true);
    }
  };

  // Triggered when clicking "Proceed to Payment" in shipping details
  const handleInitiatePaymentStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shippingAddress.trim()) {
      alert('Please fill out the shipping address before proceeding.');
      return;
    }

    if (useRealSdk && sdkAvailable) {
      handleRealRazorpayPayment();
    } else {
      setShowCheckoutModal(false);
      setShowRazorpayPortal(true);
      setPaymentStep('input');
      setCardNumber('');
      setCardExpiry('');
      setCardCvv('');
      setCardName('');
      setUpiId('');
      setQrCodeScanned(false);
      setQrTimer(300);
    }
  };

  // Simulated Pay handler
  const handleInitiateSimulatedPay = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (razorpayMethod === 'card') {
      if (cardNumber.length < 15 || cardExpiry.length < 5 || cardCvv.length < 3 || !cardName.trim()) {
        alert("Please complete credit/debit card information with a valid name, card number, CVV, and expiry.");
        return;
      }
    } else if (razorpayMethod === 'upi') {
      if (!upiId.includes('@') && !qrCodeScanned) {
        alert("Please provide a valid UPI handle (e.g., name@upi) or scan the QR Code.");
        return;
      }
    }

    setPaymentStep('processing');
    setPaymentProgress("Synchronizing secure socket node with Razorpay API endpoints...");

    setTimeout(() => {
      setPaymentProgress("Encrypting transaction payload with 256-bit SSL signatures...");
      setTimeout(() => {
        setPaymentProgress("Requesting OTP authorization payload from the issuing bank...");
        setTimeout(() => {
          setPaymentStep('otp');
          setOtpInput('');
          setOtpError('');
        }, 1200);
      }, 1200);
    }, 1000);
  };

  // Handle OTP evaluation in secure simulation
  const handleVerifyOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpInput) {
      setOtpError("Passcode cannot be empty. Please input the 6-digit verification code sent to your mobile device.");
      return;
    }

    setPaymentStep('processing');
    setPaymentProgress("Authenticating one-time password code...");

    setTimeout(() => {
      setPaymentProgress("Settling and transferring funds dynamically via Astro settlement networks...");
      setTimeout(() => {
        setPaymentProgress("Capturing transaction token and generating invoice credentials...");
        setTimeout(() => {
          const mockPaymentId = `pay_rzp_${Math.random().toString(36).substring(2, 10)}`;
          setPaymentStep('success');
          setTimeout(() => {
            completeOrderPlacement(mockPaymentId);
          }, 1500);
        }, 1200);
      }, 1200);
    }, 1000);
  };

  return (
    <div id="shop-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 dark:text-white">
      
      {/* Introduction Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <h2 className="font-serif text-3xl md:text-4xl font-extrabold text-emerald-950 dark:text-white">
          Certified Cosmic Remedies & Bookstore
        </h2>
        <p className="text-slate-600 dark:text-slate-400">
          Enhance your local environmental vibrations. Shop genuine high-altitude Nepalese Rudraksha beads, gold-plated brass Sri Yantras, natural Mercury-approved gemstones, and expert textbooks.
        </p>
      </div>

      {placedOrderId && (
        <div className="p-5 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded-xl border border-emerald-500/20 max-w-2xl mx-auto text-center space-y-2">
          <CheckCircle className="w-12 h-12 text-emerald-600 mx-auto animate-bounce" />
          <h3 className="font-bold text-lg">Transaction Complete!</h3>
          <p className="text-xs">Your order has been recorded successfully. Order reference: <strong>{placedOrderId}</strong></p>
          <button 
            onClick={() => setPlacedOrderId('')}
            className="text-xs font-bold underline text-amber-600 dark:text-amber-500 mt-2"
          >
            Continue Shopping
          </button>
        </div>
      )}

      {/* Grid: Filters and Products on Left, Cart & Order History on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Product Grid */}
        <div className="lg:col-span-8 space-y-6">
          
          <div className="flex flex-wrap justify-between items-center gap-4 border-b border-slate-100 dark:border-white/10 pb-4">
            {/* Filter buttons */}
            <div className="flex flex-wrap gap-2 text-xs font-semibold">
              {[
                { id: 'all', label: 'All Remedies' },
                { id: 'rudraksha', label: 'Rudraksha' },
                { id: 'yantra', label: 'Yantra' },
                { id: 'gemstone', label: 'Gemstones' },
                { id: 'book', label: 'Books' },
                { id: 'digital_report', label: 'Reports' }
              ].map((cat) => (
                <button
                  key={cat.id}
                  id={`cat-filter-${cat.id}`}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4.5 py-2 rounded-full border transition-all ${
                    selectedCategory === cat.id
                      ? 'bg-emerald-900 border-emerald-900 text-white font-bold'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Quick search input */}
            <div className="relative text-xs w-full sm:w-auto">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search catalog..."
                className="w-full sm:w-56 pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-full focus:outline-none"
              />
              <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
            </div>
          </div>

          {/* Catalog grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {filteredProducts.map((prod) => (
              <div 
                key={prod.id}
                className="bg-white dark:bg-slate-900 rounded-2xl overflow-hidden border border-slate-100 dark:border-white/5 shadow-md flex flex-col h-full hover:shadow-xl transition-all"
              >
                <div 
                  className="h-44 bg-slate-100 dark:bg-slate-950 relative cursor-pointer"
                  onClick={() => setDetailedProduct(prod)}
                >
                  <img 
                    src={prod.imageUrl} 
                    alt={prod.name} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute top-2 left-2 bg-amber-500 text-slate-950 text-[9px] font-bold uppercase tracking-widest px-2.5 py-0.5 rounded-md">
                    {prod.category}
                  </span>
                  
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleWishlist(prod);
                    }}
                    className="absolute top-2 right-2 bg-[#050B18]/70 hover:bg-[#050B18]/95 text-white p-1.5 rounded-full border border-white/10 shadow backdrop-blur transition-all duration-200"
                    title={wishlistIds.has(prod.id) ? "Remove from Wishlist" : "Add to Wishlist"}
                  >
                    <Heart 
                      className={`w-3.5 h-3.5 transition-colors ${
                        wishlistIds.has(prod.id) 
                          ? 'fill-red-500 text-red-500' 
                          : 'text-slate-300 hover:text-red-400'
                      }`} 
                    />
                  </button>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <h4 
                      onClick={() => setDetailedProduct(prod)}
                      className="font-serif font-bold text-sm text-emerald-950 dark:text-white line-clamp-1 hover:underline cursor-pointer"
                    >
                      {prod.name}
                    </h4>
                    <p className="text-[11px] text-slate-500 line-clamp-2 mt-1">
                      {prod.description}
                    </p>
                  </div>

                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-emerald-800 dark:text-emerald-400">₹{prod.price}</span>
                    <button
                      id={`add-cart-${prod.id}`}
                      onClick={() => handleAddToCart(prod)}
                      className="bg-emerald-900 dark:bg-emerald-600 text-white font-bold px-3 py-1.5 rounded-lg hover:opacity-90 transition-opacity"
                    >
                      Add To Cart
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: E-commerce shopping Cart & Order History */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Shopping Cart Block */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-xl border border-emerald-900/10 dark:border-white/5 space-y-6">
            <h3 className="font-serif text-base font-bold text-emerald-950 dark:text-white flex items-center gap-1.5">
              <ShoppingCart className="w-5 h-5 text-amber-500" /> Your Shopping Cart
            </h3>

            {cart.length > 0 ? (
              <div className="space-y-4">
                <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                  {cart.map((item) => (
                    <div key={item.product.id} className="flex gap-3 text-xs border-b border-slate-100 dark:border-white/5 pb-3">
                      <div className="w-12 h-12 bg-slate-100 rounded overflow-hidden flex-shrink-0">
                        <img src={item.product.imageUrl} alt={item.product.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <h4 className="font-bold text-slate-800 dark:text-slate-200 line-clamp-1">{item.product.name}</h4>
                        <div className="flex justify-between items-center text-slate-500 text-[10px]">
                          <span>₹{item.product.price}</span>
                          <div className="flex items-center gap-2 border border-slate-200 dark:border-slate-800 rounded px-1">
                            <button onClick={() => handleUpdateQty(item.product.id, -1)} className="font-bold px-1 text-xs">-</button>
                            <span className="font-bold text-slate-700 dark:text-slate-300">{item.quantity}</span>
                            <button onClick={() => handleUpdateQty(item.product.id, 1)} className="font-bold px-1 text-xs">+</button>
                          </div>
                        </div>
                      </div>
                      <button 
                        onClick={() => handleRemoveItem(item.product.id)}
                        className="text-red-600 hover:bg-red-50 p-1.5 rounded-full self-center"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Coupons Block */}
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <input
                    type="text"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value)}
                    placeholder="Enter Coupon (NABIN10)"
                    className="flex-1 p-2 border border-slate-200 dark:border-slate-800 rounded-lg text-xs bg-transparent"
                  />
                  <button 
                    type="submit" 
                    id="apply-coupon-btn"
                    className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-3 py-2 rounded-lg text-xs uppercase"
                  >
                    Apply
                  </button>
                </form>

                {couponError && <p className="text-[10px] text-red-600">{couponError}</p>}
                {couponSuccess && <p className="text-[10px] text-emerald-600 font-bold">{couponSuccess}</p>}

                {/* Subtotals */}
                <div className="space-y-1.5 text-xs border-t border-slate-100 dark:border-white/5 pt-4 text-slate-500">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>₹{cartSubtotal}</span>
                  </div>
                  {activeCouponDiscount > 0 && (
                    <div className="flex justify-between text-emerald-700 dark:text-emerald-400 font-bold">
                      <span>Discount (Coupon):</span>
                      <span>-₹{Math.round(cartSubtotal * activeCouponDiscount)}</span>
                    </div>
                  )}
                  <div className="flex justify-between border-t border-slate-200 dark:border-slate-800 pt-2 text-sm text-emerald-950 dark:text-emerald-400 font-bold">
                    <span>Grand Total:</span>
                    <span>₹{cartTotal}</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    if (!auth.currentUser) {
                      alert('Please Sign In to proceed to checkout.');
                      return;
                    }
                    setShowCheckoutModal(true);
                  }}
                  id="checkout-cart-btn"
                  className="w-full py-3 bg-emerald-900 dark:bg-emerald-600 hover:bg-emerald-800 text-white rounded-lg font-bold text-xs uppercase tracking-wider"
                >
                  Proceed to Secure Checkout
                </button>
              </div>
            ) : (
              <p className="text-xs text-slate-500 text-center py-6">Your shopping cart is currently empty. Add certified remedies from the catalog list.</p>
            )}
          </div>

          {/* Order history */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-xl border border-emerald-900/10 dark:border-white/5 space-y-4">
            <h3 className="font-serif text-sm font-bold uppercase tracking-wider text-slate-500">Order History</h3>
            <div className="space-y-3">
              {orders.map((order) => (
                <div key={order.id} className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-white/5 text-xs space-y-1">
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="font-mono text-slate-400">{order.id}</span>
                    <span className="text-slate-500">{new Date(order.createdAt).toLocaleDateString()}</span>
                  </div>
                  <p className="font-bold text-slate-800 dark:text-slate-200 line-clamp-1">
                    {order.items.map(it => `${it.name} x${it.quantity}`).join(', ')}
                  </p>
                  <div className="flex justify-between items-center text-[10px] pt-1">
                    <span className="capitalize font-semibold text-amber-600">{order.status}</span>
                    <span className="font-bold text-emerald-900 dark:text-emerald-400">₹{order.total}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* Detailed Product Dialog Modal */}
      {detailedProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 md:p-8 space-y-6 shadow-2xl relative border border-emerald-900/10 dark:border-white/5">
            <button
              onClick={() => setDetailedProduct(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 dark:hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="flex flex-col sm:flex-row gap-6">
              <div className="w-full sm:w-40 h-40 bg-slate-100 dark:bg-slate-950 rounded-xl overflow-hidden flex-shrink-0">
                <img src={detailedProduct.imageUrl} alt={detailedProduct.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <div className="space-y-2">
                <span className="text-[10px] bg-amber-500/15 text-amber-800 dark:text-amber-400 px-2.5 py-0.5 rounded uppercase font-bold tracking-wider">{detailedProduct.category}</span>
                <h3 className="font-serif font-bold text-lg text-emerald-950 dark:text-white">{detailedProduct.name}</h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">{detailedProduct.description}</p>
                <p className="text-sm font-bold text-emerald-900 dark:text-emerald-400">Price: ₹{detailedProduct.price}</p>
                
                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={() => {
                      handleAddToCart(detailedProduct);
                      setDetailedProduct(null);
                    }}
                    className="bg-emerald-900 dark:bg-emerald-600 hover:opacity-90 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all cursor-pointer"
                  >
                    Add To Cart
                  </button>
                  <button
                    onClick={() => handleToggleWishlist(detailedProduct)}
                    className="px-4 py-2 border border-slate-200 dark:border-white/10 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 hover:bg-slate-50 dark:hover:bg-white/5 cursor-pointer text-slate-700 dark:text-slate-300"
                  >
                    <Heart 
                      className={`w-4 h-4 transition-colors ${
                        wishlistIds.has(detailedProduct.id) 
                          ? 'fill-red-500 text-red-500' 
                          : 'text-slate-400 dark:text-slate-300'
                      }`} 
                    />
                    {wishlistIds.has(detailedProduct.id) ? "Saved" : "Save to Wishlist"}
                  </button>
                </div>
              </div>
            </div>

            {/* Review sections */}
            <div className="border-t border-slate-100 dark:border-white/10 pt-4 space-y-4">
              <h4 className="font-serif text-sm font-bold text-emerald-950 dark:text-white">Customer Reviews & Postings</h4>
              
              <div className="space-y-3 max-h-40 overflow-y-auto pr-1">
                {detailedProduct.reviews.length > 0 ? (
                  detailedProduct.reviews.map((rev, idx) => (
                    <div key={idx} className="bg-slate-50 dark:bg-slate-800/40 p-3 rounded-lg border border-slate-100 dark:border-white/5 text-xs space-y-1">
                      <div className="flex justify-between">
                        <span className="font-bold text-emerald-950 dark:text-slate-300">{rev.userName}</span>
                        <span className="text-[10px] text-slate-400">{rev.date}</span>
                      </div>
                      <div className="flex items-center gap-0.5 text-amber-500 text-[10px]">
                        {new Array(rev.rating).fill(0).map((_, i) => <Star key={i} className="w-3 h-3 fill-amber-500" />)}
                      </div>
                      <p className="text-slate-600 dark:text-slate-400 italic">"{rev.comment}"</p>
                    </div>
                  ))
                ) : (
                  <p className="text-[11px] text-slate-500 italic">No reviews posted yet for this sacred remedy. Write your feedback below.</p>
                )}
              </div>

              {/* Add review form */}
              <form onSubmit={handleAddReview} className="space-y-3 text-xs">
                <p className="font-bold uppercase text-[10px] text-slate-400">Write Your Review</p>
                {reviewSuccess && <p className="text-[10px] text-emerald-600 font-bold">Review submitted successfully!</p>}
                
                <div className="flex gap-4">
                  <div>
                    <label className="block text-[10px] text-slate-500 uppercase mb-1">Rating</label>
                    <select
                      value={reviewRating}
                      onChange={(e) => setReviewRating(parseInt(e.target.value))}
                      className="p-1 rounded border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white"
                    >
                      <option value="5">5 Stars</option>
                      <option value="4">4 Stars</option>
                      <option value="3">3 Stars</option>
                    </select>
                  </div>
                  <div className="flex-1">
                    <label className="block text-[10px] text-slate-500 uppercase mb-1">Your Comment</label>
                    <input
                      type="text"
                      required
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      placeholder="e.g. Exceptional vibration, noticed lower heart-rate..."
                      className="w-full p-1.5 border border-slate-200 dark:border-slate-800 rounded bg-transparent"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  id="submit-product-review"
                  className="bg-emerald-800 hover:bg-emerald-700 text-white text-[10px] px-3 py-1.5 rounded font-bold uppercase"
                >
                  Submit Review
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Checkout Modal Overlay */}
      {showCheckoutModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <form onSubmit={handleInitiatePaymentStep} className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 md:p-8 space-y-4 shadow-2xl border border-emerald-900/10 dark:border-white/5">
            <h4 className="font-serif text-base font-bold text-emerald-950 dark:text-white border-b border-slate-100 dark:border-white/10 pb-3 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-blue-500" /> Secure Shipping Checkout
            </h4>

            <div className="space-y-2 bg-slate-50 dark:bg-slate-850 p-4 rounded-xl text-xs text-slate-600 dark:text-slate-300">
              <div className="flex justify-between">
                <span>Items in Cart:</span>
                <span className="font-bold">{cart.length}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-emerald-900 dark:text-emerald-400 border-t border-slate-200/40 pt-1.5 mt-1">
                <span>Amount Due:</span>
                <span>₹{cartTotal}</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Enter Shipping Address</label>
              <textarea
                required
                value={shippingAddress}
                onChange={(e) => setShippingAddress(e.target.value)}
                placeholder="Write your complete mailing address (with PIN/Zip code) for delivery..."
                rows={3}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            {/* Gateway Configuration Selector */}
            <div className="space-y-2 border-t border-slate-100 dark:border-white/10 pt-3">
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Gateway Configuration</label>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <button
                  type="button"
                  onClick={() => setUseRealSdk(false)}
                  className={`p-2 rounded-lg border text-center font-bold transition-all ${
                    !useRealSdk 
                      ? 'border-blue-500 bg-blue-500/5 text-blue-600 dark:text-blue-400' 
                      : 'border-slate-200 dark:border-slate-800 text-slate-500'
                  }`}
                >
                  Razorpay Portal
                </button>
                <button
                  type="button"
                  disabled={!sdkAvailable}
                  onClick={() => setUseRealSdk(true)}
                  className={`p-2 rounded-lg border text-center font-bold transition-all ${
                    useRealSdk 
                      ? 'border-emerald-500 bg-emerald-500/5 text-emerald-600 dark:text-emerald-400' 
                      : sdkAvailable 
                        ? 'border-slate-200 dark:border-slate-800 text-slate-500 hover:border-slate-300' 
                        : 'border-slate-100 dark:border-slate-900 text-slate-300 dark:text-slate-700 cursor-not-allowed'
                  }`}
                  title={sdkAvailable ? 'Use official Razorpay JS library popup' : 'Standard Web SDK unavailable inside this preview frame'}
                >
                  Razorpay Web SDK
                </button>
              </div>
              {!sdkAvailable && (
                <p className="text-[9px] text-slate-400 italic">
                  Note: Razorpay JS client is sandboxed. Fallback portal simulator is active by default.
                </p>
              )}
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="submit"
                id="confirm-place-order-btn"
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md active:translate-y-[1px] transition-all"
              >
                <Lock className="w-3.5 h-3.5" /> Proceed to Razorpay Payment
              </button>
              <button
                type="button"
                onClick={() => setShowCheckoutModal(false)}
                className="w-full py-2 bg-slate-100 dark:bg-slate-800 text-xs rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Razorpay Interactive Secure Portal Modal */}
      {showRazorpayPortal && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-50 dark:bg-slate-950 rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row h-auto md:h-[550px] relative">
            
            {/* Left Column / Sidebar - Brand & Method Selectors */}
            <div className="w-full md:w-5/12 bg-[#141b29] text-white p-5 flex flex-col justify-between border-b md:border-b-0 md:border-r border-slate-800">
              <div className="space-y-4">
                {/* Brand Header */}
                <div className="flex items-center gap-2">
                  <div className="bg-blue-600 w-8 h-8 rounded-lg text-white font-black text-sm tracking-wider flex items-center justify-center shadow-inner">
                    R
                  </div>
                  <div>
                    <h4 className="font-sans font-bold text-[10px] tracking-wider uppercase text-slate-400">Certified Remedies</h4>
                    <p className="font-serif text-sm font-bold text-white">Cosmic Checkout</p>
                  </div>
                </div>

                {/* Amount Due Indicator */}
                <div className="bg-slate-900/40 p-4 rounded-xl border border-white/5 space-y-1">
                  <span className="text-[9px] text-slate-400 uppercase tracking-widest font-semibold block">Total Amount Payable</span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-xl font-black text-white">₹{cartTotal}</span>
                    <span className="text-[10px] text-slate-500 font-mono">INR</span>
                  </div>
                </div>

                {/* Method Options Selector */}
                <div className="space-y-2 pt-2">
                  <span className="text-[9px] text-slate-500 uppercase tracking-widest font-bold block">Select Payment Mode</span>
                  
                  <button
                    onClick={() => { setRazorpayMethod('card'); setPaymentStep('input'); }}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl text-left text-xs transition-all ${
                      razorpayMethod === 'card' 
                        ? 'bg-blue-600/15 border border-blue-500 text-blue-400 font-bold' 
                        : 'hover:bg-white/5 border border-transparent text-slate-400'
                    }`}
                  >
                    <CreditCard className="w-4 h-4" />
                    <span>Card (Credit / Debit)</span>
                  </button>

                  <button
                    onClick={() => { setRazorpayMethod('upi'); setPaymentStep('input'); }}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl text-left text-xs transition-all ${
                      razorpayMethod === 'upi' 
                        ? 'bg-blue-600/15 border border-blue-500 text-blue-400 font-bold' 
                        : 'hover:bg-white/5 border border-transparent text-slate-400'
                    }`}
                  >
                    <QrCode className="w-4 h-4" />
                    <span>UPI / QR Code</span>
                  </button>

                  <button
                    onClick={() => { setRazorpayMethod('netbanking'); setPaymentStep('input'); }}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl text-left text-xs transition-all ${
                      razorpayMethod === 'netbanking' 
                        ? 'bg-blue-600/15 border border-blue-500 text-blue-400 font-bold' 
                        : 'hover:bg-white/5 border border-transparent text-slate-400'
                    }`}
                  >
                    <Building className="w-4 h-4" />
                    <span>Netbanking</span>
                  </button>

                  <button
                    onClick={() => { setRazorpayMethod('wallet'); setPaymentStep('input'); }}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl text-left text-xs transition-all ${
                      razorpayMethod === 'wallet' 
                        ? 'bg-blue-600/15 border border-blue-500 text-blue-400 font-bold' 
                        : 'hover:bg-white/5 border border-transparent text-slate-400'
                    }`}
                  >
                    <Wallet className="w-4 h-4" />
                    <span>Mobile Wallets</span>
                  </button>
                </div>
              </div>

              {/* Secure payment watermark */}
              <div className="hidden md:flex items-center gap-1.5 text-slate-500 text-[10px] mt-4">
                <Lock className="w-3.5 h-3.5" />
                <span>Secure Payment by Razorpay</span>
              </div>
            </div>

            {/* Right Column - Multi-Step Interactive Payment Desk */}
            <div className="flex-1 bg-white dark:bg-slate-900 p-6 flex flex-col justify-between h-full text-slate-800 dark:text-slate-100 relative min-h-[380px]">
              
              {/* Close Button */}
              <button 
                onClick={() => setShowRazorpayPortal(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              {paymentStep === 'input' && (
                <form onSubmit={handleInitiateSimulatedPay} className="flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    <h3 className="font-serif text-base font-bold text-slate-900 dark:text-white mb-1">
                      {razorpayMethod === 'card' && 'Enter Card Credentials'}
                      {razorpayMethod === 'upi' && 'UPI Unified Interface'}
                      {razorpayMethod === 'netbanking' && 'Choose Bank Account'}
                      {razorpayMethod === 'wallet' && 'Select Online Wallet'}
                    </h3>
                    <p className="text-[11px] text-slate-500 mb-4">
                      {razorpayMethod === 'card' && 'Securely pay using Visa, Mastercard, RuPay, or Amex.'}
                      {razorpayMethod === 'upi' && 'Pay directly via scan-to-pay QR or instant UPI ID handle.'}
                      {razorpayMethod === 'netbanking' && 'Select your preferred banking node to authorize settlement.'}
                      {razorpayMethod === 'wallet' && 'Link and authorize direct payments using top mobile wallets.'}
                    </p>

                    {/* Method specific inputs */}
                    {razorpayMethod === 'card' && (
                      <div className="space-y-3">
                        <div className="relative">
                          <label className="block text-[10px] font-semibold text-slate-500 uppercase mb-1">Card Number</label>
                          <input
                            type="text"
                            required
                            placeholder="4111 1111 1111 1111 (Visa Test)"
                            value={cardNumber}
                            onChange={handleCardNumberChange}
                            className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-xs font-mono focus:ring-1 focus:ring-blue-500 focus:outline-none pr-10"
                          />
                          <div className="absolute right-3 bottom-2.5">
                            {getCardBrand(cardNumber) === 'Visa' && <span className="text-blue-600 font-bold font-mono text-xs">VISA</span>}
                            {getCardBrand(cardNumber) === 'Mastercard' && <span className="text-red-500 font-bold font-mono text-xs">MC</span>}
                            {getCardBrand(cardNumber) === 'American Express' && <span className="text-cyan-500 font-bold font-mono text-xs">AMEX</span>}
                            {getCardBrand(cardNumber) === 'Generic' && <CreditCard className="w-4 h-4 text-slate-400" />}
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] font-semibold text-slate-500 uppercase mb-1">Expiry Date</label>
                            <input
                              type="text"
                              required
                              placeholder="MM/YY"
                              value={cardExpiry}
                              onChange={handleExpiryChange}
                              className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-xs font-mono focus:ring-1 focus:ring-blue-500 focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-semibold text-slate-500 uppercase mb-1">Security CVV</label>
                            <input
                              type="password"
                              required
                              placeholder="•••"
                              value={cardCvv}
                              onChange={handleCvvChange}
                              className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-xs font-mono focus:ring-1 focus:ring-blue-500 focus:outline-none"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[10px] font-semibold text-slate-500 uppercase mb-1">Cardholder Name</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Amit Sharma"
                            value={cardName}
                            onChange={(e) => setCardName(e.target.value)}
                            className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                          />
                        </div>
                      </div>
                    )}

                    {razorpayMethod === 'upi' && (
                      <div className="space-y-4">
                        <div className="flex gap-4 border-b border-slate-100 dark:border-slate-800 pb-2 text-xs">
                          <button
                            type="button"
                            onClick={() => setQrCodeScanned(false)}
                            className={`pb-1 font-bold ${!qrCodeScanned ? 'text-blue-500 border-b-2 border-blue-500' : 'text-slate-400'}`}
                          >
                            UPI QR Code Scan
                          </button>
                          <button
                            type="button"
                            onClick={() => setQrCodeScanned(true)}
                            className={`pb-1 font-bold ${qrCodeScanned ? 'text-blue-500 border-b-2 border-blue-500' : 'text-slate-400'}`}
                          >
                            Pay via UPI ID
                          </button>
                        </div>

                        {!qrCodeScanned ? (
                          <div className="flex flex-col items-center space-y-3">
                            <div className="p-3 bg-white border border-slate-200 rounded-xl shadow-inner relative group">
                              <div className="w-32 h-32 flex items-center justify-center bg-slate-50 rounded border border-slate-100 p-1">
                                {/* Simulated Elegant QR Code SVG */}
                                <svg className="w-full h-full text-slate-900" viewBox="0 0 100 100">
                                  <rect width="100" height="100" fill="none" />
                                  <path d="M5 5h25v25H5zm0 40h25v25H5zm40-40h25v25H45z" fill="currentColor" />
                                  <path d="M10 10h15v15H10zm0 40h15v15H10zm40-40h15v15H40z" fill="white" />
                                  <path d="M30 30h40M10 70h60M35 15h5M75 10h15v15H75zm5 5h5v5h-5zm-15 35h15v15H65zm5 5h5v5h-5z" stroke="currentColor" strokeWidth="2" fill="none" />
                                  <path d="M20 20h5v5h-5zm0 40h5v5h-5zm40-40h5v5h-5zm10 50h20v20H70z" fill="currentColor" />
                                  <circle cx="50" cy="50" r="10" className="fill-blue-500 text-white" />
                                  <path d="M47 50l2 2l4-4" stroke="white" strokeWidth="2" strokeLinecap="round" fill="none" />
                                </svg>
                              </div>
                            </div>
                            
                            <div className="text-center space-y-1">
                              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Scan with Google Pay, PhonePe, Bhim</span>
                              <div className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                                QR Code Expires in <span className="font-mono text-red-500 font-bold">{formatQrTime(qrTimer)}</span>
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={() => {
                                setQrCodeScanned(true);
                                setPaymentStep('processing');
                                setPaymentProgress("Reading UPI dynamic payload sequence...");
                                setTimeout(() => {
                                  setPaymentStep('otp');
                                }, 1200);
                              }}
                              className="px-4 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-600 rounded-full text-[10px] font-bold uppercase tracking-wider transition-colors border border-emerald-500/20"
                            >
                              Simulate Scanner Captured Success
                            </button>
                          </div>
                        ) : (
                          <div className="space-y-2 py-4">
                            <label className="block text-[10px] font-semibold text-slate-500 uppercase mb-1">Enter UPI Handle</label>
                            <input
                              type="text"
                              placeholder="username@okhdfcbank"
                              value={upiId}
                              onChange={(e) => setUpiId(e.target.value)}
                              className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-xs font-mono focus:ring-1 focus:ring-blue-500 focus:outline-none"
                            />
                            <p className="text-[10px] text-slate-400">Standard test UPI triggers instant verification node.</p>
                          </div>
                        )}
                      </div>
                    )}

                    {razorpayMethod === 'netbanking' && (
                      <div className="space-y-3">
                        <label className="block text-[10px] font-semibold text-slate-500 uppercase mb-1">Popular Indian Banks</label>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          {['SBI', 'HDFC', 'ICICI', 'Axis', 'Kotak', 'PNB'].map((bank) => (
                            <button
                              key={bank}
                              type="button"
                              onClick={() => setSelectedBank(bank)}
                              className={`flex items-center justify-between p-2.5 rounded-lg border text-left transition-all ${
                                selectedBank === bank 
                                  ? 'border-blue-500 bg-blue-500/5 text-blue-600 dark:text-blue-400 font-bold shadow-sm' 
                                  : 'border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-850 text-slate-600 dark:text-slate-300'
                              }`}
                            >
                              <span className="font-mono text-[10px] font-black tracking-widest">{bank}</span>
                              <span className="text-[10px] font-semibold">
                                {bank === 'SBI' && 'State Bank'}
                                {bank === 'HDFC' && 'HDFC Bank'}
                                {bank === 'ICICI' && 'ICICI Node'}
                                {bank === 'Axis' && 'Axis Axis'}
                                {bank === 'Kotak' && 'Kotak Mah.'}
                                {bank === 'PNB' && 'Punjab Nat.'}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {razorpayMethod === 'wallet' && (
                      <div className="space-y-3">
                        <label className="block text-[10px] font-semibold text-slate-500 uppercase mb-1">Select Mobile Wallet</label>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          {['PhonePe', 'Paytm', 'Amazon Pay', 'MobiKwik'].map((wallet) => (
                            <button
                              key={wallet}
                              type="button"
                              onClick={() => setSelectedWallet(wallet)}
                              className={`flex items-center justify-between p-2.5 rounded-lg border text-left transition-all ${
                                selectedWallet === wallet 
                                  ? 'border-blue-500 bg-blue-500/5 text-blue-600 dark:text-blue-400 font-bold shadow-sm' 
                                  : 'border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-850 text-slate-600 dark:text-slate-300'
                              }`}
                            >
                              <span className="font-bold">{wallet}</span>
                              <span className="text-[9px] uppercase tracking-widest text-slate-400 font-mono">Linked</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="space-y-3 border-t border-slate-100 dark:border-slate-800 pt-4">
                    <button
                      type="submit"
                      className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md shadow-blue-500/20 active:translate-y-[1px] transition-all"
                    >
                      <ShieldCheck className="w-4 h-4" /> Secure Pay ₹{cartTotal}
                    </button>
                    <div className="flex justify-center items-center gap-1 text-[10px] text-slate-400">
                      <Lock className="w-3.5 h-3.5" /> Secure 256-Bit SSL Encryption Nodes
                    </div>
                  </div>
                </form>
              )}

              {paymentStep === 'processing' && (
                <div className="flex-1 flex flex-col items-center justify-center space-y-4 py-8">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-full border-4 border-blue-100 dark:border-slate-800 border-t-blue-500 animate-spin"></div>
                    <Lock className="w-5 h-5 text-blue-500 absolute inset-0 m-auto animate-pulse" />
                  </div>
                  <div className="text-center max-w-sm space-y-1.5">
                    <h4 className="font-serif text-sm font-bold text-slate-900 dark:text-white">Transaction Authorizing</h4>
                    <p className="text-xs text-slate-500 font-mono animate-pulse">{paymentProgress}</p>
                  </div>
                </div>
              )}

              {paymentStep === 'otp' && (
                <form onSubmit={handleVerifyOtpSubmit} className="flex-1 flex flex-col justify-between py-4">
                  <div className="space-y-4">
                    <div className="text-center space-y-1.5">
                      <div className="mx-auto w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-950/40 flex items-center justify-center text-blue-600">
                        <Smartphone className="w-5 h-5" />
                      </div>
                      <h3 className="font-serif text-base font-bold text-slate-900 dark:text-white">Verify Dynamic OTP Code</h3>
                      <p className="text-xs text-slate-500 max-w-xs mx-auto">
                        A 6-digit dynamic passcode has been transmitted to your mobile. Enter below to complete authorization.
                      </p>
                    </div>

                    <div className="max-w-xs mx-auto space-y-2">
                      <input
                        type="text"
                        maxLength={6}
                        required
                        placeholder="e.g. 123456"
                        value={otpInput}
                        onChange={(e) => setOtpInput(e.target.value.replace(/\D/g, ''))}
                        className="w-full text-center p-3 rounded-xl border border-slate-300 dark:border-slate-800 bg-transparent text-lg font-black tracking-widest focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      />
                      {otpError && <p className="text-[10px] text-red-500 text-center font-semibold">{otpError}</p>}
                      <p className="text-[10px] text-slate-400 text-center italic">
                        Test Mode Authorization: Enter any 6-digit number to bypass bank node.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                    <button
                      type="submit"
                      className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md active:translate-y-[1px] transition-all"
                    >
                      Verify Passcode & Pay
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPaymentStep('input');
                      }}
                      className="w-full py-1.5 text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase hover:underline"
                    >
                      Aborted & Modify Method
                    </button>
                  </div>
                </form>
              )}

              {paymentStep === 'success' && (
                <div className="flex-1 flex flex-col items-center justify-center space-y-4 py-8">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/40 flex items-center justify-center text-emerald-600 animate-bounce">
                    <CheckCircle className="w-10 h-10" />
                  </div>
                  <div className="text-center space-y-1">
                    <h4 className="font-serif text-base font-bold text-slate-900 dark:text-white">Transaction Captured Successfully!</h4>
                    <p className="text-xs text-slate-500">Invoice successfully recorded. Thank you for shopping with us.</p>
                    <p className="text-[9px] font-mono text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded mt-2 inline-block">
                      Merchant Token Settled
                    </p>
                  </div>
                </div>
              )}

            </div>

          </div>
        </div>
      )}

    </div>
  );
}
