import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  MessageSquare, 
  X, 
  AlertCircle, 
  Bot, 
  ArrowUpRight 
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

export default function AiMentorBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: 'm1', role: 'assistant', content: "Welcome! I am **HRCM AI MENTOR**, calibrated by founder **Nabin K. Choudhary**. I can answer any educational questions about Vedic Astrology, Chaldean Numerology, Vastu/Medical Vastu zones, sacred Rudraksha beads, or simple mental wellness screening exercises.\n\n*How can I assist your spiritual-scientific journey today?*" }
  ]);
  const [input, setInput] = useState('');
  const [isSending, setIsSending] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToEnd = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToEnd();
    }
  }, [messages, isOpen]);

  // Quick prompt buttons
  const quickPrompts = [
    "What are 5 Mukhi Rudraksha benefits?",
    "Explain North-East Vastu toilet remedy",
    "How does Chaldean Name Correction work?",
    "How to manage anxiety with breathing?"
  ];

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isSending) return;

    const userMsg: ChatMessage = {
      id: Math.random().toString(36).substring(2, 10),
      role: 'user',
      content: textToSend
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsSending(true);

    try {
      const response = await fetch('/api/ai-mentor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [...messages, userMsg].map(m => ({ role: m.role, content: m.content })) })
      });

      const data = await response.json();
      const assistantMsg: ChatMessage = {
        id: Math.random().toString(36).substring(2, 10),
        role: 'assistant',
        content: data.response || "My apologies, but my connection to the premium Gemini AI servers is not fully configured yet."
      };
      setMessages(prev => [...prev, assistantMsg]);
    } catch (err) {
      console.error(err);
      const errMsg: ChatMessage = {
        id: Math.random().toString(36).substring(2, 10),
        role: 'assistant',
        content: "Error communicating with our AI Mentor proxy. Please verify your internet connection and try again."
      };
      setMessages(prev => [...prev, errMsg]);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <>
      {/* Floating Badge Toggle Button */}
      <button
        id="floating-ai-mentor-badge"
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-50 p-4 bg-emerald-900 hover:bg-emerald-800 text-amber-400 rounded-full shadow-2xl flex items-center justify-center border-2 border-amber-500 animate-pulse transition-all group"
        title="Chat with HRCM AI Mentor"
      >
        <Bot className="w-7 h-7 group-hover:scale-110 transition-transform" />
      </button>

      {/* Slide-out Sidebar Panel */}
      {isOpen && (
        <div id="ai-mentor-drawer" className="fixed bottom-24 right-6 z-50 w-[350px] sm:w-[400px] h-[550px] bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-emerald-900/20 dark:border-white/5 flex flex-col justify-between overflow-hidden">
          
          {/* Header */}
          <div className="p-4 bg-emerald-900 text-white flex justify-between items-center border-b border-amber-500/20">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <div>
                <h4 className="font-serif font-bold text-sm tracking-wide">HRCM AI MENTOR</h4>
                <p className="text-[10px] text-slate-300">Siddha Intelligence • Online</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-slate-300 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Clinical educational Warning Disclaimer */}
          <div className="p-3 bg-amber-500/10 text-amber-800 dark:text-amber-400 border-b border-amber-500/20 text-[10px] leading-relaxed flex gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0 text-amber-500 animate-bounce" />
            <p><strong>Disclaimer:</strong> AI Mentor provides educational insights only. No emergency medical diagnosis or treatment advice is given.</p>
          </div>

          {/* Chat Messages Log */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50/50 dark:bg-slate-950/20 text-xs scrollbar">
            {messages.map((m) => (
              <div 
                key={m.id}
                className={`flex gap-2 max-w-[85%] ${m.role === 'user' ? 'ml-auto flex-row-reverse' : ''}`}
              >
                {/* Avatar icon */}
                <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-[10px] ${m.role === 'user' ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-emerald-900 text-white'}`}>
                  {m.role === 'user' ? 'U' : <Bot className="w-3.5 h-3.5 text-amber-400" />}
                </div>

                <div className={`p-3 rounded-2xl leading-relaxed text-xs ${
                  m.role === 'user' 
                    ? 'bg-emerald-900 text-white rounded-tr-none font-medium' 
                    : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-tl-none border border-slate-150'
                }`}>
                  {/* Super simple markdown parser fallback */}
                  <p className="whitespace-pre-wrap">
                    {m.content.split('**').map((chunk, i) => i % 2 === 1 ? <strong key={i} className="text-amber-600 dark:text-amber-400">{chunk}</strong> : chunk)}
                  </p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Prompts Row */}
          <div className="p-2 border-t border-slate-150 bg-white dark:bg-slate-900 flex gap-1.5 overflow-x-auto scrollbar">
            {quickPrompts.map((prompt, i) => (
              <button
                key={i}
                onClick={() => handleSendMessage(prompt)}
                className="px-3 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-[10px] rounded-full whitespace-nowrap text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Input Area */}
          <form 
            onSubmit={(e) => { e.preventDefault(); handleSendMessage(input); }}
            className="p-3 border-t border-slate-150 bg-white dark:bg-slate-900 flex gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about Astrology, Chaldean Numerology, Vastu..."
              className="flex-1 p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-xs bg-transparent focus:outline-none"
            />
            <button
              type="submit"
              id="send-message-btn"
              disabled={isSending}
              className="p-2 bg-emerald-900 text-white hover:bg-emerald-800 rounded-lg flex items-center justify-center"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>
      )}
    </>
  );
}
