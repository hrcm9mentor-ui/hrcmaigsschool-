import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  User as FirebaseUser,
  GoogleAuthProvider,
  signInWithPopup
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where, 
  updateDoc,
  deleteDoc
} from 'firebase/firestore';
import { UserProfile, DoctorProfile, Appointment, Order, Course, WishlistItem } from '../types';

const firebaseConfig = {
  projectId: "hrcm-mentor-902ba",
  appId: "1:153345059114:web:4364820db625d1b3ef5653",
  apiKey: "AIzaSyDLYkEHRvBkXn2AEL8_EU-__h6f1ALynDo",
  authDomain: "hrcm-mentor-902ba.firebaseapp.com",
  databaseId: "ai-studio-3d2099d8-5ecd-4ba8-b5a0-c7a00952662f",
  storageBucket: "hrcm-mentor-902ba.firebasestorage.app",
  messagingSenderId: "153345059114"
};

// Initialize Firebase
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app, "ai-studio-3d2099d8-5ecd-4ba8-b5a0-c7a00952662f");

// Helper to fetch or create user profiles
export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  try {
    const docRef = doc(db, 'users', uid);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data() as UserProfile;
    }
  } catch (error) {
    console.error("Error getting user profile:", error);
  }
  return null;
}

export async function createUserProfile(uid: string, email: string, displayName: string, role: 'user' | 'doctor' | 'student' | 'admin' = 'user'): Promise<UserProfile> {
  const profile: UserProfile = {
    uid,
    email,
    displayName,
    role,
    createdAt: new Date().toISOString()
  };
  try {
    await setDoc(doc(db, 'users', uid), profile);
  } catch (error) {
    console.error("Error creating user profile in Firestore:", error);
  }
  return profile;
}

// Check if user is registered as a doctor and get their doctor record
export async function getDoctorProfile(uid: string): Promise<DoctorProfile | null> {
  try {
    const docSnap = await getDoc(doc(db, 'doctors', uid));
    if (docSnap.exists()) {
      return docSnap.data() as DoctorProfile;
    }
  } catch (err) {
    console.error("Error getting doctor profile:", err);
  }
  return null;
}

// Book an appointment
export async function createAppointment(appointment: Omit<Appointment, 'id' | 'createdAt'>): Promise<string> {
  const apptData = {
    ...appointment,
    createdAt: new Date().toISOString()
  };
  const docRef = await addDoc(collection(db, 'appointments'), apptData);
  // Return the newly created ID
  await updateDoc(doc(db, 'appointments', docRef.id), { id: docRef.id });
  return docRef.id;
}

// Fetch user appointments
export async function getUserAppointments(uid: string, role: 'user' | 'doctor'): Promise<Appointment[]> {
  try {
    const field = role === 'doctor' ? 'doctorId' : 'userId';
    const q = query(collection(db, 'appointments'), where(field, '==', uid));
    const querySnapshot = await getDocs(q);
    const appointments: Appointment[] = [];
    querySnapshot.forEach((doc) => {
      appointments.push(doc.data() as Appointment);
    });
    // Sort by date/time descending
    return appointments.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  } catch (error) {
    console.error("Error fetching appointments:", error);
    return [];
  }
}

// Doctors list (approved only, or all)
export async function getDoctorsList(onlyApproved = true): Promise<DoctorProfile[]> {
  try {
    const q = onlyApproved 
      ? query(collection(db, 'doctors'), where('approved', '==', true))
      : collection(db, 'doctors');
    const querySnapshot = await getDocs(q);
    const doctors: DoctorProfile[] = [];
    querySnapshot.forEach((doc) => {
      doctors.push(doc.data() as DoctorProfile);
    });
    return doctors;
  } catch (error) {
    console.error("Error fetching doctors:", error);
    return [];
  }
}

// Place e-commerce order
export async function createOrder(order: Omit<Order, 'id' | 'createdAt'>): Promise<string> {
  const orderData = {
    ...order,
    createdAt: new Date().toISOString()
  };
  const docRef = await addDoc(collection(db, 'orders'), orderData);
  await updateDoc(doc(db, 'orders', docRef.id), { id: docRef.id });
  return docRef.id;
}

// Fetch user orders
export async function getUserOrders(uid: string): Promise<Order[]> {
  try {
    const q = query(collection(db, 'orders'), where('userId', '==', uid));
    const querySnapshot = await getDocs(q);
    const orders: Order[] = [];
    querySnapshot.forEach((doc) => {
      orders.push(doc.data() as Order);
    });
    return orders.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  } catch (error) {
    console.error("Error fetching orders:", error);
    return [];
  }
}

// Error handling types and helpers matching Firebase integration guidelines
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Helper to update a user's profile
export async function updateUserProfile(uid: string, updates: Partial<UserProfile>): Promise<void> {
  const docPath = `users/${uid}`;
  try {
    const docRef = doc(db, 'users', uid);
    await setDoc(docRef, updates, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, docPath);
  }
}

// Helper to update appointment statuses (e.g. by doctors or users)
export async function updateAppointmentStatus(
  id: string, 
  status: 'pending' | 'accepted' | 'rejected' | 'completed',
  prescription?: string,
  meetingLink?: string
): Promise<void> {
  const docPath = `appointments/${id}`;
  try {
    const docRef = doc(db, 'appointments', id);
    const updates: Record<string, any> = { status };
    if (prescription !== undefined) updates.prescription = prescription;
    if (meetingLink !== undefined) updates.meetingLink = meetingLink;
    await setDoc(docRef, updates, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, docPath);
  }
}

// Fetch all users (Admin only)
export async function getAllUsers(): Promise<UserProfile[]> {
  const docPath = 'users';
  try {
    const q = collection(db, 'users');
    const querySnapshot = await getDocs(q);
    const users: UserProfile[] = [];
    querySnapshot.forEach((doc) => {
      users.push(doc.data() as UserProfile);
    });
    return users.sort((a, b) => {
      const dateA = a.createdAt || '';
      const dateB = b.createdAt || '';
      return dateB.localeCompare(dateA);
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, docPath);
    return [];
  }
}

// Fetch all appointments (Admin only)
export async function getAllAppointments(): Promise<Appointment[]> {
  const docPath = 'appointments';
  try {
    const q = collection(db, 'appointments');
    const querySnapshot = await getDocs(q);
    const appointments: Appointment[] = [];
    querySnapshot.forEach((doc) => {
      appointments.push(doc.data() as Appointment);
    });
    return appointments.sort((a, b) => {
      const dateA = a.createdAt || '';
      const dateB = b.createdAt || '';
      return dateB.localeCompare(dateA);
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, docPath);
    return [];
  }
}

// Fetch all orders (Admin only)
export async function getAllOrders(): Promise<Order[]> {
  const docPath = 'orders';
  try {
    const q = collection(db, 'orders');
    const querySnapshot = await getDocs(q);
    const orders: Order[] = [];
    querySnapshot.forEach((doc) => {
      orders.push(doc.data() as Order);
    });
    return orders.sort((a, b) => {
      const dateA = a.createdAt || '';
      const dateB = b.createdAt || '';
      return dateB.localeCompare(dateA);
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, docPath);
    return [];
  }
}

// Delete user document (Admin only)
export async function adminDeleteUser(uid: string): Promise<void> {
  const docPath = `users/${uid}`;
  try {
    const docRef = doc(db, 'users', uid);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, docPath);
  }
}

// Add product to user's wishlist
export async function addToWishlist(uid: string, item: Omit<WishlistItem, 'addedAt'>): Promise<void> {
  const docPath = `users/${uid}/wishlist/${item.productId}`;
  try {
    const docRef = doc(db, 'users', uid, 'wishlist', item.productId);
    const wishlistItem: WishlistItem = {
      ...item,
      addedAt: new Date().toISOString()
    };
    await setDoc(docRef, wishlistItem);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, docPath);
  }
}

// Remove product from user's wishlist
export async function removeFromWishlist(uid: string, productId: string): Promise<void> {
  const docPath = `users/${uid}/wishlist/${productId}`;
  try {
    const docRef = doc(db, 'users', uid, 'wishlist', productId);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, docPath);
  }
}

// Fetch user's wishlist
export async function getUserWishlist(uid: string): Promise<WishlistItem[]> {
  const docPath = `users/${uid}/wishlist`;
  try {
    const q = collection(db, 'users', uid, 'wishlist');
    const querySnapshot = await getDocs(q);
    const wishlist: WishlistItem[] = [];
    querySnapshot.forEach((doc) => {
      wishlist.push(doc.data() as WishlistItem);
    });
    // Sort by addedAt descending
    return wishlist.sort((a, b) => b.addedAt.localeCompare(a.addedAt));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, docPath);
    return [];
  }
}

