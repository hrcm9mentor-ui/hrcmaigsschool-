import React, { useState } from 'react';
import { 
  BookOpen, 
  Play, 
  FileText, 
  Award, 
  HelpCircle, 
  CheckCircle, 
  Search, 
  ArrowLeft, 
  Star,
  Download,
  BookmarkCheck
} from 'lucide-react';
import { INITIAL_COURSES } from '../data';
import { Course, CourseVideo } from '../types';

export default function CoursePortal() {
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [activeVideo, setActiveVideo] = useState<CourseVideo | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Quiz progress states
  const [currentQuizIdx, setCurrentQuizIdx] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  // Certificate states
  const [certificateStudentName, setCertificateStudentName] = useState('');
  const [showCertificate, setShowCertificate] = useState(false);

  // Filtered courses
  const filteredCourses = INITIAL_COURSES.filter(course => 
    course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    course.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const startQuiz = () => {
    if (!selectedCourse) return;
    setQuizAnswers(new Array(selectedCourse.quizzes.length).fill(-1));
    setCurrentQuizIdx(0);
    setQuizCompleted(false);
    setQuizScore(0);
  };

  const handleSelectQuizOption = (optionIdx: number) => {
    const updated = [...quizAnswers];
    updated[currentQuizIdx] = optionIdx;
    setQuizAnswers(updated);
  };

  const nextQuizQuestion = () => {
    if (!selectedCourse) return;
    if (currentQuizIdx < selectedCourse.quizzes.length - 1) {
      setCurrentQuizIdx(currentQuizIdx + 1);
    } else {
      // Calculate final score
      let correctCount = 0;
      quizAnswers.forEach((ans, idx) => {
        if (ans === selectedCourse.quizzes[idx].answerIndex) {
          correctCount++;
        }
      });
      setQuizScore(correctCount);
      setQuizCompleted(true);
    }
  };

  return (
    <div id="courses-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 dark:text-white">
      
      {/* Search & Header (Only visible if no course selected) */}
      {!selectedCourse ? (
        <div className="space-y-8">
          <div className="text-center max-w-3xl mx-auto space-y-4">
            <h2 className="font-serif text-3xl md:text-4xl font-extrabold text-emerald-950 dark:text-white">
              Siddha Academy & Premium Courses
            </h2>
            <p className="text-slate-600 dark:text-slate-400">
              Join thousands of spiritual practitioners studying Chaldean numerology, medical vastu, and cosmological sciences from Master Nabin K. Choudhary.
            </p>
          </div>

          {/* Search bar */}
          <div className="max-w-md mx-auto relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search courses (e.g. Vastu, Numerology)..."
              className="w-full pl-10 pr-4 py-3 rounded-full border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
          </div>

          {/* Course Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredCourses.map((course) => (
              <div 
                key={course.id}
                className="bg-white dark:bg-slate-900 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all border border-slate-100 dark:border-white/5 flex flex-col h-full"
              >
                <div className="h-44 overflow-hidden relative">
                  <img 
                    src={course.imageUrl} 
                    alt={course.title} 
                    className="w-full h-full object-cover hover:scale-105 transition-transform"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute top-3 right-3 bg-emerald-900 text-white text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full border border-amber-500/20">
                    {course.duration}
                  </span>
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs text-slate-500">
                      <span className="capitalize font-semibold text-emerald-700 dark:text-emerald-400">{course.category}</span>
                      <span className="flex items-center gap-1 text-amber-500">
                        <Star className="w-3.5 h-3.5 fill-amber-500" /> {course.rating}
                      </span>
                    </div>

                    <h3 className="font-serif font-bold text-emerald-950 dark:text-white leading-tight">
                      {course.title}
                    </h3>

                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                      {course.description}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-slate-100 dark:border-white/5 flex justify-between items-center">
                    <span className="font-serif font-bold text-emerald-900 dark:text-emerald-400 text-base">
                      ₹{course.price}
                    </span>
                    <button
                      id={`enroll-${course.id}`}
                      onClick={() => {
                        setSelectedCourse(course);
                        setActiveVideo(course.videos[0] || null);
                        setShowCertificate(false);
                        setQuizCompleted(false);
                      }}
                      className="bg-emerald-900 dark:bg-emerald-600 hover:bg-emerald-800 text-white text-xs font-bold px-4 py-2 rounded-lg"
                    >
                      Enter Course
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Course Detail / Learning System Workspace */
        <div className="space-y-6">
          
          {/* Back Header */}
          <div className="flex justify-between items-center">
            <button
              id="back-to-courses"
              onClick={() => setSelectedCourse(null)}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-900 dark:text-emerald-400 hover:underline"
            >
              <ArrowLeft className="w-4 h-4" /> Back to Course Library
            </button>
            <span className="text-xs font-mono text-slate-500 uppercase tracking-widest bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full">
              Academy Portal • Live
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Workspace: Active Video Streaming / Quiz / Certificate */}
            <div className="lg:col-span-8 space-y-6">
              
              {/* Conditional Stream Video View */}
              {!showCertificate && !quizCompleted && activeVideo && (
                <div className="bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border border-white/5">
                  <div className="aspect-video w-full relative">
                    {/* Standard HTML5 Streaming Video Player with styled skin */}
                    <video 
                      key={activeVideo.id}
                      controls
                      autoPlay={false}
                      className="w-full h-full"
                    >
                      <source src={activeVideo.videoUrl} type="video/mp4" />
                      Your browser does not support HTML5 video player.
                    </video>
                  </div>
                  <div className="p-6 bg-slate-950 text-white space-y-2">
                    <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-amber-500 flex items-center gap-1">
                      <Play className="w-3 h-3 fill-amber-500 text-amber-500" /> Active Video Segment
                    </span>
                    <h3 className="font-serif text-lg font-bold">{activeVideo.title}</h3>
                    <p className="text-xs text-slate-400">Duration: {activeVideo.duration} • Instructed by Nabin K. Choudhary</p>
                  </div>
                </div>
              )}

              {/* Conditional Quiz Workspace */}
              {quizCompleted && selectedCourse && (
                <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-xl border border-emerald-900/10 dark:border-white/5 text-center space-y-6">
                  <div className="inline-flex flex-col items-center justify-center w-24 h-24 rounded-full border-4 border-amber-500 bg-amber-50 dark:bg-slate-950">
                    <span className="text-xs text-slate-500 uppercase font-bold">Passed</span>
                    <span className="text-3xl font-bold text-emerald-900 dark:text-emerald-400">{quizScore} / {selectedCourse.quizzes.length}</span>
                  </div>

                  <div className="max-w-md mx-auto space-y-3">
                    <h3 className="font-serif text-xl font-bold text-emerald-950 dark:text-white">
                      {quizScore === selectedCourse.quizzes.length ? 'Outstanding Perfect Score!' : 'Quiz Completed Successfully!'}
                    </h3>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      You have passed the mandatory academic screening quiz. You are eligible to generate your digital Completion Certificate under HRCM MENTOR.
                    </p>
                  </div>

                  {/* Certificate Generation fields */}
                  <div className="bg-slate-50 dark:bg-slate-800/40 p-6 rounded-2xl max-w-md mx-auto space-y-4 text-left border border-slate-100 dark:border-white/5">
                    <div>
                      <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Enter Your Name for Certificate</label>
                      <input
                        type="text"
                        value={certificateStudentName}
                        onChange={(e) => setCertificateStudentName(e.target.value)}
                        placeholder="e.g. Nabin Kumar"
                        className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-sm focus:outline-none"
                      />
                    </div>

                    <button
                      onClick={() => {
                        if (!certificateStudentName) {
                          alert('Please enter your name.');
                          return;
                        }
                        setShowCertificate(true);
                      }}
                      id="generate-cert-btn"
                      className="w-full py-3 gold-gradient text-white rounded-lg font-bold text-xs uppercase tracking-wider"
                    >
                      Generate Certificate
                    </button>
                  </div>
                </div>
              )}

              {/* Conditional Display Generated Certificate */}
              {showCertificate && selectedCourse && (
                <div id="completion-certificate" className="bg-amber-50/20 dark:bg-slate-950/40 p-6 md:p-8 rounded-3xl border-4 border-double border-amber-600 shadow-2xl relative overflow-hidden space-y-8">
                  {/* Watermark Logo */}
                  <div className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05] pointer-events-none flex items-center justify-center">
                    <span className="font-serif text-[180px] font-bold text-amber-500">HM</span>
                  </div>

                  <div className="text-center space-y-4">
                    <h2 className="font-serif text-amber-700 dark:text-amber-400 font-extrabold tracking-widest text-lg md:text-xl uppercase">Certificate of Completion</h2>
                    <p className="text-slate-500 dark:text-slate-400 text-xs italic">HRCM MENTOR INTEGRATIVE ACADEMY</p>
                  </div>

                  <div className="text-center space-y-6">
                    <p className="text-xs text-slate-600 dark:text-slate-300">This certifies that</p>
                    <h3 className="font-serif text-2xl md:text-3xl font-extrabold text-emerald-950 dark:text-white border-b-2 border-amber-500/30 pb-2 inline-block max-w-md uppercase tracking-wider">
                      {certificateStudentName}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-300 max-w-md mx-auto leading-relaxed">
                      has successfully completed all lectures, assignments, and structural examinations of the premium <strong className="text-emerald-900 dark:text-emerald-400">{selectedCourse.title}</strong> under instruction of Nabin K. Choudhary, located in Ghaziabad, UP, India.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 pt-6 border-t border-amber-500/20 text-center text-xs max-w-xl mx-auto gap-8">
                    <div>
                      <p className="font-serif font-bold text-slate-800 dark:text-slate-300">Nabin K. Choudhary</p>
                      <p className="text-[10px] text-slate-500 uppercase mt-0.5">Founder, HRCM MENTOR</p>
                    </div>
                    <div>
                      <p className="font-serif font-bold text-slate-800 dark:text-slate-300">July 21, 2026</p>
                      <p className="text-[10px] text-slate-500 uppercase mt-0.5">Date of Issue</p>
                    </div>
                  </div>

                  <div className="text-center">
                    <button
                      onClick={() => alert('Certificate downloaded as PDF (Simulation success)')}
                      id="download-cert-sim"
                      className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-900 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold shadow"
                    >
                      <Download className="w-4 h-4" /> Download Certified Copy
                    </button>
                  </div>
                </div>
              )}

            </div>

            {/* Right Column: Lecture index list & resources */}
            <div className="lg:col-span-4 bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-xl border border-emerald-900/10 dark:border-white/5 space-y-6">
              
              <div className="space-y-1">
                <h3 className="font-serif text-base font-bold text-emerald-950 dark:text-white">{selectedCourse.title}</h3>
                <span className="text-xs text-slate-500">Instructor: {selectedCourse.instructor}</span>
              </div>

              {/* Videos list */}
              <div className="space-y-3">
                <h4 className="font-serif text-xs font-bold uppercase tracking-wider text-slate-400">Lectures ({selectedCourse.videos.length})</h4>
                <div className="space-y-2">
                  {selectedCourse.videos.map((vid) => (
                    <button
                      key={vid.id}
                      id={`select-vid-${vid.id}`}
                      onClick={() => {
                        setActiveVideo(vid);
                        setShowCertificate(false);
                        setQuizCompleted(false);
                      }}
                      className={`w-full text-left p-3 rounded-xl border flex items-center gap-3 transition-all ${
                        activeVideo?.id === vid.id && !quizCompleted && !showCertificate
                          ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-950 dark:text-emerald-300 font-semibold'
                          : 'border-slate-100 dark:border-white/5 hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <Play className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                      <div className="flex-1 text-xs">
                        <p className="line-clamp-1">{vid.title}</p>
                        <span className="text-[10px] text-slate-400">{vid.duration}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* PDF Materials */}
              <div className="space-y-3">
                <h4 className="font-serif text-xs font-bold uppercase tracking-wider text-slate-400">Syllabus PDF Material</h4>
                <div className="space-y-2">
                  {selectedCourse.pdfs.map((pdf) => (
                    <button
                      key={pdf.id}
                      onClick={() => alert(`Downloaded study resource: ${pdf.title}`)}
                      className="w-full text-left p-3 rounded-xl border border-slate-100 dark:border-white/5 hover:bg-slate-50 dark:hover:bg-slate-800/40 flex items-center gap-3 text-xs"
                    >
                      <FileText className="w-4 h-4 text-amber-500 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="line-clamp-1">{pdf.title}</p>
                        <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-bold uppercase">Download PDF</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Assessment / Quiz */}
              <div className="space-y-3 pt-2">
                <h4 className="font-serif text-xs font-bold uppercase tracking-wider text-slate-400">Final Assessment</h4>
                {!quizCompleted ? (
                  <button
                    onClick={startQuiz}
                    id="trigger-course-quiz"
                    className="w-full py-3 bg-amber-500 text-slate-950 hover:bg-amber-600 rounded-xl font-bold text-xs uppercase flex items-center justify-center gap-2"
                  >
                    <HelpCircle className="w-4 h-4" /> Start Academic Exam
                  </button>
                ) : (
                  <div className="p-3 bg-emerald-500/10 rounded-xl border border-emerald-500/20 text-xs text-center space-y-1">
                    <p className="font-bold text-emerald-800 dark:text-emerald-400">Exam Passed Successfully!</p>
                    <button 
                      onClick={() => setShowCertificate(true)} 
                      className="text-xs font-bold text-amber-600 dark:text-amber-500 underline"
                    >
                      View Completion Certificate
                    </button>
                  </div>
                )}
              </div>

            </div>

          </div>

          {/* Quiz popup questions if in active quiz mode */}
          {!quizCompleted && quizAnswers.length > 0 && (
            <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 md:p-8 space-y-6 shadow-2xl border border-emerald-900/10 dark:border-white/5">
                <div className="flex justify-between items-center pb-3 border-b border-slate-100 dark:border-white/10">
                  <span className="text-xs font-bold text-amber-500 uppercase font-mono">Exam Question {currentQuizIdx + 1} of {selectedCourse.quizzes.length}</span>
                  <button onClick={() => setQuizAnswers([])} className="text-xs font-bold text-red-600 hover:underline">Cancel</button>
                </div>

                <div className="space-y-4">
                  <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{selectedCourse.quizzes[currentQuizIdx].question}</p>
                  <div className="space-y-2">
                    {selectedCourse.quizzes[currentQuizIdx].options.map((opt, oIdx) => (
                      <button
                        key={oIdx}
                        type="button"
                        id={`quiz-q-${currentQuizIdx}-opt-${oIdx}`}
                        onClick={() => handleSelectQuizOption(oIdx)}
                        className={`w-full p-3 text-left rounded-xl border text-xs font-medium transition-all ${
                          quizAnswers[currentQuizIdx] === oIdx
                            ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-300 font-bold'
                            : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={nextQuizQuestion}
                  id="quiz-next-btn"
                  className="w-full py-3 bg-emerald-900 dark:bg-emerald-600 text-white rounded-lg font-bold text-xs uppercase"
                >
                  {currentQuizIdx < selectedCourse.quizzes.length - 1 ? 'Next Question' : 'Submit Exam Paper'}
                </button>
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
}
