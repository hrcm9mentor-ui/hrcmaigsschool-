import React, { useState, useEffect } from 'react';
import { 
  User, 
  Calendar, 
  Clock, 
  CheckCircle, 
  XCircle, 
  FileText, 
  Plus, 
  CreditCard, 
  Activity, 
  ShieldAlert,
  Download,
  AlertCircle
} from 'lucide-react';
import { auth, getDoctorsList, getUserAppointments, createAppointment, getDoctorProfile, db } from '../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { setDoc, doc, updateDoc, collection, addDoc, getDocs } from 'firebase/firestore';
import { DoctorProfile, Appointment } from '../types';

export default function DoctorConsultation() {
  const [user, setUser] = useState<any>(null);
  const [userRole, setUserRole] = useState<'user' | 'doctor' | 'admin'>('user');

  // List of approved Doctors (seeded with static fallback plus live state)
  const [doctors, setDoctors] = useState<DoctorProfile[]>([
    { id: 'nabin-founder', name: 'Nabin K. Choudhary', email: 'choudharynabink@gmail.com', phone: '+91 7906596613', degree: 'B.Sc, Siddha Astrologer & Vastu Acharya', specialty: 'Medical Vastu & Cosmic Remediation', fees: 1100, availability: ['Monday 10:00 - 13:00', 'Wednesday 15:00 - 18:00'], approved: true, rating: 4.9 },
    { id: 'dr-ramesh', name: 'Dr. Ramesh Kumar', email: 'drramesh@hrcm.com', phone: '+91 9999012345', degree: 'MBBS, MD (Psychiatry), Spiritual Counsellor', specialty: 'Mental Health Counselling & Mindfulness', fees: 1500, availability: ['Tuesday 11:00 - 14:00', 'Friday 16:00 - 19:00'], approved: true, rating: 4.8 }
  ]);

  // Appointments (seeded with static fallbacks + live state)
  const [appointments, setAppointments] = useState<Appointment[]>([
    { id: 'appt-1', userId: 'seeker-1', userName: 'Amit Sharma', userPhone: '9876543210', doctorId: 'nabin-founder', doctorName: 'Nabin K. Choudhary', specialty: 'Medical Vastu & Cosmic Remediation', date: '2026-07-25', time: '11:30 AM', status: 'pending', paymentStatus: 'paid', createdAt: '2026-07-20T10:00:00Z' }
  ]);

  // Seeker booking inputs
  const [selectedDocId, setSelectedDocId] = useState('nabin-founder');
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('');
  const [bookingPhone, setBookingPhone] = useState('');
  const [isSubmittingBooking, setIsSubmittingBooking] = useState(false);
  const [bookingSuccessMsg, setBookingSuccessMsg] = useState('');
  const [invoiceHtml, setInvoiceHtml] = useState('');

  // Doctor registration inputs
  const [docDegree, setDocDegree] = useState('');
  const [docSpecialty, setDocSpecialty] = useState('');
  const [docFees, setDocFees] = useState(1000);
  const [docBio, setDocBio] = useState('');
  const [docAvailableTime, setDocAvailableTime] = useState('Monday 14:00 - 17:00');
  const [docIsRegistered, setDocIsRegistered] = useState(false);

  // Active doctor workspace inputs (for writing prescriptions)
  const [selectedApptIdForPresc, setSelectedApptIdForPresc] = useState<string | null>(null);
  const [prescriptionText, setPrescriptionText] = useState('');

  // simulated payment checkout
  const [showCheckout, setShowCheckout] = useState(false);
  const [checkoutApptData, setCheckoutApptData] = useState<any>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currUser) => {
      setUser(currUser);
      if (currUser) {
        // Find if this user has a doctor profile
        const docSnap = await getDoctorProfile(currUser.uid);
        if (docSnap) {
          setUserRole('doctor');
          setDocIsRegistered(true);
          // Insert doctor into active lists if not present
          if (!doctors.find(d => d.id === currUser.uid)) {
            setDoctors(prev => [...prev, docSnap]);
          }
        } else {
          setUserRole('user');
        }
        
        // Fetch appointments
        const appts = await getUserAppointments(currUser.uid, docSnap ? 'doctor' : 'user');
        if (appts && appts.length > 0) {
          setAppointments(appts);
        }
      }
    });
    return unsubscribe;
  }, []);

  // Handle Seeker Booking Submit
  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      alert('Please Sign In to book a clinical consultation.');
      return;
    }
    if (!bookingDate || !bookingTime || !bookingPhone) {
      alert('Please fill out all booking fields.');
      return;
    }

    const selectedDoc = doctors.find(d => d.id === selectedDocId);
    if (!selectedDoc) return;

    // trigger checkout drawer/modal
    setCheckoutApptData({
      doctorId: selectedDocId,
      doctorName: selectedDoc.name,
      specialty: selectedDoc.specialty,
      fees: selectedDoc.fees,
      date: bookingDate,
      time: bookingTime,
      userPhone: bookingPhone
    });
    setShowCheckout(true);
  };

  // Complete simulated payment
  const completeSimulatedPayment = async (paymentMethod: 'razorpay' | 'upi' | 'qr') => {
    if (!user || !checkoutApptData) return;
    setIsSubmittingBooking(true);
    setErrorState('');

    try {
      const selectedDoc = doctors.find(d => d.id === checkoutApptData.doctorId)!;
      const apptId = `appt_${Math.random().toString(36).substring(2, 10)}`;

      const newAppt: Appointment = {
        id: apptId,
        userId: user.uid,
        userName: user.displayName || 'Spiritual Seeker',
        userPhone: checkoutApptData.userPhone,
        doctorId: checkoutApptData.doctorId,
        doctorName: checkoutApptData.doctorName,
        specialty: checkoutApptData.specialty,
        date: checkoutApptData.date,
        time: checkoutApptData.time,
        status: 'pending',
        paymentStatus: 'paid',
        createdAt: new Date().toISOString()
      };

      // Save to Firestore
      try {
        await setDoc(doc(db, 'appointments', apptId), newAppt);
      } catch (fErr) {
        console.warn("Firestore save bypassed (simulated local success).");
      }

      setAppointments([newAppt, ...appointments]);
      setBookingSuccessMsg(`Consultation booked successfully with ${checkoutApptData.doctorName} on ${checkoutApptData.date} at ${checkoutApptData.time}!`);
      
      // Generate simulated invoice
      const invRes = await fetch('/api/generate-invoice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: apptId,
          customerName: user.displayName || 'Seeker',
          total: checkoutApptData.fees,
          items: [{ name: `Consultation Booking: ${checkoutApptData.doctorName}`, price: checkoutApptData.fees, quantity: 1 }]
        })
      });
      const invData = await invRes.json();
      setInvoiceHtml(invData.invoiceHtml || '');

      setShowCheckout(false);
      setCheckoutApptData(null);
      setBookingDate('');
      setBookingTime('');
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsSubmittingBooking(false);
    }
  };

  const [errorState, setErrorState] = useState('');

  // Handle Doctor Self-Registration
  const handleDoctorRegistration = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      alert('Please Sign In first.');
      return;
    }
    if (!docDegree || !docSpecialty || !docBio) {
      alert('Please complete all professional credentials fields.');
      return;
    }

    const docProfile: DoctorProfile = {
      id: user.uid,
      name: user.displayName || 'Dr. Practitioner',
      email: user.email || '',
      phone: '+91 7906596613',
      degree: docDegree,
      specialty: docSpecialty,
      fees: docFees,
      bio: docBio,
      availability: [docAvailableTime],
      approved: true, // Auto-approve for seamless simulation
      rating: 5.0
    };

    try {
      await setDoc(doc(db, 'doctors', user.uid), docProfile);
      // Also update role in user profile
      await updateDoc(doc(db, 'users', user.uid), { role: 'doctor' });
      
      setDoctors([...doctors, docProfile]);
      setUserRole('doctor');
      setDocIsRegistered(true);
      alert('Professional credentials registered successfully. Welcome to HRCM MENTOR clinical registry.');
    } catch (err: any) {
      console.error("Firestore write issue, updating state locally:", err);
      setDoctors([...doctors, docProfile]);
      setUserRole('doctor');
      setDocIsRegistered(true);
    }
  };

  // Doctor Action: Accept / Reject Booking
  const handleUpdateBookingStatus = async (apptId: string, newStatus: 'accepted' | 'rejected' | 'completed') => {
    const updated = appointments.map(appt => {
      if (appt.id === apptId) {
        return { ...appt, status: newStatus };
      }
      return appt;
    });
    setAppointments(updated);
    
    try {
      await updateDoc(doc(db, 'appointments', apptId), { status: newStatus });
    } catch (fErr) {
      console.warn("Firestore bypass.");
    }
  };

  // Doctor Action: Save Prescription
  const handleSavePrescription = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedApptIdForPresc || !prescriptionText) return;

    const updated = appointments.map(appt => {
      if (appt.id === selectedApptIdForPresc) {
        return { ...appt, prescription: prescriptionText, status: 'completed' as const };
      }
      return appt;
    });
    setAppointments(updated);

    try {
      await updateDoc(doc(db, 'appointments', selectedApptIdForPresc), { 
        prescription: prescriptionText, 
        status: 'completed' 
      });
    } catch (err) {
      console.warn(err);
    }

    setSelectedApptIdForPresc(null);
    setPrescriptionText('');
    alert('Clinical prescription uploaded successfully and sent to patient dashboard.');
  };

  return (
    <div id="consultation-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 dark:text-white">
      
      {/* Title Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <h2 className="font-serif text-3xl md:text-4xl font-extrabold text-emerald-950 dark:text-white">
          Siddha Clinical Practice & Consultations
        </h2>
        <p className="text-slate-600 dark:text-slate-400">
          Consult directly with medical-spiritual experts and certified psychiatrists to treat chronic structural and biological imbalances.
        </p>
      </div>

      {bookingSuccessMsg && (
        <div className="p-4 bg-emerald-100 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-400 rounded-xl border border-emerald-500/20 max-w-2xl mx-auto space-y-3">
          <p className="font-semibold">{bookingSuccessMsg}</p>
          {invoiceHtml && (
            <button
              onClick={() => {
                const w = window.open();
                if (w) w.document.write(invoiceHtml);
              }}
              className="text-xs font-bold text-amber-600 dark:text-amber-500 underline flex items-center gap-1"
            >
              <Download className="w-4 h-4" /> View & Print Medical Invoice
            </button>
          )}
        </div>
      )}

      {/* Grid: Layout adapts based on user role */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: User Booking Form OR Doctor Registry Profile */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 p-6 md:p-8 rounded-2xl shadow-xl border border-emerald-900/10 dark:border-white/5 space-y-6">
          
          {userRole !== 'doctor' ? (
            /* Seeker Booking Form */
            <div className="space-y-4">
              <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white flex items-center gap-2">
                <Calendar className="w-5 h-5 text-amber-500" /> Book Video Consultation
              </h3>
              <p className="text-xs text-slate-500">Securely schedule a 1-on-1 audio/video consultation with an approved practitioner.</p>

              <form onSubmit={handleBookingSubmit} className="space-y-4 text-xs sm:text-sm">
                <div>
                  <label className="block font-semibold text-slate-500 mb-1">Select Practitioner</label>
                  <select
                    value={selectedDocId}
                    onChange={(e) => setSelectedDocId(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white"
                  >
                    {doctors.map(doc => (
                      <option key={doc.id} value={doc.id} className="dark:bg-slate-900">
                        {doc.name} (Fees: ₹{doc.fees})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-slate-500 mb-1">Preferred Date</label>
                    <input
                      type="date"
                      required
                      value={bookingDate}
                      onChange={(e) => setBookingDate(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-500 mb-1">Preferred Time</label>
                    <select
                      value={bookingTime}
                      onChange={(e) => setBookingTime(e.target.value)}
                      required
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white"
                    >
                      <option value="">Select slot</option>
                      <option value="10:00 AM">10:00 AM</option>
                      <option value="11:30 AM">11:30 AM</option>
                      <option value="02:00 PM">02:00 PM</option>
                      <option value="04:30 PM">04:30 PM</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-500 mb-1">Contact Phone Number</label>
                  <input
                    type="tel"
                    required
                    value={bookingPhone}
                    onChange={(e) => setBookingPhone(e.target.value)}
                    placeholder="e.g. 7906596613"
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  id="book-consultation-btn"
                  className="w-full py-3 gold-gradient text-white rounded-lg font-bold text-xs uppercase tracking-wider"
                >
                  Pay Online & Confirm
                </button>
              </form>
            </div>
          ) : (
            /* Doctor registered, show registration detail edit if wanted, or instructions */
            <div className="space-y-4">
              <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white">Practitioner Office Active</h3>
              <p className="text-xs text-slate-500">You are logged in as a registered practitioner. You can manage your online consulting hours and review medical histories.</p>
              
              <div className="p-4 bg-emerald-500/10 rounded-xl border border-emerald-500/20 text-xs text-slate-700 dark:text-slate-300 space-y-1">
                <p><strong>Registry Status</strong>: Approved Partner</p>
                <p><strong>Practice Clinic Location</strong>: Ghaziabad Head Office</p>
              </div>
            </div>
          )}

          {/* Practice Register Panel (Only if user has regular role and wants to apply as doctor) */}
          {userRole !== 'doctor' && !docIsRegistered && (
            <div className="pt-6 border-t border-slate-100 dark:border-white/5 space-y-4">
              <h3 className="font-serif text-base font-bold text-slate-800 dark:text-slate-200">Are you a Medical Doctor?</h3>
              <p className="text-xs text-slate-500">Join our clinical network. Register your psychiatric, ayurvedic, or surgical credentials to consult patients.</p>

              <form onSubmit={handleDoctorRegistration} className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-500 mb-1 font-semibold">Degrees & Qualifications</label>
                  <input
                    type="text"
                    required
                    value={docDegree}
                    onChange={(e) => setDocDegree(e.target.value)}
                    placeholder="e.g. MBBS, MD (Internal Medicine)"
                    className="w-full p-2 rounded border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-slate-500 mb-1 font-semibold">Specialty</label>
                    <input
                      type="text"
                      required
                      value={docSpecialty}
                      onChange={(e) => setDocSpecialty(e.target.value)}
                      placeholder="e.g. Cardiology"
                      className="w-full p-2 rounded border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 mb-1 font-semibold">Fees (INR)</label>
                    <input
                      type="number"
                      required
                      value={docFees}
                      onChange={(e) => setDocFees(parseInt(e.target.value))}
                      className="w-full p-2 rounded border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-slate-500 mb-1 font-semibold">Short Professional Bio</label>
                  <textarea
                    required
                    value={docBio}
                    onChange={(e) => setDocBio(e.target.value)}
                    placeholder="Describe your medical practice and spiritual alignment methods..."
                    rows={2}
                    className="w-full p-2 rounded border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  id="doctor-reg-submit"
                  className="w-full py-2 border border-emerald-900 text-emerald-900 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/20 text-xs font-bold rounded"
                >
                  Register Practitioner Profile
                </button>
              </form>
            </div>
          )}

        </div>

        {/* Right Column: Appointments List & Action Centre */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-6 md:p-8 rounded-2xl shadow-xl border border-emerald-900/10 dark:border-white/5 space-y-6 min-h-[420px]">
          <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white border-b border-slate-100 dark:border-white/10 pb-4">
            Consultation Desk (Active Case Files)
          </h3>

          <div className="space-y-4">
            {appointments.length > 0 ? (
              appointments.map((appt) => (
                <div key={appt.id} className="p-5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/40 dark:border-white/5 space-y-3">
                  <div className="flex flex-wrap justify-between items-start gap-2">
                    <div>
                      <p className="text-[10px] font-mono font-bold text-amber-600 dark:text-amber-500 uppercase">Appointment ID: {appt.id}</p>
                      <h4 className="font-bold text-emerald-900 dark:text-emerald-400 text-sm mt-0.5">
                        {userRole === 'doctor' ? `Patient: ${appt.userName}` : `Doctor: ${appt.doctorName}`}
                      </h4>
                      <p className="text-xs text-slate-500">{appt.specialty}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                        appt.status === 'completed' ? 'bg-emerald-100 text-emerald-800' :
                        appt.status === 'accepted' ? 'bg-blue-100 text-blue-800' :
                        appt.status === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {appt.status}
                      </span>
                      <span className="text-[10px] bg-emerald-900 text-white px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                        {appt.paymentStatus}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 dark:text-slate-300">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-4 h-4 text-emerald-600" />
                      <span>{appt.date}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-emerald-600" />
                      <span>{appt.time}</span>
                    </div>
                  </div>

                  {/* Patient phone if doctor viewing */}
                  {userRole === 'doctor' && appt.userPhone && (
                    <p className="text-xs text-slate-500">Patient Phone: <strong>{appt.userPhone}</strong></p>
                  )}

                  {/* Interactive Prescription details */}
                  {appt.prescription ? (
                    <div className="p-3 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 space-y-1 text-xs">
                      <strong className="text-emerald-800 dark:text-emerald-400 flex items-center gap-1">
                        <FileText className="w-3.5 h-3.5" /> Clinical Prescription:
                      </strong>
                      <p className="text-slate-700 dark:text-slate-300 italic whitespace-pre-wrap">"{appt.prescription}"</p>
                    </div>
                  ) : (
                    appt.status === 'completed' && (
                      <p className="text-xs text-slate-400 italic">No prescription uploaded for this session.</p>
                    )
                  )}

                  {/* Doctor actions: Accept, Reject, Prescribe */}
                  {userRole === 'doctor' && appt.status !== 'completed' && (
                    <div className="pt-2 border-t border-slate-200/50 dark:border-white/5 flex gap-2">
                      {appt.status === 'pending' && (
                        <>
                          <button
                            onClick={() => handleUpdateBookingStatus(appt.id, 'accepted')}
                            className="flex-1 py-1.5 bg-emerald-800 text-white rounded text-xs font-bold flex items-center justify-center gap-1"
                          >
                            <CheckCircle className="w-3.5 h-3.5" /> Accept Booking
                          </button>
                          <button
                            onClick={() => handleUpdateBookingStatus(appt.id, 'rejected')}
                            className="py-1.5 px-3 bg-red-100 text-red-700 rounded text-xs font-bold"
                          >
                            Reject
                          </button>
                        </>
                      )}

                      {appt.status === 'accepted' && (
                        <button
                          onClick={() => setSelectedApptIdForPresc(appt.id)}
                          className="flex-1 py-1.5 bg-amber-500 text-slate-950 rounded text-xs font-bold flex items-center justify-center gap-1"
                        >
                          <FileText className="w-3.5 h-3.5" /> Write Prescription / Complete Case
                        </button>
                      )}
                    </div>
                  )}

                </div>
              ))
            ) : (
              <div className="text-center py-12 text-slate-400 space-y-2">
                <AlertCircle className="w-12 h-12 mx-auto" />
                <p className="text-xs">No consulting case history found in this account.</p>
              </div>
            )}
          </div>

        </div>
      </div>

      {/* Online simulated Payment Checkout drawer modal */}
      {showCheckout && checkoutApptData && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 md:p-8 space-y-6 shadow-2xl border border-emerald-900/10 dark:border-white/5">
            <div className="flex justify-between items-center border-b border-slate-100 dark:border-white/10 pb-3">
              <h4 className="font-serif text-base font-bold text-emerald-950 dark:text-white">Secure Payment checkout</h4>
              <button onClick={() => setShowCheckout(false)} className="text-xs font-bold text-slate-400">Cancel</button>
            </div>

            <div className="space-y-3 bg-slate-50 dark:bg-slate-850 p-4 rounded-xl text-xs">
              <p className="flex justify-between"><span>Expert practitioner:</span> <strong>{checkoutApptData.doctorName}</strong></p>
              <p className="flex justify-between"><span>Specialty:</span> <span className="text-slate-500">{checkoutApptData.specialty}</span></p>
              <p className="flex justify-between"><span>Date & Time:</span> <span className="font-bold">{checkoutApptData.date} at {checkoutApptData.time}</span></p>
              <p className="flex justify-between border-t border-dashed border-slate-200 dark:border-slate-800 pt-2 text-sm text-emerald-900 dark:text-emerald-400 font-bold">
                <span>Total consultation fees:</span> <span>₹{checkoutApptData.fees}</span>
              </p>
            </div>

            <div className="space-y-3">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Select simulated Gateway</p>
              
              <div className="grid grid-cols-1 gap-2">
                <button
                  type="button"
                  onClick={() => completeSimulatedPayment('razorpay')}
                  className="p-3 bg-emerald-900 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs flex justify-between items-center shadow"
                >
                  <span>Pay with simulated Razorpay Gateways</span>
                  <CreditCard className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => completeSimulatedPayment('upi')}
                  className="p-3 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-800 dark:text-slate-200 rounded-xl text-xs flex justify-between items-center font-bold"
                >
                  <span>Pay using UPI Instant Payment</span>
                  <span className="text-[10px] bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-amber-600 font-mono">BHIM / GPay</span>
                </button>

                {/* QR Code Simulation */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col items-center gap-3 text-center">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Fast Scan and Pay via QR</span>
                  {/* Square Box mimicking QR */}
                  <div className="w-24 h-24 bg-slate-900 p-2 rounded flex items-center justify-center">
                    <div className="w-full h-full border-4 border-white bg-slate-900 flex flex-wrap gap-1 p-1">
                      {new Array(16).fill(0).map((_, i) => (
                        <div key={i} className={`w-3 h-3 ${i % 3 === 0 ? 'bg-white' : 'bg-transparent'}`}></div>
                      ))}
                    </div>
                  </div>
                  <button
                    onClick={() => completeSimulatedPayment('qr')}
                    className="text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:underline"
                  >
                    Click to simulate QR scan complete
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Write Prescription Dialog Overlay */}
      {selectedApptIdForPresc && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <form onSubmit={handleSavePrescription} className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 md:p-8 space-y-4 shadow-2xl border border-emerald-900/10 dark:border-white/5">
            <h4 className="font-serif text-base font-bold text-emerald-950 dark:text-white border-b border-slate-100 dark:border-white/10 pb-3">
              clinical case prescription
            </h4>

            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Prescription Details (Medicines, Herbs, Vastu remedies)</label>
              <textarea
                required
                value={prescriptionText}
                onChange={(e) => setPrescriptionText(e.target.value)}
                placeholder="Write precise prescription directions. Include dosage, Vastu direction coordinates, or healing beads..."
                rows={5}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-sm text-slate-900 dark:text-white focus:outline-none"
              />
            </div>

            <div className="flex gap-2">
              <button
                type="submit"
                className="flex-1 py-2.5 bg-emerald-900 dark:bg-emerald-600 hover:bg-emerald-800 text-white rounded text-xs font-bold"
              >
                Upload & Mark Completed
              </button>
              <button
                type="button"
                onClick={() => { setSelectedApptIdForPresc(null); setPrescriptionText(''); }}
                className="py-2.5 px-4 bg-slate-100 dark:bg-slate-800 rounded text-xs font-bold"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
}
