import { Course, Product, BlogPost } from './types';

export const FOUNDER_INFO = {
  name: "Nabin K. Choudhary",
  location: "Ghaziabad, Uttar Pradesh, India",
  email: "choudharynabink@gmail.com",
  phone: "+91 7906596613",
  languages: ["Hindi", "English"],
  brand: "HRCM MENTOR",
  tagline: "Medical & Spiritual Sciences Integrated"
};

export const INITIAL_COURSES: Course[] = [
  {
    id: 'course-astrology',
    title: 'Astrology Master Course',
    category: 'astrology',
    description: 'Master Vedic Astrology, planet transits, Kundli reading, and Dasha calculations from basic to professional level.',
    price: 4999,
    duration: '12 Weeks',
    instructor: 'Nabin K. Choudhary',
    rating: 4.9,
    imageUrl: 'https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?auto=format&fit=crop&q=80&w=600',
    studentCount: 1840,
    videos: [
      { id: 'v1', title: 'Introduction to Vedic Cosmology', duration: '45 mins', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' },
      { id: 'v2', title: 'The 12 Houses and Cosmic Significance', duration: '1 hr 15 mins', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' },
      { id: 'v3', title: 'Nakshatras and Planetary Strengths', duration: '58 mins', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' }
    ],
    pdfs: [
      { id: 'pdf1', title: 'Comprehensive Astrology Chart Guide', pdfUrl: '#' },
      { id: 'pdf2', title: 'Planetary Transits & Remedies Workbook', pdfUrl: '#' }
    ],
    quizzes: [
      {
        question: 'Which house represents Career and Profession in Vedic Astrology?',
        options: ['1st House', '5th House', '9th House', '10th House'],
        answerIndex: 3
      },
      {
        question: 'What is the lord of Aries (Mesh Rashi)?',
        options: ['Venus', 'Mars', 'Jupiter', 'Mercury'],
        answerIndex: 1
      }
    ]
  },
  {
    id: 'course-numerology',
    title: 'Chaldean Numerology Master Course',
    category: 'numerology',
    description: 'Understand Chaldean method, single/double number combinations, name corrections, and calculating lucky vehicle or business names.',
    price: 3499,
    duration: '8 Weeks',
    instructor: 'Nabin K. Choudhary',
    rating: 4.8,
    imageUrl: 'https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?auto=format&fit=crop&q=80&w=600',
    studentCount: 1420,
    videos: [
      { id: 'n1', title: 'Chaldean vs Pythagorean System', duration: '35 mins', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' },
      { id: 'n2', title: 'The Vibration of Compound Numbers', duration: '55 mins', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' },
      { id: 'n3', title: 'Formulating Business Name Correction', duration: '1 hr 10 mins', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' }
    ],
    pdfs: [
      { id: 'pdf-n1', title: 'Chaldean Sound Value Matrix PDF', pdfUrl: '#' },
      { id: 'pdf-n2', title: 'Name Correction Formula Worksheet', pdfUrl: '#' }
    ],
    quizzes: [
      {
        question: 'In Chaldean Numerology, which number value is assigned to the letter A?',
        options: ['1', '2', '5', '8'],
        answerIndex: 0
      }
    ]
  },
  {
    id: 'course-medical-vastu',
    title: 'Medical Vastu Course',
    category: 'vastu',
    description: 'Learn the healing art of Medical Vastu. Align the 16 directions with anatomical health zones to prevent and remediate chronic diseases.',
    price: 5999,
    duration: '10 Weeks',
    instructor: 'Nabin K. Choudhary',
    rating: 4.95,
    imageUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=600',
    studentCount: 980,
    videos: [
      { id: 'mv1', title: 'The 16 Zones and Anatomical Connections', duration: '50 mins', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' },
      { id: 'mv2', title: 'North-East & Brain Health Anomalies', duration: '1 hr 05 mins', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' }
    ],
    pdfs: [
      { id: 'pdf-mv1', title: 'Medical Vastu Directional Mapping Poster', pdfUrl: '#' }
    ],
    quizzes: [
      {
        question: 'Which zone governs immunity and health in Vastu?',
        options: ['North-East', 'North-North-East', 'East-South-East', 'South-West'],
        answerIndex: 1
      }
    ]
  },
  {
    id: 'course-mental-health',
    title: 'Mental Health Awareness Course',
    category: 'mental_health',
    description: 'Integrate ancient mindful breathing exercises with modern clinical mental health concepts for deep emotional healing.',
    price: 1999,
    duration: '6 Weeks',
    instructor: 'Nabin K. Choudhary',
    rating: 4.7,
    imageUrl: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&q=80&w=600',
    studentCount: 750,
    videos: [
      { id: 'mh1', title: 'Pranayama and Vagustimulation', duration: '40 mins', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' }
    ],
    pdfs: [
      { id: 'pdf-mh1', title: 'Anxiety Coping Tools & Breathing Protocols', pdfUrl: '#' }
    ],
    quizzes: [
      {
        question: 'Which of the following is an effective technique for immediate vagus nerve activation?',
        options: ['Deep thoracic rapid breathing', 'Stretches', 'Double inhale followed by long exhale', 'Intense running'],
        answerIndex: 2
      }
    ]
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-rudraksha-5',
    name: 'Premium 5 Mukhi Nepal Rudraksha',
    description: 'Sourced directly from Nepalese high-altitude forests. Certified 5-faced Rudraksha bead for mental clarity, peace, lower blood pressure, and spiritual connection.',
    price: 1250,
    category: 'rudraksha',
    imageUrl: 'https://images.unsplash.com/photo-1609137144813-94c65363406e?auto=format&fit=crop&q=80&w=600',
    stock: 25,
    rating: 4.8,
    reviews: [
      { userName: 'Dr. Ramesh Kumar', rating: 5, comment: 'Incredibly authentic bead. Noticed immediate stabilizing effect on anxiety.', date: '2026-06-15' }
    ]
  },
  {
    id: 'prod-rudraksha-7',
    name: 'Siddha 7 Mukhi Mahalaxmi Rudraksha',
    description: 'Genuine 7 Mukhi Rudraksha governing the planet Saturn (Shani). Bestows prosperity, financial abundance, and professional opportunities.',
    price: 2400,
    category: 'rudraksha',
    imageUrl: 'https://images.unsplash.com/photo-1590073844006-33379778ae09?auto=format&fit=crop&q=80&w=600',
    stock: 12,
    rating: 4.9,
    reviews: []
  },
  {
    id: 'prod-sri-yantra',
    name: 'Premium Brass Sri Yantra (3D Meru)',
    description: 'Gold-plated 3D Meru Sri Yantra designed with absolute geometric precision. Energized for home and office abundance.',
    price: 4500,
    category: 'yantra',
    imageUrl: 'https://images.unsplash.com/photo-1447069387593-a5de0862481e?auto=format&fit=crop&q=80&w=600',
    stock: 8,
    rating: 5.0,
    reviews: [
      { userName: 'Anil Gupta', rating: 5, comment: 'Highly precise geometry. Outstanding quality!', date: '2026-07-02' }
    ]
  },
  {
    id: 'prod-emerald',
    name: 'Certified Natural Zambian Emerald (Panna)',
    description: '5.25 Carat Natural Zambian Emerald stone. Represents Mercury (Budh) to boost business intelligence, communication, and cognitive capacity.',
    price: 18500,
    category: 'gemstone',
    imageUrl: 'https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?auto=format&fit=crop&q=80&w=600',
    stock: 3,
    rating: 4.7,
    reviews: []
  },
  {
    id: 'prod-book-vastu',
    name: 'Secret of Medical Vastu Handbook',
    description: 'Authored by medical-spiritual experts. Comprehensive guide detailing house orientation, zone maps, illness causes, and remedies.',
    price: 499,
    category: 'book',
    imageUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=600',
    stock: 50,
    rating: 4.85,
    reviews: []
  },
  {
    id: 'prod-report-career',
    name: 'Custom Career & Business Numerology Report',
    description: 'Delivered digitally in 48 hours. Comprehensive 25-page customized PDF containing name compatibility scores, lucky dates, mobile number analysis, and yearly predictions.',
    price: 1500,
    category: 'digital_report',
    imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=600',
    stock: 999,
    rating: 4.9,
    reviews: []
  }
];

export const INITIAL_BLOGS: BlogPost[] = [
  {
    id: 'blog-1',
    title: 'The Neurological Benefits of Rudraksha & Panchang Rhythms',
    excerpt: 'Explore how wearing certified Rudraksha beads regulates bio-electrical impulses in the human body and how Panchang alignment minimizes stress.',
    content: `Rudraksha beads possess unique electromagnetic, paramagnetic, and inductive properties. When worn against the chest, they stabilize the sensory neurons regulating cardiovascular activity, bringing down stress and hyper-reactivity. 

### Modern Physics and Bio-electromagnetism
Scientific studies confirm that Rudraksha beads act like capacitors, storing electrical charges that interact harmoniously with the human bio-field. This bio-electrical synergy has been found to soothe the central nervous system, lower hypertension, and induce peaceful theta-wave brain states.

### Aligning Daily Panchang with Circadian Rhythms
Daily Panchang is not merely cultural; it is a description of the planetary-lunar magnetic fields influencing Earth. The Tithi, Nakshatra, and Yoga describe atmospheric electromagnetic densities. By scheduling high-focus actions during auspicious Muhurats (like Abhijit Muhurat) and reserving Rahu Kaal for introspection, we optimize endocrine secretions and prevent mental fatigue.`,
    category: 'Spiritual Science',
    imageUrl: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&q=80&w=600',
    author: 'Nabin K. Choudhary',
    date: '2026-07-18',
    readTime: '5 min read',
    comments: [
      { id: 'c1', userName: 'Sanjay Rawat', comment: 'Extremely fascinating explanation linking physics and tradition!', date: '2026-07-19' }
    ]
  },
  {
    id: 'blog-2',
    title: 'Medical Vastu: Diagnosing House Zones for Brain and Heart Health',
    excerpt: 'Understand how placing restrooms or kitchens in certain compass coordinates impacts cognitive health and cardiovascular states of the residents.',
    content: `Medical Vastu integrates structural orientation with spatial-anatomical frequencies. Just as our body has an energetic spine (Sushumna), your living space possesses cardinal pathways that guide atmospheric prana.

### The Brain Health Axis: North-East (Ishanya)
The North-East zone is governed by the Water element and represents cognitive clarity. Places of accumulation, toilets, or heavy metal storage in the North-East pollute the brain's subtle meridians. This frequently manifests as neurological fog, migraines, sleep disorders, and chronic anxiety.

### The Immune Shield: North-North-East (NNE)
Positioned between North and North-East, this zone is the ultimate immune shield. Placing pharmaceutical storage or meditation rooms here optimizes body defenses. Conversely, a kitchen burner or trash incinerator here generates auto-immune disorders.

### Simple Remedies
1. Avoid red color in the North and North-East zones.
2. Introduce copper spiral rods or brass pyramids to ground magnetic faults.
3. Decorate the North-North-East with real, air-purifying indoor plants.`,
    category: 'Medical Vastu',
    imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=600',
    author: 'Nabin K. Choudhary',
    date: '2026-07-15',
    readTime: '7 min read',
    comments: []
  }
];

export const DAILY_PANCHANG = {
  date: "July 21, 2026",
  tithi: "Shukla Saptami (7th Lunar Day)",
  nakshatra: "Chitra Nakshatra",
  yoga: "Siddha Yoga",
  karana: "Vanija",
  rahukaal: "15:30 to 17:15 (Inauspicious)",
  abhijit: "11:45 to 12:35 (Highly Auspicious)",
  sunset: "19:12",
  sunrise: "05:32"
};

export const HOROSCOPES = {
  Aries: "Focus on cardiovascular health and grounding. Today represents high intellectual performance; ideal for name correction reviews.",
  Taurus: "Your financial planets are aligning favorably in the 11th house. Wear a 7 Mukhi Rudraksha to maximize opportunities.",
  Gemini: "Anxiety levels might spike. Use the GAD-7 screening tool on our site and balance your North-East house coordinates.",
  Cancer: "Nurture family relationships. A minor Vastu modification in your East zone will bring deep, therapeutic harmony.",
  Leo: "Your ruling sun boosts your leadership today. Business name corrections will attract significant authority and success.",
  Virgo: "High cognitive focus is assured. Excellent day to enroll in our Astrology or Chaldean Numerology courses.",
  Libra: "Balance your expenditure. Planetary transits advise setting up a Sri Yantra in your North office drawer.",
  Scorpio: "A powerful time for spiritual insight. Deep meditation and chanting will activate profound physical healing.",
  Sagittarius: "Career planetary configurations are in progress. Focus on your North-East medical vastu zone to boost vision.",
  Capricorn: "Patience will reward your efforts. Keep green plants in your North zone to attract commercial prosperity.",
  Aquarius: "Excellent day to analyze your mobile number vibration. Ensure your name number totals a friendly planetary value.",
  Pisces: "Seek advice for mental fatigue. Re-align your sleeping directions; head towards the South to regulate blood pressure."
};
