import React, { useState, useMemo } from 'react';
import { 
  Gem, 
  HelpCircle, 
  Sparkles, 
  ArrowRight, 
  UserCheck, 
  PhoneCall, 
  Building2, 
  Car, 
  UserPlus 
} from 'lucide-react';

// Chaldean sound matrix values
const CHALDEAN_MAP: Record<string, number> = {
  A: 1, I: 1, J: 1, Q: 1, Y: 1,
  B: 2, K: 2, R: 2,
  C: 3, G: 3, L: 3, S: 3,
  D: 4, M: 4, T: 4,
  E: 5, H: 5, N: 5, X: 5,
  U: 6, V: 6, W: 6,
  O: 7, Z: 7,
  F: 8, P: 8
};

const PLANET_VIBRATIONS: Record<number, { planet: string; traits: string; luckyDates: string; remedies: string }> = {
  1: { planet: 'Sun (Surya)', traits: 'Leadership, authority, cognitive power, original creator.', luckyDates: '1st, 10th, 19th, 28th', remedies: 'Incorporate copper details in East direction.' },
  2: { planet: 'Moon (Chandra)', traits: 'Emotional depth, artistic talents, empathy, fluctuating energy.', luckyDates: '2nd, 11th, 20th, 29th', remedies: 'Meditate facing the North-East.' },
  3: { planet: 'Jupiter (Guru)', traits: 'Wisdom, spiritual growth, educational mastery, wealth expansion.', luckyDates: '3rd, 12th, 21st, 30th', remedies: 'Wear a certified 5 Mukhi Nepal Rudraksha.' },
  4: { planet: 'Rahu (North Node)', traits: 'Unconventional vision, rapid amplification, technology focus, sudden changes.', luckyDates: '4th, 13th, 22nd, 31st', remedies: 'Do Vastu checks in the South-West sector.' },
  5: { planet: 'Mercury (Budh)', traits: 'Commercial intelligence, rapid speech, quick calculations, name correction affinity.', luckyDates: '5th, 14th, 23rd', remedies: 'Add green plants in North zone.' },
  6: { planet: 'Venus (Shukra)', traits: 'Luxury, creative arts, beauty, harmony, diplomatic balance.', luckyDates: '6th, 15th, 24th', remedies: 'Maintain immaculate hygiene in South-East.' },
  7: { planet: 'Ketu (South Node)', traits: 'Spiritual detachment, sharp intuition, psychic talents, research.', luckyDates: '7th, 16th, 25th', remedies: 'Perform deep diaphragmatic pranayama.' },
  8: { planet: 'Saturn (Shani)', traits: 'Discipline, severe trials, heavy karmic lessons, structured order.', luckyDates: '8th, 17th, 26th', remedies: 'Wear a certified 7 Mukhi Rudraksha.' },
  9: { planet: 'Mars (Mangal)', traits: 'Courage, physical endurance, competitive drive, surgery affinity.', luckyDates: '9th, 18th, 27th', remedies: 'Position red accents in South-South-East.' }
};

export default function NumerologyTool() {
  const [activeTab, setActiveTab] = useState<'name' | 'business' | 'vehicle' | 'mobile' | 'compatibility'>('name');

  // Input states
  const [inputName, setInputName] = useState('NABIN K CHOUDHARY');
  const [businessName, setBusinessName] = useState('HRCM MENTOR');
  const [vehicleNumber, setVehicleNumber] = useState('UP16BD7906');
  const [mobileNumber, setMobileNumber] = useState('7906596613');
  
  // Compatibility inputs
  const [name1, setName1] = useState('');
  const [name2, setName2] = useState('');

  // Calculate Chaldean Name value helper
  const calculateChaldean = (text: string) => {
    let compound = 0;
    const details: { letter: string; val: number }[] = [];
    const uppercaseText = text.toUpperCase();

    for (let i = 0; i < uppercaseText.length; i++) {
      const char = uppercaseText[i];
      if (CHALDEAN_MAP[char] !== undefined) {
        compound += CHALDEAN_MAP[char];
        details.push({ letter: char, val: CHALDEAN_MAP[char] });
      }
    }

    // Reduce compound to single-digit (if compound > 9, sum digits)
    let single = compound;
    while (single > 9) {
      single = String(single).split('').reduce((sum, d) => sum + parseInt(d), 0);
    }

    return { compound, single, details };
  };

  const nameResult = useMemo(() => calculateChaldean(inputName), [inputName]);
  const businessResult = useMemo(() => calculateChaldean(businessName), [businessName]);
  
  const vehicleResult = useMemo(() => {
    // Only extract alphanumeric values
    const cleaned = vehicleNumber.replace(/[^A-Za-z0-9]/g, '');
    let sum = 0;
    const details: string[] = [];
    for (let char of cleaned.toUpperCase()) {
      if (/[0-9]/.test(char)) {
        const val = parseInt(char);
        sum += val;
        details.push(char);
      } else if (CHALDEAN_MAP[char] !== undefined) {
        sum += CHALDEAN_MAP[char];
        details.push(`${char}(${CHALDEAN_MAP[char]})`);
      }
    }
    let single = sum;
    while (single > 9) {
      single = String(single).split('').reduce((acc, d) => acc + parseInt(d), 0);
    }
    return { compound: sum, single, details: details.join(' + ') };
  }, [vehicleNumber]);

  const mobileResult = useMemo(() => {
    const cleaned = mobileNumber.replace(/[^0-9]/g, '');
    let sum = 0;
    for (let num of cleaned) {
      sum += parseInt(num);
    }
    let single = sum;
    while (single > 9) {
      single = String(single).split('').reduce((acc, d) => acc + parseInt(d), 0);
    }
    return { compound: sum, single };
  }, [mobileNumber]);

  // Compatibility score generator
  const compatibilityScore = useMemo(() => {
    if (!name1 || !name2) return null;
    const val1 = calculateChaldean(name1).single;
    const val2 = calculateChaldean(name2).single;
    
    // Simple harmonic rule
    const diff = Math.abs(val1 - val2);
    let score = 95 - diff * 12;
    if (score < 30) score = 42;
    return { score, val1, val2 };
  }, [name1, name2]);

  // Suggest correction helper
  const nameCorrectionSuggestion = useMemo(() => {
    const activeSingle = nameResult.single;
    if (activeSingle === 4 || activeSingle === 8) {
      // Recommend suffix letters or vowel duplicates to steer towards 1, 5, or 6
      return {
        necessary: true,
        reason: `Your current name vibration resolves to single number ${activeSingle} (governed by ${PLANET_VIBRATIONS[activeSingle]?.planet}). This vibration carries heavy structural trials and delay frequencies.`,
        correction1: `${inputName}A`,
        correction1Value: calculateChaldean(`${inputName}A`).single,
        correction2: `${inputName}I`,
        correction2Value: calculateChaldean(`${inputName}I`).single,
      };
    }
    return { necessary: false, reason: "Your name is currently tuned to an auspicious planetary vibration." };
  }, [nameResult, inputName]);

  return (
    <div id="numerology-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 dark:text-white">
      
      {/* Introduction Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <h2 className="font-serif text-3xl md:text-4xl font-extrabold text-emerald-950 dark:text-white">
          Chaldean Numerology Laboratory
        </h2>
        <p className="text-slate-600 dark:text-slate-400">
          Chaldean numerology represents the oldest and most precise vibrational sound system. Unlike Pythagorean grids, Chaldean mapping centers on phonetical sound frequencies.
        </p>
      </div>

      {/* Tool Navigation tabs */}
      <div className="flex flex-wrap justify-center bg-slate-100 dark:bg-slate-900 p-1.5 rounded-xl text-xs sm:text-sm font-semibold max-w-3xl mx-auto gap-1">
        {[
          { id: 'name', label: 'Name Calculator', icon: UserCheck },
          { id: 'business', label: 'Business Name', icon: Building2 },
          { id: 'vehicle', label: 'Vehicle Number', icon: Car },
          { id: 'mobile', label: 'Mobile Analyzer', icon: PhoneCall },
          { id: 'compatibility', label: 'Compatibility', icon: UserPlus }
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              id={`numerology-tab-${tab.id}`}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${
                activeTab === tab.id
                  ? 'bg-emerald-900 dark:bg-emerald-600 text-white shadow'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Main Tool Content Boxes */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Interactive Input Panel */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 p-6 md:p-8 rounded-2xl shadow-xl border border-emerald-900/10 dark:border-white/5 space-y-6">
          
          {activeTab === 'name' && (
            <div className="space-y-4">
              <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white">Chaldean Name Correction</h3>
              <p className="text-xs text-slate-500">Calculate individual sound vibrations and single compound values of your full name.</p>
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">Type Full Name</label>
                <input
                  type="text"
                  value={inputName}
                  onChange={(e) => setInputName(e.target.value)}
                  placeholder="e.g. NABIN K CHOUDHARY"
                  className="w-full px-4 py-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500 uppercase font-serif"
                />
              </div>
            </div>
          )}

          {activeTab === 'business' && (
            <div className="space-y-4">
              <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white">Business Name Vibrator</h3>
              <p className="text-xs text-slate-500">Formulate commercial names to resonate with 1 (authority) or 5 (Mercury commerce).</p>
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">Enter Business Name</label>
                <input
                  type="text"
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  placeholder="e.g. HRCM MENTOR"
                  className="w-full px-4 py-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500 uppercase"
                />
              </div>
            </div>
          )}

          {activeTab === 'vehicle' && (
            <div className="space-y-4">
              <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white">Vehicle Plate Calculator</h3>
              <p className="text-xs text-slate-500">Calculate single compound code of your car or bike numbers to ensure road accident immunity.</p>
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">Enter License Plate</label>
                <input
                  type="text"
                  value={vehicleNumber}
                  onChange={(e) => setVehicleNumber(e.target.value)}
                  placeholder="e.g. UP16BD7906"
                  className="w-full px-4 py-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500 uppercase"
                />
              </div>
            </div>
          )}

          {activeTab === 'mobile' && (
            <div className="space-y-4">
              <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white">Mobile Number Analysis</h3>
              <p className="text-xs text-slate-500">Analyze friendly planet vibration based on the complete addition of your mobile digits.</p>
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">Enter Mobile Number</label>
                <input
                  type="text"
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value)}
                  placeholder="e.g. 7906596613"
                  className="w-full px-4 py-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          )}

          {activeTab === 'compatibility' && (
            <div className="space-y-4">
              <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white">Vibrational Compatibility</h3>
              <p className="text-xs text-slate-500">Check compatibility score between two individuals or an individual and their business name.</p>
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">First Name / Partner A</label>
                  <input
                    type="text"
                    value={name1}
                    onChange={(e) => setName1(e.target.value)}
                    placeholder="Partner Name"
                    className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500 uppercase"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">Second Name / Partner B</label>
                  <input
                    type="text"
                    value={name2}
                    onChange={(e) => setName2(e.target.value)}
                    placeholder="Partner Name"
                    className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500 uppercase"
                  />
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Right Output Dashboard Column */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-6 md:p-8 rounded-2xl shadow-xl border border-emerald-900/10 dark:border-white/5 min-h-[380px]">
          
          {activeTab === 'name' && nameResult && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-slate-100 dark:border-white/10 pb-4">
                <h4 className="font-serif text-base font-bold text-emerald-900 dark:text-white">Name Vibration Summary</h4>
                <span className="text-[10px] font-mono bg-amber-500/10 text-amber-800 dark:text-amber-400 px-2.5 py-0.5 rounded-full border border-amber-500/20">Chaldean Method</span>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-100 dark:border-white/5 text-center">
                  <span className="text-xs text-slate-500">Compound (Double) Number</span>
                  <p className="text-3xl font-bold text-emerald-900 dark:text-emerald-400 mt-1">{nameResult.compound}</p>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-100 dark:border-white/5 text-center">
                  <span className="text-xs text-slate-500">Single Destiny Number</span>
                  <p className="text-3xl font-bold text-amber-500 mt-1">{nameResult.single}</p>
                </div>
              </div>

              {/* Sound mapping visualization */}
              <div className="space-y-2">
                <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Acoustic Sound Breakdown</p>
                <div className="flex flex-wrap gap-2">
                  {nameResult.details.map((item, i) => (
                    <div key={i} className="flex flex-col items-center bg-emerald-50 dark:bg-emerald-950/20 px-3 py-1.5 rounded-lg border border-emerald-100/30 text-xs">
                      <span className="font-bold text-emerald-900 dark:text-emerald-400">{item.letter}</span>
                      <span className="text-[10px] text-slate-500 font-mono mt-0.5">{item.val}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Planetary description */}
              {PLANET_VIBRATIONS[nameResult.single] && (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/50 dark:border-white/5 space-y-2">
                  <p className="text-xs font-semibold text-slate-500 uppercase">Ruling Planetary Vibration</p>
                  <p className="text-sm font-bold text-emerald-800 dark:text-amber-400">
                    {PLANET_VIBRATIONS[nameResult.single].planet}
                  </p>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    <strong>Vibrational Traits:</strong> {PLANET_VIBRATIONS[nameResult.single].traits}
                  </p>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    <strong>Auspicious Action Dates:</strong> {PLANET_VIBRATIONS[nameResult.single].luckyDates}
                  </p>
                  <p className="text-xs text-slate-500">
                    <strong>Medical-Vastu Remedy:</strong> {PLANET_VIBRATIONS[nameResult.single].remedies}
                  </p>
                </div>
              )}

              {/* Name Correction Recommendation */}
              {nameCorrectionSuggestion.necessary ? (
                <div className="p-4 bg-amber-500/10 rounded-xl border border-amber-500/20 space-y-2">
                  <div className="flex items-center gap-1.5 font-bold text-xs text-amber-800 dark:text-amber-400">
                    <Sparkles className="w-4 h-4 animate-bounce" />
                    <span>Correction Indicated</span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{nameCorrectionSuggestion.reason}</p>
                  <div className="grid grid-cols-2 gap-2 pt-2">
                    <div className="p-2 bg-white dark:bg-slate-900 rounded border border-amber-500/30">
                      <span className="text-[10px] text-slate-400 uppercase">Suggestion A</span>
                      <p className="font-serif font-bold text-sm text-emerald-900 dark:text-emerald-400">{nameCorrectionSuggestion.correction1}</p>
                      <span className="text-[10px] text-amber-600 dark:text-amber-500 font-mono">Destiny Single: {nameCorrectionSuggestion.correction1Value}</span>
                    </div>
                    <div className="p-2 bg-white dark:bg-slate-900 rounded border border-amber-500/30">
                      <span className="text-[10px] text-slate-400 uppercase">Suggestion B</span>
                      <p className="font-serif font-bold text-sm text-emerald-900 dark:text-emerald-400">{nameCorrectionSuggestion.correction2}</p>
                      <span className="text-[10px] text-amber-600 dark:text-amber-500 font-mono">Destiny Single: {nameCorrectionSuggestion.correction2Value}</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-emerald-500/10 rounded-xl border border-emerald-500/20 text-xs text-emerald-800 dark:text-emerald-400 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 flex-shrink-0 text-amber-500" />
                  <span>Your current name is auspiciously aligned. No major spelling modification is required.</span>
                </div>
              )}
            </div>
          )}

          {activeTab === 'business' && businessResult && (
            <div className="space-y-6">
              <h4 className="font-serif text-base font-bold text-emerald-950 dark:text-white border-b border-slate-100 dark:border-white/10 pb-4">Business Name Vibration</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl text-center border border-slate-100 dark:border-white/5">
                  <span className="text-xs text-slate-500">Business Sound Sum</span>
                  <p className="text-3xl font-bold text-emerald-900 dark:text-emerald-400">{businessResult.compound}</p>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl text-center border border-slate-100 dark:border-white/5">
                  <span className="text-xs text-slate-500">Acoustic Destiny Single</span>
                  <p className="text-3xl font-bold text-amber-500">{businessResult.single}</p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/50 dark:border-white/5 space-y-2 text-xs">
                <strong className="text-slate-800 dark:text-slate-200 block uppercase">Commercial Analysis:</strong>
                {businessResult.single === 1 || businessResult.single === 5 || businessResult.single === 6 ? (
                  <p className="text-emerald-700 dark:text-emerald-400 leading-relaxed">
                    This business name is highly auspicious! Resolving to {businessResult.single} ensures massive client retention, fast-growing commercial revenues, and excellent corporate credibility.
                  </p>
                ) : (
                  <p className="text-amber-700 dark:text-amber-500 leading-relaxed">
                    Resolving to {businessResult.single} might cause minor cashflow bottlenecks. We advise modifying the name spelling slightly to resolve to 1 (authority), 5 (Mercury commerce), or 6 (diplomatic harmony).
                  </p>
                )}
              </div>
            </div>
          )}

          {activeTab === 'vehicle' && vehicleResult && (
            <div className="space-y-6">
              <h4 className="font-serif text-base font-bold text-emerald-950 dark:text-white border-b border-slate-100 dark:border-white/10 pb-4">Vehicle Plate Vibration</h4>
              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl space-y-2 text-xs">
                <p className="text-slate-500">License Plate Formulation:</p>
                <p className="font-mono text-slate-800 dark:text-slate-200 font-bold text-sm bg-white dark:bg-slate-950 p-2.5 rounded border border-slate-200 dark:border-slate-800">
                  {vehicleResult.details} = {vehicleResult.compound}
                </p>
                <div className="pt-2 flex justify-between items-center">
                  <span className="text-slate-500">Reduced Single Value:</span>
                  <span className="text-lg font-bold text-amber-500">{vehicleResult.single}</span>
                </div>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl text-xs space-y-2 border border-slate-200/50 dark:border-white/5">
                <strong className="text-slate-800 dark:text-slate-200 block uppercase">Road Safety Profile:</strong>
                {vehicleResult.single === 8 ? (
                  <p className="text-red-600 dark:text-red-400">
                    A single value of 8 represents Saturn (Shani). This might cause frequent engine repairs or road delays. Place a small energized copper pyramid behind the driving seat to ground magnetic stress.
                  </p>
                ) : (
                  <p className="text-emerald-700 dark:text-emerald-400">
                    A single value of {vehicleResult.single} is well-aligned with your active travel vectors. Supports peaceful, safe commuting.
                  </p>
                )}
              </div>
            </div>
          )}

          {activeTab === 'mobile' && mobileResult && (
            <div className="space-y-6">
              <h4 className="font-serif text-base font-bold text-emerald-950 dark:text-white border-b border-slate-100 dark:border-white/10 pb-4">Mobile Number Analysis</h4>
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl text-center border border-slate-100 dark:border-white/5">
                  <span className="text-slate-500">Vibrational Total</span>
                  <p className="text-2xl font-bold text-emerald-900 dark:text-emerald-400 mt-1">{mobileResult.compound}</p>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl text-center border border-slate-100 dark:border-white/5">
                  <span className="text-slate-500">Ruling Planet Number</span>
                  <p className="text-2xl font-bold text-amber-500 mt-1">{mobileResult.single}</p>
                </div>
              </div>

              {PLANET_VIBRATIONS[mobileResult.single] && (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/50 dark:border-white/5 text-xs space-y-2">
                  <p className="font-bold text-slate-800 dark:text-slate-200 uppercase">Vibrational Influence on Incoming Calls:</p>
                  <p>Your mobile number is governed by <strong>{PLANET_VIBRATIONS[mobileResult.single].planet}</strong>.</p>
                  <p className="text-slate-600 dark:text-slate-400">{PLANET_VIBRATIONS[mobileResult.single].traits}</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'compatibility' && (
            <div className="space-y-6">
              <h4 className="font-serif text-base font-bold text-emerald-950 dark:text-white border-b border-slate-100 dark:border-white/10 pb-4">Relationship & Business Alignment</h4>
              {compatibilityScore ? (
                <div className="space-y-4 text-center">
                  <div className="inline-flex flex-col items-center justify-center w-28 h-28 rounded-full border-4 border-amber-500 bg-emerald-50 dark:bg-emerald-950/30">
                    <span className="text-xs text-slate-500 uppercase font-bold">Alignment</span>
                    <span className="text-2xl font-bold text-emerald-900 dark:text-emerald-400">{compatibilityScore.score}%</span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-xs text-left pt-2">
                    <div className="p-3 border border-slate-200 dark:border-slate-800 rounded-lg">
                      <p className="text-slate-400">Partner A Single</p>
                      <p className="font-bold text-sm text-slate-800 dark:text-slate-200">Value: {compatibilityScore.val1}</p>
                    </div>
                    <div className="p-3 border border-slate-200 dark:border-slate-800 rounded-lg">
                      <p className="text-slate-400">Partner B Single</p>
                      <p className="font-bold text-sm text-slate-800 dark:text-slate-200">Value: {compatibilityScore.val2}</p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-500 leading-relaxed text-left">
                    *Chaldean calculations indicate that a difference of {Math.abs(compatibilityScore.val1 - compatibilityScore.val2)} between primary numbers generates a moderately helpful magnetic tension. Wear 5 Mukhi Nepalese Rudraksha together to shield mutual communication.
                  </p>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center text-center my-auto p-6 space-y-4 text-slate-400">
                  <Gem className="w-12 h-12" />
                  <p className="text-xs">Enter both names on the left to evaluate their acoustical alignment score.</p>
                </div>
              )}
            </div>
          )}

        </div>
      </div>

    </div>
  );
}
