import React, { useState } from 'react';
import { 
  Compass, 
  Sparkles, 
  Star, 
  Moon, 
  Sun, 
  Clock, 
  Calendar, 
  User, 
  MapPin, 
  ShieldAlert 
} from 'lucide-react';
import { HOROSCOPES, DAILY_PANCHANG } from '../data';

const ZODIAC_SIGNS = [
  { name: 'Aries', symbol: '♈', element: 'Fire', lord: 'Mars' },
  { name: 'Taurus', symbol: '♉', element: 'Earth', lord: 'Venus' },
  { name: 'Gemini', symbol: '♊', element: 'Air', lord: 'Mercury' },
  { name: 'Cancer', symbol: '♋', element: 'Water', lord: 'Moon' },
  { name: 'Leo', symbol: '♌', element: 'Fire', lord: 'Sun' },
  { name: 'Virgo', symbol: '♍', element: 'Earth', lord: 'Mercury' },
  { name: 'Libra', symbol: '♎', element: 'Air', lord: 'Venus' },
  { name: 'Scorpio', symbol: '♏', element: 'Water', lord: 'Mars' },
  { name: 'Sagittarius', symbol: '♐', element: 'Fire', lord: 'Jupiter' },
  { name: 'Capricorn', symbol: '♑', element: 'Earth', lord: 'Saturn' },
  { name: 'Aquarius', symbol: '♒', element: 'Air', lord: 'Saturn' },
  { name: 'Pisces', symbol: '♓', element: 'Water', lord: 'Jupiter' }
];

export default function AstrologyTool() {
  const [selectedSign, setSelectedSign] = useState<string>('Aries');
  const [forecastPeriod, setForecastPeriod] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('daily');
  
  // Kundli Input States
  const [birthName, setBirthName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [birthTime, setBirthTime] = useState('');
  const [birthPlace, setBirthPlace] = useState('');
  const [generatedKundli, setGeneratedKundli] = useState<boolean>(false);

  // Transit alerts
  const transits = [
    { planet: 'Jupiter (Guru)', transit: 'Transiting Taurus (Vrishabha) - 9th House alignment', influence: 'Highly auspicious for philosophical learning and medical-vastu corrections.' },
    { planet: 'Saturn (Shani)', transit: 'Sustained Transit in Aquarius (Kumbha)', influence: 'Demands hard discipline in lifestyle, alignment of North-North-East coordinates.' },
    { planet: 'Mercury (Budh)', transit: 'Entering Cancer on July 23', influence: 'Enhances cognitive awareness. Excellent for Chaldean name modification studies.' }
  ];

  const handleGenerateKundli = (e: React.FormEvent) => {
    e.preventDefault();
    if (!birthName || !birthDate || !birthTime || !birthPlace) return;
    setGeneratedKundli(true);
  };

  return (
    <div id="astrology-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 dark:text-white">
      
      {/* Title & Introduction */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <h2 className="font-serif text-3xl md:text-4xl font-extrabold text-emerald-950 dark:text-white">
          Vedic Astrology & Panchang Center
        </h2>
        <p className="text-slate-600 dark:text-slate-400">
          Sync your daily micro-decisions with the cosmos. Read your medically influenced horoscope, calculate planetary dasha, and view the precise Ghaziabad-calibrated panchang metrics.
        </p>
      </div>

      {/* Grid: Panchang on left, Horoscope selector on right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Full Daily Panchang */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl p-6 md:p-8 shadow-xl border border-emerald-900/10 dark:border-white/5 space-y-6">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-white/10 pb-4">
            <Compass className="w-6 h-6 text-emerald-700 dark:text-emerald-400" />
            <div>
              <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white">Daily Ghaziabad Panchang</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">{DAILY_PANCHANG.date}</p>
            </div>
          </div>

          <div className="space-y-4 text-sm">
            <div className="flex justify-between py-2 border-b border-slate-100/50 dark:border-white/5">
              <span className="text-slate-500 dark:text-slate-400">Sunrise / Sunset</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">
                {DAILY_PANCHANG.sunrise} AM / {DAILY_PANCHANG.sunset} PM
              </span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100/50 dark:border-white/5">
              <span className="text-slate-500 dark:text-slate-400">Tithi (Lunar Day)</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">{DAILY_PANCHANG.tithi}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100/50 dark:border-white/5">
              <span className="text-slate-500 dark:text-slate-400">Nakshatra</span>
              <span className="font-semibold text-emerald-700 dark:text-emerald-400">{DAILY_PANCHANG.nakshatra}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100/50 dark:border-white/5">
              <span className="text-slate-500 dark:text-slate-400">Yoga / Karana</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">{DAILY_PANCHANG.yoga} / {DAILY_PANCHANG.karana}</span>
            </div>
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 rounded-xl border border-emerald-100 dark:border-emerald-900/30">
              <p className="text-xs font-bold text-emerald-900 dark:text-emerald-400 uppercase tracking-wider mb-1">Abhijit Muhurat (Auspicious Action)</p>
              <p className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1">
                <Sun className="w-4 h-4 text-amber-500 animate-pulse" /> {DAILY_PANCHANG.abhijit}
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">Excellent for buying gold, correcting business names, or scheduling clinical consultation bookings.</p>
            </div>
            <div className="p-4 bg-red-500/10 rounded-xl border border-red-500/20">
              <p className="text-xs font-bold text-red-700 dark:text-red-400 uppercase tracking-wider mb-1">Rahu Kaal (Avoid Major Actions)</p>
              <p className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1">
                <Moon className="w-4 h-4 text-slate-400" /> {DAILY_PANCHANG.rahukaal}
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">Avoid launching new digital reports, signing rental Vastu leases, or conducting surgeries.</p>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Horoscope Forecast */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-6 md:p-8 shadow-xl border border-emerald-900/10 dark:border-white/5 space-y-6">
          <div className="flex flex-wrap justify-between items-center gap-4 border-b border-slate-100 dark:border-white/10 pb-4">
            <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white flex items-center gap-1.5">
              <Star className="w-5 h-5 text-amber-500" /> Medical-Spiritual Horoscope
            </h3>
            
            {/* Period selector */}
            <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs font-semibold">
              {(['daily', 'weekly', 'monthly', 'yearly'] as const).map((period) => (
                <button
                  key={period}
                  id={`horoscope-tab-${period}`}
                  onClick={() => setForecastPeriod(period)}
                  className={`px-3 py-1.5 rounded-md capitalize transition-all ${
                    forecastPeriod === period 
                      ? 'bg-emerald-900 dark:bg-emerald-600 text-white shadow-md' 
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {period}
                </button>
              ))}
            </div>
          </div>

          {/* Sign Selector Grid */}
          <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
            {ZODIAC_SIGNS.map((sign) => (
              <button
                key={sign.name}
                id={`sign-select-${sign.name}`}
                onClick={() => setSelectedSign(sign.name)}
                className={`p-2.5 rounded-xl text-center border transition-all flex flex-col items-center justify-center ${
                  selectedSign === sign.name
                    ? 'border-amber-500 bg-emerald-50 dark:bg-emerald-950/30 shadow-md shadow-emerald-900/5'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <span className="text-xl md:text-2xl mb-1">{sign.symbol}</span>
                <span className="text-[10px] md:text-xs font-semibold block">{sign.name}</span>
                <span className="text-[8px] text-slate-500 dark:text-slate-400 font-mono hidden sm:inline-block">{sign.lord}</span>
              </button>
            ))}
          </div>

          {/* Active Sign Forecast Content */}
          {selectedSign && (
            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/50 dark:border-white/5 space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="font-serif text-lg font-bold text-emerald-900 dark:text-amber-400 flex items-center gap-2">
                  <span>{selectedSign}</span>
                  <span className="text-xs font-sans px-2.5 py-0.5 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-300 rounded-full">
                    {ZODIAC_SIGNS.find(z => z.name === selectedSign)?.element} Element
                  </span>
                </h4>
                <span className="text-xs font-mono text-slate-500">Lord: {ZODIAC_SIGNS.find(z => z.name === selectedSign)?.lord}</span>
              </div>

              <div className="text-slate-700 dark:text-slate-300 text-sm leading-relaxed space-y-3">
                <p>
                  <strong>{forecastPeriod.toUpperCase()} OUTLOOK:</strong> {HOROSCOPES[selectedSign as keyof typeof HOROSCOPES] || "The planets support slow, meticulous work."}
                </p>
                {forecastPeriod !== 'daily' && (
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    *During this {forecastPeriod} cycle, retrograde Saturn triggers secondary medical vastu imbalances. Focus on balancing East-South-East sectors with high-frequency copper strips to prevent digestive sluggishness.
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Interactive Vedic Kundli Generator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Form: Birth Entry */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl p-6 md:p-8 shadow-xl border border-emerald-900/10 dark:border-white/5 space-y-6">
          <h3 className="font-serif text-xl font-bold text-emerald-950 dark:text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-500" /> Interactive Kundli Creator
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Generate your traditional North Indian Kundli chart instantly. Our algorithm charts the planetary coordinates based on precise sidereal longitude projections.
          </p>

          <form onSubmit={handleGenerateKundli} className="space-y-4 text-xs sm:text-sm">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Birth Name</label>
              <input
                type="text"
                required
                value={birthName}
                onChange={(e) => setBirthName(e.target.value)}
                placeholder="e.g. Nabin Kumar"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Date of Birth</label>
                <input
                  type="date"
                  required
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Time of Birth</label>
                <input
                  type="time"
                  required
                  value={birthTime}
                  onChange={(e) => setBirthTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Place of Birth</label>
              <input
                type="text"
                required
                value={birthPlace}
                onChange={(e) => setBirthPlace(e.target.value)}
                placeholder="e.g. Ghaziabad, UP, India"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-transparent text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <button
              type="submit"
              id="generate-kundli-button"
              className="w-full py-3 gold-gradient text-white rounded-lg font-bold text-xs uppercase tracking-wider shadow-lg hover:opacity-95 transition-all"
            >
              Calculate Chart & Dasha
            </button>
          </form>
        </div>

        {/* Right Panel: Render North Indian Style Kundli */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-6 md:p-8 shadow-xl border border-emerald-900/10 dark:border-white/5 flex flex-col justify-between min-h-[480px]">
          {generatedKundli ? (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-slate-100 dark:border-white/10 pb-4">
                <div>
                  <h4 className="font-serif text-lg font-bold text-emerald-950 dark:text-white">Kundli Chart (Lagna)</h4>
                  <p className="text-xs text-slate-500">Calculated for {birthName} born at {birthTime} on {birthDate}</p>
                </div>
                <button
                  id="reset-kundli"
                  onClick={() => setGeneratedKundli(false)}
                  className="text-xs font-bold text-emerald-700 hover:underline"
                >
                  Edit Birth Info
                </button>
              </div>

              {/* Dynamic North Indian Style Kundli Diagram */}
              <div className="flex flex-col md:flex-row items-center gap-8">
                {/* Visual Grid */}
                <div className="relative w-64 h-64 border-2 border-emerald-900 dark:border-amber-500 bg-emerald-50/20 dark:bg-slate-950/30 flex items-center justify-center">
                  {/* Diagonal Line 1 */}
                  <div className="absolute w-[360px] h-[2px] bg-emerald-900/40 dark:bg-amber-500/40 rotate-45"></div>
                  {/* Diagonal Line 2 */}
                  <div className="absolute w-[360px] h-[2px] bg-emerald-900/40 dark:bg-amber-500/40 -rotate-45"></div>
                  {/* Outer Square border markers */}
                  <div className="absolute w-44 h-44 border border-dashed border-emerald-800/30 rotate-45"></div>
                  
                  {/* House Text Overlays for standard 12 Vedic Houses */}
                  <div className="absolute top-2 text-[10px] font-bold text-slate-800 dark:text-amber-500 font-mono">10: Mo, Me</div>
                  <div className="absolute left-2 text-[10px] font-bold text-slate-800 dark:text-amber-500 font-mono">4: Ju (Asc)</div>
                  <div className="absolute right-2 text-[10px] font-bold text-slate-800 dark:text-amber-500 font-mono">7: Sa</div>
                  <div className="absolute bottom-2 text-[10px] font-bold text-slate-800 dark:text-amber-500 font-mono">1: Su, Ve</div>
                  <div className="absolute top-12 left-12 text-[9px] text-slate-500 dark:text-slate-400">11: Ke</div>
                  <div className="absolute top-12 right-12 text-[9px] text-slate-500 dark:text-slate-400">9: Ma</div>
                  <div className="absolute bottom-12 left-12 text-[9px] text-slate-500 dark:text-slate-400">3: Ra</div>
                  <div className="absolute bottom-12 right-12 text-[9px] text-slate-500 dark:text-slate-400">12: Pl</div>
                </div>

                {/* Interpretation / Dasha */}
                <div className="flex-1 space-y-4 text-xs sm:text-sm">
                  <div className="p-3 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                    <p className="font-bold text-emerald-900 dark:text-emerald-400">Primary Lagna: Leo (Simha)</p>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">Sun occupies your 10th house, indicating massive corporate authority, medical career success, and extreme administrative intelligence.</p>
                  </div>

                  <div className="space-y-1">
                    <p className="font-semibold text-slate-500 uppercase text-[10px]">Vimshottari Dasha Information</p>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="p-2 border border-slate-200 dark:border-slate-800 rounded">
                        <span className="text-slate-500">Jupiter (Guru) Dasha</span>
                        <p className="font-bold text-emerald-700 dark:text-emerald-400">Active (Until 2032)</p>
                      </div>
                      <div className="p-2 border border-slate-200 dark:border-slate-800 rounded">
                        <span className="text-slate-500">Saturn (Shani) Antar</span>
                        <p className="font-bold text-slate-700 dark:text-slate-300">Begins Dec 2026</p>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-amber-500/10 rounded-lg text-xs border border-amber-500/20">
                    <strong className="text-amber-800 dark:text-amber-400 block">Acharya Recommendation:</strong>
                    Wear a high-altitude Nepalese 5 Mukhi Rudraksha to align the active Jupiter dasha and shield the cardiac nerve bundles.
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center text-center my-auto p-8 space-y-4">
              <Compass className="w-16 h-16 text-slate-300 dark:text-slate-700 animate-spin" />
              <h4 className="font-serif text-lg font-bold text-slate-400">Calculate Your Kundli</h4>
              <p className="text-xs text-slate-500 max-w-sm">Enter your birth parameters on the left to see your full sidereal lagna chart, Dasha details, and custom planetary alignment remedies.</p>
            </div>
          )}
        </div>
      </div>

      {/* Planetary Transit alerts */}
      <div className="bg-slate-50 dark:bg-slate-900/60 p-6 rounded-2xl border border-slate-200/50 dark:border-white/5 space-y-4">
        <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white flex items-center gap-2">
          <Clock className="w-5 h-5 text-amber-500" /> Nakshatra & Planetary Transit Guide
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {transits.map((item, i) => (
            <div key={i} className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-white/5 space-y-2">
              <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-widest">{item.planet}</span>
              <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">{item.transit}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">{item.influence}</p>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
