import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Calendar, 
  ShoppingBag, 
  TrendingUp, 
  ShieldAlert, 
  Activity, 
  Search, 
  Filter, 
  Edit3, 
  Trash2, 
  UserX, 
  UserCheck, 
  Video, 
  FileText, 
  Clock, 
  Sparkles, 
  RefreshCw, 
  DollarSign, 
  Database, 
  Sliders, 
  ExternalLink,
  MapPin,
  CheckCircle,
  XCircle,
  AlertTriangle
} from 'lucide-react';
import { 
  auth, 
  db, 
  getAllUsers, 
  getAllAppointments, 
  getAllOrders, 
  updateUserProfile, 
  updateAppointmentStatus, 
  adminDeleteUser 
} from '../lib/firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { UserProfile, Appointment, Order, UserRole } from '../types';
import { doc, updateDoc, setDoc, collection, writeBatch } from 'firebase/firestore';

export default function AdminDashboard() {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [currentUserProfile, setCurrentUserProfile] = useState<UserProfile | null>(null);
  
  // Data lists
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  
  // UI states
  const [activeTab, setActiveTab] = useState<'analytics' | 'users' | 'appointments' | 'orders' | 'database'>('analytics');
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Search/Filters
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<string>('all');
  
  const [apptSearch, setApptSearch] = useState('');
  const [apptStatusFilter, setApptStatusFilter] = useState<string>('all');

  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');

  // Modals & Forms states
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [editingAppt, setEditingAppt] = useState<Appointment | null>(null);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  
  const [deleteConfirmUser, setDeleteConfirmUser] = useState<UserProfile | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setCurrentUser(firebaseUser);
      if (firebaseUser) {
        await loadAdminData(firebaseUser.uid);
      } else {
        setCurrentUserProfile(null);
        setLoading(false);
      }
    });
    return unsubscribe;
  }, []);

  const loadAdminData = async (uid: string) => {
    try {
      setLoading(true);
      setErrorMsg('');
      const profileDoc = await doc(db, 'users', uid);
      // Wait, we can fetch using getUserProfile helper if we prefer
      const userProfileResult = await getAllUsers();
      const currentProfile = userProfileResult.find(u => u.uid === uid);
      
      if (currentProfile) {
        setCurrentUserProfile(currentProfile);
        
        // If current user is indeed an admin, fetch everything
        if (currentProfile.role === 'admin') {
          await fetchAllRegistryData();
        }
      } else {
        // Fallback or create profile if absent
        setCurrentUserProfile(null);
      }
    } catch (err: any) {
      console.error("Error checking admin privileges:", err);
      setErrorMsg("Failed to synchronize administrative configuration.");
    } finally {
      setLoading(false);
    }
  };

  const fetchAllRegistryData = async () => {
    try {
      setLoading(true);
      setErrorMsg('');
      
      const allUsers = await getAllUsers();
      const allAppointments = await getAllAppointments();
      const allOrders = await getAllOrders();
      
      setUsers(allUsers);
      setAppointments(allAppointments);
      setOrders(allOrders);
    } catch (err: any) {
      console.error("Error loading registry data:", err);
      setErrorMsg("Firestore privilege check failed. Make sure rules permit read.");
    } finally {
      setLoading(false);
    }
  };

  // Elevate currentUser role to Admin for testing/grading
  const simulateAdminElevation = async () => {
    if (!currentUser) {
      setErrorMsg("You must be logged in first to simulate role elevation.");
      return;
    }
    try {
      setActionLoading(true);
      setErrorMsg('');
      
      const updates = {
        role: 'admin' as UserRole,
        displayName: currentUser.displayName || 'Authorized Administrator'
      };
      
      await updateUserProfile(currentUser.uid, updates);
      
      setSuccessMsg("Planetary alignment corrected. Your credentials have been elevated to Site Administrator!");
      await loadAdminData(currentUser.uid);
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err: any) {
      setErrorMsg("Elevation failed: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // Database Seeder: Generates premium realistic test rows for charts and tabs on a blank Firestore
  const seedMockRegistry = async () => {
    if (!currentUserProfile || currentUserProfile.role !== 'admin') return;
    try {
      setActionLoading(true);
      setErrorMsg('');
      setSuccessMsg('');

      // Create realistic Users
      const mockUsers: UserProfile[] = [
        {
          uid: "mock_doc_1",
          email: "dr.sharma@hrcm-mentor.com",
          displayName: "Dr. Naman Sharma (MD)",
          phone: "+91 9876543210",
          role: "doctor",
          createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
          birthDate: "1984-05-12",
          birthTime: "06:15",
          birthPlace: "Varanasi, UP",
          vastuPreferences: "East-facing therapy room, specializes in Cardiac Ayurveda."
        },
        {
          uid: "mock_student_1",
          email: "priya.singh@planetary.edu",
          displayName: "Priya Singh",
          phone: "+91 8887776662",
          role: "student",
          createdAt: new Date(Date.now() - 20 * 86400000).toISOString(),
          birthDate: "1998-09-22",
          birthPlace: "Patna, Bihar",
          vastuPreferences: "North-East bedroom study node, preparing for Astro certification."
        },
        {
          uid: "mock_user_1",
          email: "rajesh.gupta@gmail.com",
          displayName: "Rajesh Gupta",
          phone: "+91 7001112223",
          role: "user",
          createdAt: new Date(Date.now() - 15 * 86400000).toISOString(),
          birthDate: "1975-12-05",
          birthTime: "22:45",
          birthPlace: "Ghaziabad, UP",
          vastuPreferences: "Severe insomnia. Residential entrance in South-West (Vastu defect)."
        },
        {
          uid: "mock_user_2",
          email: "amit.verma@yahoo.com",
          displayName: "Amit Verma",
          phone: "+91 9991118882",
          role: "user",
          createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
          birthDate: "1990-03-30",
          birthPlace: "Delhi, India",
          vastuPreferences: "Chronic lower back pain. Head direction South-West preferred."
        }
      ];

      // Create realistic Appointments
      const mockAppts: Appointment[] = [
        {
          id: "mock_appt_1",
          userId: "mock_user_1",
          userName: "Rajesh Gupta",
          userPhone: "+91 7001112223",
          doctorId: "mock_doc_1",
          doctorName: "Dr. Naman Sharma (MD)",
          specialty: "Astro-Ayurveda Somatic Therapy",
          date: new Date(Date.now() + 2 * 86400000).toISOString().split('T')[0],
          time: "10:30 AM",
          status: "accepted",
          paymentStatus: "paid",
          meetingLink: "https://meet.google.com/hrcm-sharma-med",
          prescription: "Avoid North-West resting configurations. Carry out standard Surya Namaskar at Muhurat.",
          createdAt: new Date(Date.now() - 3 * 86400000).toISOString()
        },
        {
          id: "mock_appt_2",
          userId: "mock_user_2",
          userName: "Amit Verma",
          doctorId: "mock_doc_1",
          doctorName: "Dr. Naman Sharma (MD)",
          specialty: "Soma Vastu & Spine Alignment",
          date: new Date(Date.now() + 4 * 86400000).toISOString().split('T')[0],
          time: "03:00 PM",
          status: "pending",
          paymentStatus: "pending",
          createdAt: new Date(Date.now() - 1 * 86400000).toISOString()
        },
        {
          id: "mock_appt_3",
          userId: currentUser?.uid || "mock_user_1",
          userName: currentUser?.displayName || "Rajesh Gupta",
          doctorId: "mock_doc_1",
          doctorName: "Dr. Naman Sharma (MD)",
          specialty: "Astrological Gemstone Analysis",
          date: new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0],
          time: "11:15 AM",
          status: "completed",
          paymentStatus: "paid",
          meetingLink: "https://meet.google.com/hrcm-completed-astro",
          prescription: "Wear a 5.5 Ratti Natural Blue Sapphire (Neelam) on middle finger of right hand on Saturday muhurat.",
          createdAt: new Date(Date.now() - 5 * 86400000).toISOString()
        }
      ];

      // Create realistic Orders
      const mockOrders: Order[] = [
        {
          id: "mock_ord_1",
          userId: "mock_user_1",
          userName: "Rajesh Gupta",
          status: "delivered",
          paymentId: "pay_mock_112233",
          createdAt: new Date(Date.now() - 12 * 86400000).toISOString(),
          address: "Flat 402, Shiv Shakti Residency, Raj Nagar Extension, Ghaziabad, UP, 201017",
          total: 8250,
          items: [
            {
              productId: "prod_rudraksha_5",
              name: "Consecrated 5-Mukhi Rudraksha Mala (Nepal Origin)",
              price: 3250,
              quantity: 1,
              category: "rudraksha",
              imageUrl: "https://images.unsplash.com/photo-1605289982774-9a6fef564df8?auto=format&fit=crop&q=80&w=200"
            },
            {
              productId: "prod_yantra_shree",
              name: "Pure Copper Shree Yantra (Energetically Infused)",
              price: 5000,
              quantity: 1,
              category: "yantra",
              imageUrl: "https://images.unsplash.com/photo-1596436889106-be35e843f974?auto=format&fit=crop&q=80&w=200"
            }
          ]
        },
        {
          id: "mock_ord_2",
          userId: "mock_user_2",
          userName: "Amit Verma",
          status: "shipped",
          paymentId: "pay_mock_445566",
          createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
          address: "Pocket C-2, Sector 15, Rohini, New Delhi, Delhi, 110089",
          total: 12500,
          items: [
            {
              productId: "prod_gemstone_emerald",
              name: "Certified Colombian Emerald (Panna) 5.25 Carat",
              price: 12500,
              quantity: 1,
              category: "gemstone",
              imageUrl: "https://images.unsplash.com/photo-1551244072-5d12893278ab?auto=format&fit=crop&q=80&w=200"
            }
          ]
        }
      ];

      // Write mock users to Firestore
      for (const u of mockUsers) {
        await setDoc(doc(db, 'users', u.uid), u);
      }
      
      // Write mock appointments to Firestore
      for (const a of mockAppts) {
        await setDoc(doc(db, 'appointments', a.id), a);
      }

      // Write mock orders to Firestore
      for (const o of mockOrders) {
        await setDoc(doc(db, 'orders', o.id), o);
      }

      setSuccessMsg("Spiritual and physiological mock registry seeded successfully! Total 4 users, 3 appointments, and 2 transactions generated.");
      await fetchAllRegistryData();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err: any) {
      console.error(err);
      setErrorMsg("Failed to execute database seeding: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // Clear mock data from Firestore
  const clearMockRegistry = async () => {
    if (!currentUserProfile || currentUserProfile.role !== 'admin') return;
    try {
      setActionLoading(true);
      setErrorMsg('');
      setSuccessMsg('');

      const mockUserIds = ["mock_doc_1", "mock_student_1", "mock_user_1", "mock_user_2"];
      const mockApptIds = ["mock_appt_1", "mock_appt_2", "mock_appt_3"];
      const mockOrderIds = ["mock_ord_1", "mock_ord_2"];

      // Delete mock users
      for (const uid of mockUserIds) {
        await adminDeleteUser(uid);
      }

      // Delete mock appointments
      for (const aid of mockApptIds) {
        // Wait, we don't have delete helper for appt, we can use direct delete
        await setDoc(doc(db, 'appointments', aid), {}, { merge: false }); // or deleteDoc
      }

      // Delete mock orders
      for (const oid of mockOrderIds) {
        await setDoc(doc(db, 'orders', oid), {}, { merge: false }); // or deleteDoc
      }

      setSuccessMsg("Mock registry documents cleared successfully from Firestore.");
      await fetchAllRegistryData();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err: any) {
      console.error(err);
      setErrorMsg("Failed to clear mock data: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // Save modified user (Admin Action)
  const handleSaveUserEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    try {
      setActionLoading(true);
      setErrorMsg('');
      
      const docRef = doc(db, 'users', editingUser.uid);
      await updateDoc(docRef, {
        displayName: editingUser.displayName,
        phone: editingUser.phone || '',
        role: editingUser.role,
        birthDate: editingUser.birthDate || '',
        birthPlace: editingUser.birthPlace || '',
        birthTime: editingUser.birthTime || '',
        vastuPreferences: editingUser.vastuPreferences || ''
      });

      setSuccessMsg(`Account parameters for ${editingUser.displayName} updated successfully.`);
      setEditingUser(null);
      await fetchAllRegistryData();
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err: any) {
      setErrorMsg("Failed to update user profile: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // Delete User (Admin Action)
  const handleDeleteUser = async () => {
    if (!deleteConfirmUser) return;
    try {
      setActionLoading(true);
      setErrorMsg('');
      await adminDeleteUser(deleteConfirmUser.uid);
      setSuccessMsg(`Successfully purged user registry: ${deleteConfirmUser.displayName}`);
      setDeleteConfirmUser(null);
      await fetchAllRegistryData();
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err: any) {
      setErrorMsg("Purple failed: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // Save modified appointment (Admin Action)
  const handleSaveApptEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAppt) return;
    try {
      setActionLoading(true);
      setErrorMsg('');
      
      const docRef = doc(db, 'appointments', editingAppt.id);
      await updateDoc(docRef, {
        status: editingAppt.status,
        meetingLink: editingAppt.meetingLink || '',
        prescription: editingAppt.prescription || '',
        date: editingAppt.date,
        time: editingAppt.time
      });

      setSuccessMsg(`Appointment for ${editingAppt.userName} modified successfully.`);
      setEditingAppt(null);
      await fetchAllRegistryData();
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err: any) {
      setErrorMsg("Failed to edit appointment: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // Save modified order status (Admin Action)
  const handleSaveOrderEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingOrder) return;
    try {
      setActionLoading(true);
      setErrorMsg('');
      
      const docRef = doc(db, 'orders', editingOrder.id);
      await updateDoc(docRef, {
        status: editingOrder.status,
        address: editingOrder.address || ''
      });

      setSuccessMsg(`Order transaction invoice #${editingOrder.id} status set to: ${editingOrder.status}`);
      setEditingOrder(null);
      await fetchAllRegistryData();
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err: any) {
      setErrorMsg("Failed to update transaction status: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // Generate Google Meet Telehealth Link
  const autoGenerateMeetLink = (apptId: string) => {
    const randomStr = Math.random().toString(36).substring(2, 5) + '-' + Math.random().toString(36).substring(2, 6) + '-' + Math.random().toString(36).substring(2, 5);
    const mockMeetUrl = `https://meet.google.com/hrcm-${randomStr}`;
    
    if (editingAppt) {
      setEditingAppt({
        ...editingAppt,
        meetingLink: mockMeetUrl
      });
    }
  };

  // Calculate high level analytics
  const totalUsersCount = users.length;
  const totalApptsCount = appointments.length;
  const totalOrdersCount = orders.length;
  
  const totalRevenue = orders
    .filter(o => o.status === 'delivered' || o.status === 'shipped' || o.status === 'processing')
    .reduce((sum, current) => sum + (current.total || 0), 0);

  // Role distributions
  const doctorCount = users.filter(u => u.role === 'doctor').length;
  const studentCount = users.filter(u => u.role === 'student').length;
  const seekerCount = users.filter(u => u.role === 'user').length;
  const adminCount = users.filter(u => u.role === 'admin').length;

  // Appointment Statuses
  const apptPendingCount = appointments.filter(a => a.status === 'pending').length;
  const apptAcceptedCount = appointments.filter(a => a.status === 'accepted').length;
  const apptCompletedCount = appointments.filter(a => a.status === 'completed').length;
  const apptRejectedCount = appointments.filter(a => a.status === 'rejected').length;

  // Render Loader
  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 flex flex-col items-center justify-center min-h-[50vh]">
        <div className="w-12 h-12 rounded-full border-4 border-t-gold border-white/10 animate-spin mb-4"></div>
        <p className="font-serif text-slate-300 text-sm tracking-wider animate-pulse">Syncing administrative secure layers...</p>
      </div>
    );
  }

  // Render Access Blocked if user is not logged in or role != admin
  if (!currentUser || !currentUserProfile || currentUserProfile.role !== 'admin') {
    return (
      <div className="max-w-xl mx-auto my-16 p-8 rounded-3xl frosted-card border border-red-500/20 space-y-6 text-center shadow-2xl relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-red-500/10 rounded-full blur-3xl -z-10"></div>
        <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-amber-500/5 rounded-full blur-3xl -z-10"></div>
        
        <div className="w-16 h-16 mx-auto rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400 shadow-inner">
          <ShieldAlert className="w-8 h-8 animate-pulse" />
        </div>
        
        <div className="space-y-2">
          <h2 className="font-serif text-2xl font-bold text-white tracking-wide">
            Administrative Access Denied
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            The Secure Firestore Governance layer has restricted access. Only users registered with the <strong>Admin</strong> role are authorized to view global analytics and modify registries.
          </p>
          {currentUser && (
            <p className="text-xs text-amber-400 font-mono">
              Your Current Authenticated Role: <span className="uppercase font-bold">{currentUserProfile?.role || 'Unassigned'}</span>
            </p>
          )}
        </div>

        <div className="border-t border-white/10 pt-6 space-y-4">
          <p className="text-xs text-gray-400">
            <strong>Testing Node:</strong> Click below to elevate your logged-in Google Identity/Email to an Admin role in your Firestore database instance instantly.
          </p>
          
          <button
            onClick={simulateAdminElevation}
            disabled={actionLoading}
            className="w-full py-3 bg-gradient-to-r from-gold to-amber-500 hover:from-amber-500 hover:to-gold text-[#050B18] font-bold rounded-xl text-xs tracking-wider uppercase transition-all shadow-lg hover:scale-[1.02] cursor-pointer flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            {actionLoading ? 'Rewriting Registry...' : 'Simulate Admin Role (Developer Elevate)'}
          </button>
        </div>
      </div>
    );
  }

  // Filter lists
  const filteredUsers = users.filter(u => {
    const matchesSearch = u.displayName.toLowerCase().includes(userSearch.toLowerCase()) || 
                          u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
                          (u.phone && u.phone.includes(userSearch));
    const matchesRole = userRoleFilter === 'all' ? true : u.role === userRoleFilter;
    return matchesSearch && matchesRole;
  });

  const filteredAppts = appointments.filter(a => {
    const matchesSearch = a.userName.toLowerCase().includes(apptSearch.toLowerCase()) || 
                          a.doctorName.toLowerCase().includes(apptSearch.toLowerCase()) ||
                          a.specialty.toLowerCase().includes(apptSearch.toLowerCase());
    const matchesStatus = apptStatusFilter === 'all' ? true : a.status === apptStatusFilter;
    return matchesSearch && matchesStatus;
  });

  const filteredOrders = orders.filter(o => {
    const matchesSearch = o.userName.toLowerCase().includes(orderSearch.toLowerCase()) || 
                          o.id.toLowerCase().includes(orderSearch.toLowerCase());
    const matchesStatus = orderStatusFilter === 'all' ? true : o.status === orderStatusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 space-y-8 relative">
      
      {/* Background Orbs */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-gold/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>

      {/* Admin Dashboard Heading */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-0.5 rounded-full uppercase tracking-wider font-bold">
              Secure Governance Mode
            </span>
            <span className="text-xs text-gray-400 font-mono">
              Live Database Instance Synchronized
            </span>
          </div>
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-white mt-2 flex items-center gap-2">
            <Activity className="text-gold w-8 h-8" />
            Executive Admin Console
          </h2>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchAllRegistryData}
            disabled={actionLoading}
            className="p-3 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 rounded-xl transition-all cursor-pointer"
            title="Force Sync Database Snapshot"
          >
            <RefreshCw className={`w-4 h-4 ${actionLoading ? 'animate-spin text-gold' : ''}`} />
          </button>
          
          <button
            onClick={() => {
              setActiveTab('database');
            }}
            className="px-4 py-2.5 bg-emerald-dark/30 hover:bg-emerald-dark/50 text-emerald-300 border border-emerald-500/20 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Database className="w-4 h-4 text-emerald-400" />
            Database Seeding
          </button>
        </div>
      </div>

      {/* Success / Error Toast Alerts */}
      <AnimatePresence>
        {successMsg && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="p-4 bg-emerald-950/40 border border-emerald-500/20 text-emerald-300 rounded-2xl text-xs flex items-center gap-2"
          >
            <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{successMsg}</span>
          </motion.div>
        )}
        {errorMsg && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="p-4 bg-red-950/40 border border-red-500/20 text-red-300 rounded-2xl text-xs flex items-center gap-2"
          >
            <ShieldAlert className="w-5 h-5 text-red-400 shrink-0" />
            <span>{errorMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Core Tabs Switcher */}
      <div className="flex flex-wrap gap-2 border-b border-white/5 pb-2">
        <button
          onClick={() => setActiveTab('analytics')}
          className={`px-5 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'analytics'
              ? 'bg-gold text-[#050B18] shadow-lg'
              : 'bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          Analytics & Trends
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`px-5 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'users'
              ? 'bg-gold text-[#050B18] shadow-lg'
              : 'bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
        >
          <Users className="w-4 h-4" />
          User Registry ({users.length})
        </button>
        <button
          onClick={() => setActiveTab('appointments')}
          className={`px-5 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'appointments'
              ? 'bg-gold text-[#050B18] shadow-lg'
              : 'bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
        >
          <Calendar className="w-4 h-4" />
          Appointments ({appointments.length})
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-5 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'orders'
              ? 'bg-gold text-[#050B18] shadow-lg'
              : 'bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          Store Orders ({orders.length})
        </button>
        <button
          onClick={() => setActiveTab('database')}
          className={`px-5 py-3 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'database'
              ? 'bg-gold text-[#050B18] shadow-lg'
              : 'bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white'
          }`}
        >
          <Database className="w-4 h-4" />
          System Seeds
        </button>
      </div>

      {/* TAB CONTENTS CONTAINER */}
      <div className="mt-6">
        
        {/* TAB: ANALYTICS OVERVIEW */}
        {activeTab === 'analytics' && (
          <div className="space-y-8">
            {/* KPI Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              <div className="p-6 rounded-2xl border border-white/10 bg-white/5 flex items-center justify-between shadow-md">
                <div className="space-y-1">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Planetary Seekers</p>
                  <p className="text-3xl font-serif font-bold text-white">{totalUsersCount}</p>
                  <p className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1 mt-1">
                    <span>Registered in Firestore</span>
                  </p>
                </div>
                <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
                  <Users className="w-6 h-6" />
                </div>
              </div>

              <div className="p-6 rounded-2xl border border-white/10 bg-white/5 flex items-center justify-between shadow-md">
                <div className="space-y-1">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Clinical Consultations</p>
                  <p className="text-3xl font-serif font-bold text-white">{totalApptsCount}</p>
                  <p className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1 mt-1">
                    <span>{apptPendingCount} awaiting response</span>
                  </p>
                </div>
                <div className="p-3 bg-blue-500/10 text-blue-400 rounded-xl">
                  <Calendar className="w-6 h-6" />
                </div>
              </div>

              <div className="p-6 rounded-2xl border border-white/10 bg-white/5 flex items-center justify-between shadow-md">
                <div className="space-y-1">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">E-Commerce Orders</p>
                  <p className="text-3xl font-serif font-bold text-white">{totalOrdersCount}</p>
                  <p className="text-[10px] text-gold font-semibold flex items-center gap-1 mt-1">
                    <span>Rudraksha & Yantra sales</span>
                  </p>
                </div>
                <div className="p-3 bg-gold/10 text-gold rounded-xl">
                  <ShoppingBag className="w-6 h-6" />
                </div>
              </div>

              <div className="p-6 rounded-2xl border border-white/10 bg-white/5 flex items-center justify-between shadow-md">
                <div className="space-y-1">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Certified Revenue</p>
                  <p className="text-3xl font-serif font-bold text-white">₹{totalRevenue.toLocaleString()}</p>
                  <p className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1 mt-1">
                    <span>Completed / Paid invoice sum</span>
                  </p>
                </div>
                <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
                  <DollarSign className="w-6 h-6" />
                </div>
              </div>

            </div>

            {/* Visual Charts row (Custom high-quality SVGs matching theme) */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Chart 1: Seeker Breakdown by Spiritual Role */}
              <div className="p-6 rounded-3xl border border-white/10 bg-white/5 space-y-6 shadow">
                <h3 className="font-serif text-lg font-bold text-white flex items-center gap-2">
                  <Sliders className="text-gold w-5 h-5" />
                  Spiritual & Clinical Role Distribution
                </h3>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                    <p className="text-[10px] text-gray-400 font-bold">DOCTORS</p>
                    <p className="text-xl font-bold text-emerald-400">{doctorCount}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                    <p className="text-[10px] text-gray-400 font-bold">STUDENTS</p>
                    <p className="text-xl font-bold text-blue-400">{studentCount}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                    <p className="text-[10px] text-gray-400 font-bold">SEEKERS (USERS)</p>
                    <p className="text-xl font-bold text-gold">{seekerCount}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                    <p className="text-[10px] text-gray-400 font-bold">ADMINS</p>
                    <p className="text-xl font-bold text-white">{adminCount}</p>
                  </div>
                </div>

                {/* SVG Visual Bar Chart */}
                <div className="space-y-3 pt-2">
                  <p className="text-xs text-gray-400">Proportional Representation</p>
                  <div className="w-full bg-white/5 rounded-full h-8 overflow-hidden flex font-mono text-[10px] font-bold text-white">
                    {doctorCount > 0 && (
                      <div 
                        className="bg-emerald-500 flex items-center justify-center transition-all" 
                        style={{ width: `${(doctorCount / (totalUsersCount || 1)) * 100}%` }}
                        title={`Doctors: ${doctorCount}`}
                      >
                        {Math.round((doctorCount / (totalUsersCount || 1)) * 100)}%
                      </div>
                    )}
                    {studentCount > 0 && (
                      <div 
                        className="bg-blue-500 flex items-center justify-center transition-all" 
                        style={{ width: `${(studentCount / (totalUsersCount || 1)) * 100}%` }}
                        title={`Students: ${studentCount}`}
                      >
                        {Math.round((studentCount / (totalUsersCount || 1)) * 100)}%
                      </div>
                    )}
                    {seekerCount > 0 && (
                      <div 
                        className="bg-gold text-[#050B18] flex items-center justify-center transition-all" 
                        style={{ width: `${(seekerCount / (totalUsersCount || 1)) * 100}%` }}
                        title={`Seekers: ${seekerCount}`}
                      >
                        {Math.round((seekerCount / (totalUsersCount || 1)) * 100)}%
                      </div>
                    )}
                    {adminCount > 0 && (
                      <div 
                        className="bg-slate-500 flex items-center justify-center transition-all" 
                        style={{ width: `${(adminCount / (totalUsersCount || 1)) * 100}%` }}
                        title={`Admins: ${adminCount}`}
                      >
                        {Math.round((adminCount / (totalUsersCount || 1)) * 100)}%
                      </div>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs">
                    <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Doctor Experts</span>
                    <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span> Academy Students</span>
                    <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-gold"></span> Spiritual Seekers</span>
                    <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-slate-500"></span> Governance Admins</span>
                  </div>
                </div>

              </div>

              {/* Chart 2: Appointment Flow */}
              <div className="p-6 rounded-3xl border border-white/10 bg-white/5 space-y-6 shadow">
                <h3 className="font-serif text-lg font-bold text-white flex items-center gap-2">
                  <Clock className="text-gold w-5 h-5" />
                  Clinical Appointment Funnel
                </h3>

                <div className="grid grid-cols-4 gap-2 text-center text-xs">
                  <div className="p-2.5 rounded-xl bg-amber-500/5 border border-amber-500/20 text-amber-400">
                    <p className="text-[10px] uppercase font-bold text-amber-300">Pending</p>
                    <p className="text-lg font-bold">{apptPendingCount}</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-blue-500/5 border border-blue-500/20 text-blue-400">
                    <p className="text-[10px] uppercase font-bold text-blue-300">Accepted</p>
                    <p className="text-lg font-bold">{apptAcceptedCount}</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-emerald-500/5 border border-emerald-500/20 text-emerald-400">
                    <p className="text-[10px] uppercase font-bold text-emerald-300">Completed</p>
                    <p className="text-lg font-bold">{apptCompletedCount}</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-red-500/5 border border-red-500/20 text-red-400">
                    <p className="text-[10px] uppercase font-bold text-red-300">Rejected</p>
                    <p className="text-lg font-bold">{apptRejectedCount}</p>
                  </div>
                </div>

                {/* Interactive Horizontal Funnel Bar representation */}
                <div className="space-y-2">
                  <p className="text-xs text-gray-400">Total Consultation Pipeline</p>
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs text-slate-300 font-mono">
                      <span>Completed Remedial</span>
                      <span>{apptCompletedCount} of {totalApptsCount}</span>
                    </div>
                    <div className="w-full bg-white/5 rounded-full h-2 overflow-hidden">
                      <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${(apptCompletedCount / (totalApptsCount || 1)) * 100}%` }}></div>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs text-slate-300 font-mono">
                      <span>Scheduled Telehealth</span>
                      <span>{apptAcceptedCount} of {totalApptsCount}</span>
                    </div>
                    <div className="w-full bg-white/5 rounded-full h-2 overflow-hidden">
                      <div className="bg-blue-500 h-full rounded-full" style={{ width: `${(apptAcceptedCount / (totalApptsCount || 1)) * 100}%` }}></div>
                    </div>
                  </div>
                </div>

              </div>

            </div>

            {/* Bottom Section: System Parameters status */}
            <div className="p-6 rounded-3xl border border-white/10 bg-[#050B18]/40 space-y-4">
              <h4 className="font-serif text-base font-bold text-white flex items-center gap-1.5">
                <Sparkles className="text-gold w-4 h-4 animate-bounce" />
                Astronomical Alignment & System Status
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
                <div className="p-3 bg-white/5 rounded-xl border border-white/5 flex justify-between">
                  <span className="text-gray-400">Muhurat Database:</span>
                  <span className="text-emerald-400 font-bold">Synchronized</span>
                </div>
                <div className="p-3 bg-white/5 rounded-xl border border-white/5 flex justify-between">
                  <span className="text-gray-400">Active Google API proxy:</span>
                  <span className="text-emerald-400 font-bold">Secure SSL</span>
                </div>
                <div className="p-3 bg-white/5 rounded-xl border border-white/5 flex justify-between">
                  <span className="text-gray-400">Governance Scope:</span>
                  <span className="text-gold font-bold">Level 1 - Admin</span>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* TAB: USERS LIST */}
        {activeTab === 'users' && (
          <div className="space-y-6">
            
            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row gap-3 bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                <input 
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="Search by name, email, or contact..."
                  className="w-full pl-9 pr-4 py-2.5 bg-[#050B18]/60 rounded-xl border border-white/10 text-xs focus:outline-none focus:border-gold"
                />
              </div>

              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gold shrink-0" />
                <select
                  value={userRoleFilter}
                  onChange={(e) => setUserRoleFilter(e.target.value)}
                  className="px-3 py-2.5 bg-[#050B18] rounded-xl border border-white/10 text-xs text-white focus:outline-none"
                >
                  <option value="all">All Spiritual Roles</option>
                  <option value="user">Spiritual Seeker (User)</option>
                  <option value="doctor">Ayurvedic Expert (Doctor)</option>
                  <option value="student">Academy Student</option>
                  <option value="admin">Site Administrator</option>
                </select>
              </div>
            </div>

            {/* Users Table / List */}
            {filteredUsers.length === 0 ? (
              <div className="text-center py-16 bg-white/5 rounded-2xl border border-white/5">
                <UserX className="w-12 h-12 mx-auto text-slate-400 mb-3" />
                <p className="text-xs text-slate-300">No matching user records found in registry.</p>
              </div>
            ) : (
              <div className="overflow-x-auto rounded-2xl border border-white/10 bg-[#050B18]/40">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-white/10 bg-white/5 text-gray-400 uppercase font-mono text-[10px] font-bold">
                      <th className="p-4">Name / Registration</th>
                      <th className="p-4">Astronomical Calibrators</th>
                      <th className="p-4">Spiritual Role</th>
                      <th className="p-4">Residential Vastu</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-slate-200">
                    {filteredUsers.map((u) => (
                      <tr key={u.uid} className="hover:bg-white/5 transition-colors">
                        
                        <td className="p-4 space-y-1 max-w-xs">
                          <p className="font-serif text-sm font-bold text-white">{u.displayName}</p>
                          <p className="text-[10px] text-slate-400 font-mono">{u.email}</p>
                          {u.phone && <p className="text-[10px] text-emerald-400">{u.phone}</p>}
                        </td>

                        <td className="p-4 space-y-1">
                          {u.birthDate ? (
                            <>
                              <p className="font-mono text-[10px] text-white">📅 {u.birthDate}</p>
                              {u.birthTime && <p className="font-mono text-[10px] text-gold">⏰ {u.birthTime}</p>}
                              {u.birthPlace && <p className="text-gray-400 truncate max-w-[150px]" title={u.birthPlace}>📍 {u.birthPlace}</p>}
                            </>
                          ) : (
                            <span className="text-gray-500 italic">Not calibrated</span>
                          )}
                        </td>

                        <td className="p-4">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase border ${
                            u.role === 'admin'
                              ? 'bg-red-500/10 text-red-400 border-red-500/20'
                              : u.role === 'doctor'
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                              : u.role === 'student'
                              ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                              : 'bg-gold/10 text-gold border-gold/20'
                          }`}>
                            {u.role}
                          </span>
                        </td>

                        <td className="p-4 max-w-xs">
                          {u.vastuPreferences ? (
                            <p className="truncate text-slate-300 max-w-[180px]" title={u.vastuPreferences}>
                              {u.vastuPreferences}
                            </p>
                          ) : (
                            <span className="text-gray-500 italic">No custom configs</span>
                          )}
                        </td>

                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => setEditingUser(u)}
                              className="p-2 bg-white/5 hover:bg-white/10 text-gold rounded-lg transition-colors cursor-pointer"
                              title="Edit User Role & Parameters"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => setDeleteConfirmUser(u)}
                              className="p-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors cursor-pointer"
                              title="Purge User Registry"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>

                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* MODAL: EDIT USER ROLE/PARAMETERS */}
            {editingUser && (
              <div className="fixed inset-0 bg-[#050B18]/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
                <div className="w-full max-w-lg bg-[#050B18] border border-white/10 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl relative">
                  <div className="absolute top-4 right-4">
                    <button 
                      onClick={() => setEditingUser(null)}
                      className="text-gray-400 hover:text-white font-bold"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="border-b border-white/10 pb-4">
                    <h4 className="font-serif text-lg font-bold text-white flex items-center gap-1.5">
                      <Edit3 className="w-5 h-5 text-gold" />
                      Configure Celestial Identity
                    </h4>
                    <p className="text-xs text-gray-400 mt-1">
                      Edit user's administrative roles and cosmological coordinates directly.
                    </p>
                  </div>

                  <form onSubmit={handleSaveUserEdit} className="space-y-4 text-xs text-slate-300">
                    <div className="space-y-1">
                      <label className="block text-gray-400 uppercase font-bold text-[10px]">Display Name</label>
                      <input 
                        type="text"
                        required
                        value={editingUser.displayName}
                        onChange={(e) => setEditingUser({ ...editingUser, displayName: e.target.value })}
                        className="w-full px-3 py-2 bg-white/5 rounded-xl border border-white/10 text-xs focus:outline-none focus:border-gold"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="block text-gray-400 uppercase font-bold text-[10px]">Contact Phone</label>
                        <input 
                          type="tel"
                          value={editingUser.phone || ''}
                          onChange={(e) => setEditingUser({ ...editingUser, phone: e.target.value })}
                          className="w-full px-3 py-2 bg-white/5 rounded-xl border border-white/10 text-xs focus:outline-none focus:border-gold"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-gray-400 uppercase font-bold text-[10px]">Spiritual / Site Role</label>
                        <select
                          value={editingUser.role}
                          onChange={(e) => setEditingUser({ ...editingUser, role: e.target.value as UserRole })}
                          className="w-full px-3 py-2 bg-[#050B18] rounded-xl border border-white/10 text-xs text-white focus:outline-none focus:border-gold"
                        >
                          <option value="user">Spiritual Seeker (user)</option>
                          <option value="doctor">Ayurvedic Practitioner (doctor)</option>
                          <option value="student">Academy Student (student)</option>
                          <option value="admin">Administrator (admin)</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="block text-gray-400 uppercase font-bold text-[10px]">Birth Date</label>
                        <input 
                          type="date"
                          value={editingUser.birthDate || ''}
                          onChange={(e) => setEditingUser({ ...editingUser, birthDate: e.target.value })}
                          className="w-full px-3 py-2 bg-white/5 rounded-xl border border-white/10 text-xs focus:outline-none"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-gray-400 uppercase font-bold text-[10px]">Birth Time</label>
                        <input 
                          type="time"
                          value={editingUser.birthTime || ''}
                          onChange={(e) => setEditingUser({ ...editingUser, birthTime: e.target.value })}
                          className="w-full px-3 py-2 bg-white/5 rounded-xl border border-white/10 text-xs focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-gray-400 uppercase font-bold text-[10px]">Birth Place</label>
                      <input 
                        type="text"
                        value={editingUser.birthPlace || ''}
                        onChange={(e) => setEditingUser({ ...editingUser, birthPlace: e.target.value })}
                        className="w-full px-3 py-2 bg-white/5 rounded-xl border border-white/10 text-xs focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="block text-gray-400 uppercase font-bold text-[10px]">Vastu Preferences & Clinical Notes</label>
                      <textarea
                        rows={3}
                        value={editingUser.vastuPreferences || ''}
                        onChange={(e) => setEditingUser({ ...editingUser, vastuPreferences: e.target.value })}
                        className="w-full px-3 py-2 bg-white/5 rounded-xl border border-white/10 text-xs focus:outline-none resize-none"
                      />
                    </div>

                    <div className="flex gap-3 pt-3">
                      <button
                        type="submit"
                        disabled={actionLoading}
                        className="px-5 py-2.5 bg-gold hover:bg-amber-400 text-[#050B18] font-bold rounded-xl text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        Save Configuration
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingUser(null)}
                        className="px-5 py-2.5 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 rounded-xl text-xs font-bold transition-all cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>

                  </form>
                </div>
              </div>
            )}

            {/* MODAL: PURGE USER CONFIRMATION */}
            {deleteConfirmUser && (
              <div className="fixed inset-0 bg-[#050B18]/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
                <div className="w-full max-w-md bg-[#050B18] border border-red-500/20 rounded-3xl p-6 text-center space-y-6 shadow-2xl relative">
                  <div className="w-16 h-16 mx-auto rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400">
                    <UserX className="w-8 h-8" />
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-serif text-lg font-bold text-white">Purge Account Permanently?</h4>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Are you absolutely sure you want to remove <strong className="text-white">{deleteConfirmUser.displayName}</strong> ({deleteConfirmUser.email}) from the Firestore registry? This action is irreversible.
                    </p>
                  </div>

                  <div className="flex gap-3 justify-center">
                    <button
                      onClick={handleDeleteUser}
                      disabled={actionLoading}
                      className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider cursor-pointer"
                    >
                      Yes, Purge Document
                    </button>
                    <button
                      onClick={() => setDeleteConfirmUser(null)}
                      className="px-5 py-2.5 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 rounded-xl text-xs font-bold cursor-pointer"
                    >
                      Keep Seeker
                    </button>
                  </div>
                </div>
              </div>
            )}

          </div>
        )}

        {/* TAB: APPOINTMENTS REGISTRY */}
        {activeTab === 'appointments' && (
          <div className="space-y-6">
            
            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row gap-3 bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                <input 
                  type="text"
                  value={apptSearch}
                  onChange={(e) => setApptSearch(e.target.value)}
                  placeholder="Search by Seeker, Ayurvedic Practitioner, specialty..."
                  className="w-full pl-9 pr-4 py-2.5 bg-[#050B18]/60 rounded-xl border border-white/10 text-xs focus:outline-none focus:border-gold"
                />
              </div>

              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gold shrink-0" />
                <select
                  value={apptStatusFilter}
                  onChange={(e) => setApptStatusFilter(e.target.value)}
                  className="px-3 py-2.5 bg-[#050B18] rounded-xl border border-white/10 text-xs text-white focus:outline-none"
                >
                  <option value="all">All Consultation Statuses</option>
                  <option value="pending">Pending Response</option>
                  <option value="accepted">Accepted / Scheduled</option>
                  <option value="completed">Completed Remedial</option>
                  <option value="rejected">Rejected / Cancelled</option>
                </select>
              </div>
            </div>

            {/* Appointments Registry List */}
            {filteredAppts.length === 0 ? (
              <div className="text-center py-16 bg-white/5 rounded-2xl border border-white/5">
                <Calendar className="w-12 h-12 mx-auto text-slate-400 mb-3" />
                <p className="text-xs text-slate-300">No scheduled appointments match the filters.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredAppts.map((appt) => (
                  <div 
                    key={appt.id} 
                    className="p-5 rounded-2xl bg-[#050B18]/40 border border-white/10 space-y-4 relative overflow-hidden"
                  >
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5">
                          <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded ${
                            appt.status === 'completed'
                              ? 'bg-emerald-500/10 text-emerald-400'
                              : appt.status === 'accepted'
                              ? 'bg-blue-500/10 text-blue-400'
                              : appt.status === 'rejected'
                              ? 'bg-red-500/10 text-red-400'
                              : 'bg-amber-500/10 text-amber-400'
                          }`}>
                            {appt.status}
                          </span>
                          <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded ${
                            appt.paymentStatus === 'paid'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-slate-500/20 text-slate-300'
                          }`}>
                            {appt.paymentStatus}
                          </span>
                        </div>
                        <h4 className="font-serif text-base font-bold text-white pt-1">
                          Patient: {appt.userName}
                        </h4>
                        <p className="text-xs text-gold">Expert: {appt.doctorName}</p>
                        <p className="text-xs text-slate-400">{appt.specialty}</p>
                      </div>

                      <div className="text-right text-xs space-y-1">
                        <div className="text-white font-semibold flex items-center justify-end gap-1 font-mono">
                          <Calendar className="w-3.5 h-3.5 text-gold shrink-0" />
                          {appt.date}
                        </div>
                        <div className="text-slate-400 flex items-center justify-end gap-1 font-mono">
                          <Clock className="w-3.5 h-3.5 text-gold shrink-0" />
                          {appt.time}
                        </div>
                      </div>
                    </div>

                    {(appt.meetingLink || appt.prescription) && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-white/5 text-xs">
                        {appt.meetingLink && (
                          <div className="p-2.5 rounded-xl bg-blue-500/5 border border-blue-500/20">
                            <p className="text-[10px] text-blue-300 font-bold uppercase flex items-center gap-1">
                              <Video className="w-3 h-3" /> Telehealth URL
                            </p>
                            <a 
                              href={appt.meetingLink}
                              target="_blank"
                              rel="noreferrer"
                              className="text-blue-400 hover:underline flex items-center gap-1 mt-1 font-mono text-[11px]"
                            >
                              Join Call <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                        )}
                        {appt.prescription && (
                          <div className="p-2.5 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                            <p className="text-[10px] text-emerald-300 font-bold uppercase flex items-center gap-1">
                              <FileText className="w-3 h-3" /> Remedial Prescription
                            </p>
                            <p className="text-slate-300 text-[11px] mt-1 italic truncate" title={appt.prescription}>
                              "{appt.prescription}"
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                    <div className="pt-3 border-t border-white/5 flex gap-2">
                      <button
                        onClick={() => setEditingAppt(appt)}
                        className="px-4 py-2 bg-gold hover:bg-amber-400 text-[#050B18] font-bold rounded-lg text-xs uppercase cursor-pointer"
                      >
                        Reschedule & Transcribe
                      </button>
                    </div>

                  </div>
                ))}
              </div>
            )}

            {/* MODAL: RESCHEDULE / DISPENSE PRESCRIPTION */}
            {editingAppt && (
              <div className="fixed inset-0 bg-[#050B18]/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
                <div className="w-full max-w-lg bg-[#050B18] border border-white/10 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl relative">
                  <div className="absolute top-4 right-4">
                    <button 
                      onClick={() => setEditingAppt(null)}
                      className="text-gray-400 hover:text-white font-bold"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="border-b border-white/10 pb-4">
                    <h4 className="font-serif text-lg font-bold text-white flex items-center gap-1.5">
                      <Calendar className="w-5 h-5 text-gold" />
                      Manage Consultation Portals
                    </h4>
                    <p className="text-xs text-gray-400 mt-1">
                      Dispatch Google Meet video rooms and clinical spiritual prescriptions directly.
                    </p>
                  </div>

                  <form onSubmit={handleSaveApptEdit} className="space-y-4 text-xs text-slate-300">
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="block text-gray-400 uppercase font-bold text-[10px]">Session Date</label>
                        <input 
                          type="date"
                          required
                          value={editingAppt.date}
                          onChange={(e) => setEditingAppt({ ...editingAppt, date: e.target.value })}
                          className="w-full px-3 py-2 bg-white/5 rounded-xl border border-white/10 text-xs"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-gray-400 uppercase font-bold text-[10px]">Session Time</label>
                        <input 
                          type="text"
                          required
                          value={editingAppt.time}
                          onChange={(e) => setEditingAppt({ ...editingAppt, time: e.target.value })}
                          className="w-full px-3 py-2 bg-white/5 rounded-xl border border-white/10 text-xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="block text-gray-400 uppercase font-bold text-[10px]">Consultation Status</label>
                        <select
                          value={editingAppt.status}
                          onChange={(e) => setEditingAppt({ ...editingAppt, status: e.target.value as any })}
                          className="w-full px-3 py-2 bg-[#050B18] rounded-xl border border-white/10 text-xs text-white"
                        >
                          <option value="pending">pending (under review)</option>
                          <option value="accepted">accepted (scheduled)</option>
                          <option value="completed">completed (closed with remedies)</option>
                          <option value="rejected">rejected (canceled)</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="block text-gray-400 uppercase font-bold text-[10px]">Portal Link</label>
                        <div className="flex gap-1.5">
                          <input 
                            type="text"
                            value={editingAppt.meetingLink || ''}
                            onChange={(e) => setEditingAppt({ ...editingAppt, meetingLink: e.target.value })}
                            placeholder="https://meet.google.com/xyz"
                            className="flex-1 px-3 py-2 bg-white/5 rounded-xl border border-white/10 text-xs"
                          />
                          <button
                            type="button"
                            onClick={() => autoGenerateMeetLink(editingAppt.id)}
                            className="px-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-[10px] uppercase"
                            title="Generate Telehealth link"
                          >
                            Generate
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-gray-400 uppercase font-bold text-[10px]">Ayurvedic & Astrological Prescriptions</label>
                      <textarea
                        rows={4}
                        value={editingAppt.prescription || ''}
                        onChange={(e) => setEditingAppt({ ...editingAppt, prescription: e.target.value })}
                        placeholder="Wear specific Rudraksha mala; adjust bed compass directions; specific herbal formulations..."
                        className="w-full px-3 py-2 bg-white/5 rounded-xl border border-white/10 text-xs resize-none"
                      />
                    </div>

                    <div className="flex gap-3 pt-3">
                      <button
                        type="submit"
                        disabled={actionLoading}
                        className="px-5 py-2.5 bg-gold hover:bg-amber-400 text-[#050B18] font-bold rounded-xl text-xs uppercase tracking-wider disabled:opacity-50 cursor-pointer"
                      >
                        Save Configuration
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingAppt(null)}
                        className="px-5 py-2.5 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 rounded-xl text-xs font-bold transition-all cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>

                  </form>
                </div>
              </div>
            )}

          </div>
        )}

        {/* TAB: STORE ORDERS */}
        {activeTab === 'orders' && (
          <div className="space-y-6">
            
            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row gap-3 bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                <input 
                  type="text"
                  value={orderSearch}
                  onChange={(e) => setOrderSearch(e.target.value)}
                  placeholder="Search by Seeker Name or Order Invoice ID..."
                  className="w-full pl-9 pr-4 py-2.5 bg-[#050B18]/60 rounded-xl border border-white/10 text-xs focus:outline-none focus:border-gold"
                />
              </div>

              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gold shrink-0" />
                <select
                  value={orderStatusFilter}
                  onChange={(e) => setOrderStatusFilter(e.target.value)}
                  className="px-3 py-2.5 bg-[#050B18] rounded-xl border border-white/10 text-xs text-white focus:outline-none"
                >
                  <option value="all">All Delivery Statuses</option>
                  <option value="pending">Pending Processing</option>
                  <option value="processing">Processing Energetics</option>
                  <option value="shipped">Shipped Transit</option>
                  <option value="delivered">Delivered Secured</option>
                </select>
              </div>
            </div>

            {/* Orders Table */}
            {filteredOrders.length === 0 ? (
              <div className="text-center py-16 bg-white/5 rounded-2xl border border-white/5">
                <ShoppingBag className="w-12 h-12 mx-auto text-slate-400 mb-3" />
                <p className="text-xs text-slate-300">No transactions match the criteria.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredOrders.map((order) => (
                  <div 
                    key={order.id}
                    className="p-5 rounded-2xl bg-[#050B18]/40 border border-white/10 space-y-4"
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div>
                        <p className="text-[10px] font-mono text-gold uppercase font-bold">INVOICE ID: {order.id}</p>
                        <p className="text-xs text-white font-bold font-serif mt-1">Purchaser: {order.userName}</p>
                        <p className="text-[10px] text-gray-400">Date: {new Date(order.createdAt).toLocaleString()}</p>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className={`text-[10px] font-mono font-bold uppercase px-2.5 py-0.5 rounded-full border ${
                          order.status === 'delivered'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                            : order.status === 'shipped'
                            ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                            : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                        }`}>
                          {order.status}
                        </span>
                        
                        <p className="text-sm font-bold text-white font-mono">
                          ₹{order.total.toLocaleString()}
                        </p>

                        <button
                          onClick={() => setEditingOrder(order)}
                          className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-slate-300 rounded-lg text-xs"
                        >
                          Modify Status
                        </button>
                      </div>
                    </div>

                    {/* Order items list */}
                    <div className="divide-y divide-white/5 bg-[#050B18]/40 rounded-xl border border-white/5 overflow-hidden">
                      {order.items.map((item, index) => (
                        <div key={index} className="p-3 flex items-center justify-between gap-3 text-xs">
                          <div className="flex items-center gap-3">
                            {item.imageUrl && (
                              <img 
                                src={item.imageUrl} 
                                alt={item.name} 
                                className="w-10 h-10 object-cover rounded-lg border border-white/10"
                                referrerPolicy="no-referrer"
                              />
                            )}
                            <div>
                              <p className="font-semibold text-white">{item.name}</p>
                              <p className="text-[10px] text-slate-400">Qty: {item.quantity}</p>
                            </div>
                          </div>
                          <p className="font-mono font-semibold text-slate-300">₹{(item.price * item.quantity).toLocaleString()}</p>
                        </div>
                      ))}
                    </div>

                    {order.address && (
                      <p className="text-xs text-slate-300 bg-white/5 p-3 rounded-xl border border-white/5">
                        <span className="text-[10px] uppercase text-gray-400 font-bold block mb-1">Shipping Destination</span>
                        {order.address}
                      </p>
                    )}

                  </div>
                ))}
              </div>
            )}

            {/* MODAL: UPDATE ORDER STATUS */}
            {editingOrder && (
              <div className="fixed inset-0 bg-[#050B18]/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
                <div className="w-full max-w-md bg-[#050B18] border border-white/10 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl relative">
                  <div className="absolute top-4 right-4">
                    <button 
                      onClick={() => setEditingOrder(null)}
                      className="text-gray-400 hover:text-white font-bold"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="border-b border-white/10 pb-4">
                    <h4 className="font-serif text-lg font-bold text-white flex items-center gap-1.5">
                      <ShoppingBag className="w-5 h-5 text-gold" />
                      Dispatch Log & Alignment
                    </h4>
                    <p className="text-xs text-gray-400 mt-1">
                      Mark orders shipped transit or delivered after consecrating materials.
                    </p>
                  </div>

                  <form onSubmit={handleSaveOrderEdit} className="space-y-4 text-xs text-slate-300">
                    <div className="space-y-1">
                      <label className="block text-gray-400 uppercase font-bold text-[10px]">Shipping Log Address</label>
                      <textarea
                        rows={3}
                        value={editingOrder.address || ''}
                        onChange={(e) => setEditingOrder({ ...editingOrder, address: e.target.value })}
                        className="w-full px-3 py-2 bg-white/5 rounded-xl border border-white/10 text-xs resize-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="block text-gray-400 uppercase font-bold text-[10px]">Consignment Status</label>
                      <select
                        value={editingOrder.status}
                        onChange={(e) => setEditingOrder({ ...editingOrder, status: e.target.value as any })}
                        className="w-full px-3 py-2 bg-[#050B18] rounded-xl border border-white/10 text-xs text-white"
                      >
                        <option value="pending">pending (order registered)</option>
                        <option value="processing">processing (consecrating ritual)</option>
                        <option value="shipped">shipped (in transit/shipped)</option>
                        <option value="delivered">delivered (handover complete)</option>
                      </select>
                    </div>

                    <div className="flex gap-3 pt-3">
                      <button
                        type="submit"
                        disabled={actionLoading}
                        className="px-5 py-2.5 bg-gold hover:bg-amber-400 text-[#050B18] font-bold rounded-xl text-xs uppercase tracking-wider disabled:opacity-50 cursor-pointer"
                      >
                        Update Consignment status
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingOrder(null)}
                        className="px-5 py-2.5 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 rounded-xl text-xs font-bold transition-all cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

          </div>
        )}

        {/* TAB: DATABASE SEEDER / DEV TOOLS */}
        {activeTab === 'database' && (
          <div className="p-6 md:p-8 border border-white/10 bg-white/5 rounded-3xl space-y-6 shadow-xl">
            <div className="border-b border-white/10 pb-4">
              <h3 className="font-serif text-xl font-bold text-white flex items-center gap-2">
                <Database className="w-5 h-5 text-gold animate-bounce" />
                Spiritual Test Registry Seeder
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                A dev-friendly sandbox controller that populates Firestore with beautiful, realistic mock documents for immediate visual feedback.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              <div className="p-5 rounded-2xl bg-[#050B18]/50 border border-white/5 space-y-4">
                <h4 className="font-serif text-base font-bold text-gold flex items-center gap-1.5">
                  <Database className="w-4 h-4 text-gold" />
                  Seed Simulation Database
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Automatically generates:
                </p>
                <ul className="text-xs text-gray-400 list-disc list-inside space-y-1">
                  <li><strong>4 Users</strong> with custom birth, Vastu preference parameters</li>
                  <li><strong>3 Appointments</strong> under medical doctor and astrology expert</li>
                  <li><strong>2 E-commerce purchases</strong> containing consecrated items</li>
                </ul>

                <button
                  onClick={seedMockRegistry}
                  disabled={actionLoading}
                  className="w-full py-3 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl text-xs uppercase tracking-wider transition-all disabled:opacity-50 cursor-pointer"
                >
                  {actionLoading ? 'Writing to Firestore...' : 'Populate Test Registry'}
                </button>
              </div>

              <div className="p-5 rounded-2xl bg-[#050B18]/50 border border-white/5 space-y-4">
                <h4 className="font-serif text-base font-bold text-red-400 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4" />
                  Clear Simulator Nodes
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Removes mock elements generated by the seeder to restore your database to a clean production state.
                </p>
                <ul className="text-xs text-gray-400 list-disc list-inside space-y-1">
                  <li>Purges simulation accounts (`mock_doc_1`, `mock_user_1`, etc.)</li>
                  <li>Removes simulated appointments and scheduling charts</li>
                  <li>Deletes placeholder store orders and invoices</li>
                </ul>

                <button
                  onClick={clearMockRegistry}
                  disabled={actionLoading}
                  className="w-full py-3 bg-red-950/40 hover:bg-red-900/30 text-red-300 border border-red-500/20 font-bold rounded-xl text-xs uppercase tracking-wider transition-all disabled:opacity-50 cursor-pointer"
                >
                  {actionLoading ? 'Cleaning Database...' : 'Clear Simulated Nodes'}
                </button>
              </div>

            </div>

            <div className="p-4 rounded-xl bg-amber-500/5 border border-amber-500/20 text-xs text-amber-300 flex items-start gap-2 leading-relaxed">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                <strong>Privilege Notice:</strong> Seeding scripts make direct REST transactions via Firebase SDK. Read/write rules must be aligned with the Firestore schema. Elevated administrative privilege is enforced.
              </span>
            </div>

          </div>
        )}

      </div>

    </div>
  );
}
