import React, { useState } from 'react';
import { 
  Bookmark, 
  Search, 
  Clock, 
  MessageSquare, 
  ChevronRight, 
  User, 
  ArrowLeft, 
  Plus 
} from 'lucide-react';
import { INITIAL_BLOGS } from '../data';
import { BlogPost } from '../types';

export default function BlogSection() {
  const [blogs, setBlogs] = useState<BlogPost[]>(INITIAL_BLOGS);
  const [selectedBlog, setSelectedBlog] = useState<BlogPost | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');

  // Comment inputs
  const [commentName, setCommentName] = useState('');
  const [commentText, setCommentText] = useState('');

  // Categories list
  const categories = ['all', 'Spiritual Science', 'Medical Vastu'];

  // Filter blog posts
  const filteredBlogs = blogs.filter((post) => {
    const matchCat = activeCategory === 'all' || post.category === activeCategory;
    const matchSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        post.content.toLowerCase().includes(searchTerm.toLowerCase());
    return matchCat && matchSearch;
  });

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBlog || !commentName || !commentText) return;

    const newComment = {
      id: Math.random().toString(36).substring(2, 9),
      userName: commentName,
      comment: commentText,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    };

    const updatedBlogs = blogs.map((post) => {
      if (post.id === selectedBlog.id) {
        return {
          ...post,
          comments: [...post.comments, newComment]
        };
      }
      return post;
    });

    setBlogs(updatedBlogs);
    // Update active view
    setSelectedBlog({
      ...selectedBlog,
      comments: [...selectedBlog.comments, newComment]
    });

    setCommentName('');
    setCommentText('');
    alert('Thank you! Your insight has been posted to our SEO clinical forums.');
  };

  return (
    <div id="blog-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 dark:text-white">
      
      {/* Search Header (Visible if no blog selected) */}
      {!selectedBlog ? (
        <div className="space-y-8">
          <div className="text-center max-w-3xl mx-auto space-y-4">
            <h2 className="font-serif text-3xl md:text-4xl font-extrabold text-emerald-950 dark:text-white">
              HRCM Scientific Insights
            </h2>
            <p className="text-slate-600 dark:text-slate-400">
              Deep-dives into bio-electromagnetic medical sciences, planetary-astral cell polarization, and historical Siddha guidelines.
            </p>
          </div>

          {/* Filters & Search Row */}
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 border-b border-slate-100 dark:border-white/10 pb-4 max-w-4xl mx-auto">
            <div className="flex gap-2 text-xs font-semibold">
              {categories.map((cat) => (
                <button
                  key={cat}
                  id={`blog-filter-${cat}`}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4.5 py-1.5 rounded-full border transition-all capitalize ${
                    activeCategory === cat
                      ? 'bg-emerald-900 border-emerald-900 text-white font-bold'
                      : 'border-slate-200 dark:border-slate-800'
                  }`}
                >
                  {cat === 'all' ? 'All Publications' : cat}
                </button>
              ))}
            </div>

            <div className="relative text-xs w-full md:w-auto">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search articles..."
                className="w-full md:w-56 pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-full focus:outline-none"
              />
              <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
            </div>
          </div>

          {/* Articles list layout */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {filteredBlogs.map((post) => (
              <div 
                key={post.id}
                className="bg-white dark:bg-slate-900 rounded-2xl overflow-hidden border border-slate-100 dark:border-white/5 shadow-md flex flex-col hover:shadow-xl transition-all"
              >
                <div className="h-48 overflow-hidden">
                  <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-[10px] font-mono font-bold text-slate-400 uppercase">
                      <span>{post.category}</span>
                      <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {post.readTime}</span>
                    </div>
                    <h3 className="font-serif font-bold text-emerald-950 dark:text-white text-base md:text-lg leading-tight hover:underline cursor-pointer" onClick={() => setSelectedBlog(post)}>
                      {post.title}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                      {post.excerpt}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-slate-100 dark:border-white/5 flex justify-between items-center text-xs">
                    <span className="font-semibold text-slate-700 dark:text-slate-300">By {post.author}</span>
                    <button
                      id={`read-blog-${post.id}`}
                      onClick={() => setSelectedBlog(post)}
                      className="text-emerald-900 dark:text-emerald-400 font-bold hover:underline flex items-center gap-1"
                    >
                      Read Full Article <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      ) : (
        /* Expanded Article View with Comments section */
        <div className="max-w-3xl mx-auto space-y-8">
          
          <button
            id="back-to-blogs"
            onClick={() => setSelectedBlog(null)}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-900 dark:text-emerald-400 hover:underline"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Insights Library
          </button>

          <article className="space-y-6">
            <div className="space-y-3">
              <span className="text-xs font-mono font-bold text-amber-600 dark:text-amber-500 uppercase bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">{selectedBlog.category}</span>
              <h1 className="font-serif text-2xl md:text-4xl font-extrabold text-emerald-950 dark:text-white leading-tight">
                {selectedBlog.title}
              </h1>
              <div className="flex items-center gap-4 text-xs text-slate-500">
                <span className="flex items-center gap-1"><User className="w-4 h-4" /> By {selectedBlog.author}</span>
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {selectedBlog.readTime}</span>
                <span>Published on {selectedBlog.date}</span>
              </div>
            </div>

            <div className="h-64 md:h-80 rounded-2xl overflow-hidden shadow">
              <img src={selectedBlog.imageUrl} alt={selectedBlog.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>

            {/* Markdown simulated text */}
            <div className="text-slate-700 dark:text-slate-300 leading-relaxed text-sm whitespace-pre-wrap font-sans space-y-4 pt-4">
              {selectedBlog.content}
            </div>
          </article>

          {/* Comments section */}
          <div className="border-t border-slate-200 dark:border-white/10 pt-8 space-y-6">
            <h3 className="font-serif text-lg font-bold text-emerald-950 dark:text-white flex items-center gap-1.5">
              <MessageSquare className="w-5 h-5 text-emerald-600" /> Forum Comments ({selectedBlog.comments.length})
            </h3>

            {/* Existing Comments list */}
            <div className="space-y-4">
              {selectedBlog.comments.length > 0 ? (
                selectedBlog.comments.map((comm) => (
                  <div key={comm.id} className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-white/5 text-xs space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-emerald-950 dark:text-slate-300">{comm.userName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{comm.date}</span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-400">"{comm.comment}"</p>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-500 italic">No comments posted yet. Start the clinical debate below.</p>
              )}
            </div>

            {/* Post comment form */}
            <form onSubmit={handlePostComment} className="space-y-4 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800/40 p-6 rounded-2xl border border-slate-100">
              <p className="font-bold uppercase text-xs text-slate-500">Post Forum Insight</p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-500 mb-1 font-semibold">Your Name</label>
                  <input
                    type="text"
                    required
                    value={commentName}
                    onChange={(e) => setCommentName(e.target.value)}
                    placeholder="e.g. Nabin Choudhary"
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-500 mb-1 font-semibold">Your Comment</label>
                <textarea
                  required
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Share your experience with non-demolition vastu modifications or wearing Nepalese beads..."
                  rows={3}
                  className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                id="submit-blog-comment"
                className="px-6 py-2.5 bg-emerald-900 hover:bg-emerald-800 text-white font-bold rounded-lg text-xs uppercase"
              >
                Post Comment
              </button>
            </form>

          </div>

        </div>
      )}

    </div>
  );
}
