import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Cookie, X, Settings2, ShieldCheck, Sparkles, AlertCircle } from 'lucide-react';

interface CookiePreferences {
  essential: boolean;
  analytics: boolean;
  marketing: boolean;
}

export default function CookieConsent() {
  const [isVisible, setIsVisible] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [preferences, setPreferences] = useState<CookiePreferences>({
    essential: true,
    analytics: true,
    marketing: false,
  });

  useEffect(() => {
    // Check if user has already made a choice
    const consent = localStorage.getItem('hrcm-cookie-consent');
    if (!consent) {
      // Small timeout to give entering animation a premium delay
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAcceptAll = () => {
    const choice = {
      essential: true,
      analytics: true,
      marketing: true,
    };
    localStorage.setItem('hrcm-cookie-consent', JSON.stringify(choice));
    setIsVisible(false);
  };

  const handleDeclineNonEssential = () => {
    const choice = {
      essential: true,
      analytics: false,
      marketing: false,
    };
    localStorage.setItem('hrcm-cookie-consent', JSON.stringify(choice));
    setIsVisible(false);
  };

  const handleSavePreferences = () => {
    localStorage.setItem('hrcm-cookie-consent', JSON.stringify(preferences));
    setIsVisible(false);
  };

  const togglePreference = (key: keyof CookiePreferences) => {
    if (key === 'essential') return; // Essential is always locked
    setPreferences(prev => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 100, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 80, scale: 0.95 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="fixed bottom-6 left-4 right-4 md:left-6 md:right-auto md:max-w-md lg:max-w-xl z-50 p-[1px] rounded-3xl bg-gradient-to-tr from-gold/30 via-white/5 to-emerald-400/20 shadow-2xl backdrop-blur-2xl"
          style={{
            background: 'rgba(255, 255, 255, 0.04)',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            boxShadow: '0 20px 50px rgba(5, 11, 24, 0.8), inset 0 1px 1px rgba(255, 255, 255, 0.1)'
          }}
        >
          <div className="p-6 md:p-8 space-y-6">
            
            {/* Header */}
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-gold/20 to-emerald-400/20 flex items-center justify-center border border-white/10 text-gold shadow-lg">
                  <Cookie className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-bold tracking-wider text-gold flex items-center gap-1.5">
                    Cosmic Calibration Cookies
                  </h3>
                  <p className="text-[10px] text-emerald-400 uppercase tracking-widest font-semibold">
                    Optimal Alignment & Security
                  </p>
                </div>
              </div>
              <button
                onClick={handleDeclineNonEssential}
                className="p-1.5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                title="Dismiss and Accept Essential Only"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Description or Preferences Switcher */}
            <div className="text-xs text-slate-300 leading-relaxed space-y-4">
              {!showPreferences ? (
                <p>
                  To optimize your spiritual and medical guidance, HRCM Mentor utilizes essential diagnostic state cookies, sacred Vastu angle caching, and Chaldean calculation preferences. By accepting, you consent to aligning ancient astronomical parameters with modern client metrics.
                </p>
              ) : (
                <div className="space-y-3 pt-2">
                  {/* Essential Cookies */}
                  <div className="flex items-start justify-between p-3 rounded-xl bg-white/5 border border-white/5">
                    <div className="flex-grow pr-4">
                      <div className="flex items-center gap-1.5 font-bold text-white text-xs">
                        <ShieldCheck className="w-4 h-4 text-emerald-400" />
                        Essential Calibration
                      </div>
                      <p className="text-[10px] text-slate-400 mt-1 leading-normal">
                        Maintains secure authentications, cart selections, and essential planetary chart caching. (Always Required)
                      </p>
                    </div>
                    <div className="text-[10px] uppercase font-mono px-2 py-1 bg-white/10 border border-white/5 rounded-md text-emerald-400 font-semibold self-center">
                      Required
                    </div>
                  </div>

                  {/* Spiritual Analytics */}
                  <button
                    onClick={() => togglePreference('analytics')}
                    className="w-full text-left flex items-start justify-between p-3 rounded-xl hover:bg-white/5 bg-white/5 border border-white/5 transition-all cursor-pointer group"
                  >
                    <div className="flex-grow pr-4">
                      <div className="flex items-center gap-1.5 font-bold text-white text-xs group-hover:text-gold transition-colors">
                        <Sparkles className="w-4 h-4 text-gold" />
                        Planetary Analytics
                      </div>
                      <p className="text-[10px] text-slate-400 mt-1 leading-normal">
                        Aggregates anonymous transit tuning behavior to continuously align our AI mentor algorithms and chart tools.
                      </p>
                    </div>
                    <div className="self-center">
                      <div className={`w-10 h-6 rounded-full p-1 transition-colors duration-200 ${preferences.analytics ? 'bg-gold' : 'bg-white/15'}`}>
                        <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-200 ${preferences.analytics ? 'translate-x-4' : 'translate-x-0'}`}></div>
                      </div>
                    </div>
                  </button>

                  {/* Clinical Outreach & Marketing */}
                  <button
                    onClick={() => togglePreference('marketing')}
                    className="w-full text-left flex items-start justify-between p-3 rounded-xl hover:bg-white/5 bg-white/5 border border-white/5 transition-all cursor-pointer group"
                  >
                    <div className="flex-grow pr-4">
                      <div className="flex items-center gap-1.5 font-bold text-white text-xs group-hover:text-gold transition-colors">
                        <AlertCircle className="w-4 h-4 text-emerald-400" />
                        Outreach & Alerts
                      </div>
                      <p className="text-[10px] text-slate-400 mt-1 leading-normal">
                        Notifies you of exclusive live masterclasses with Dr. Nabin K. Choudhary, astro-events, and Vastu discounts.
                      </p>
                    </div>
                    <div className="self-center">
                      <div className={`w-10 h-6 rounded-full p-1 transition-colors duration-200 ${preferences.marketing ? 'bg-gold' : 'bg-white/15'}`}>
                        <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-200 ${preferences.marketing ? 'translate-x-4' : 'translate-x-0'}`}></div>
                      </div>
                    </div>
                  </button>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
              {!showPreferences ? (
                <>
                  <button
                    onClick={handleAcceptAll}
                    className="w-full sm:flex-1 py-2.5 px-4 rounded-full bg-gold hover:bg-amber-400 text-[#050B18] font-bold text-xs transition-all tracking-wider shadow-lg hover:scale-[1.02] cursor-pointer"
                  >
                    Accept Cosmic Alignment
                  </button>
                  <div className="w-full sm:w-auto flex items-center gap-3">
                    <button
                      onClick={() => setShowPreferences(true)}
                      className="flex-1 sm:flex-none py-2.5 px-4 rounded-full bg-white/5 hover:bg-white/10 text-slate-200 hover:text-white border border-white/10 font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Settings2 className="w-3.5 h-3.5 text-gold" />
                      Configure
                    </button>
                    <button
                      onClick={handleDeclineNonEssential}
                      className="flex-1 sm:flex-none py-2.5 px-4 rounded-full text-slate-400 hover:text-white font-medium text-xs transition-all hover:bg-white/5"
                    >
                      Decline
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <button
                    onClick={handleSavePreferences}
                    className="w-full sm:flex-1 py-2.5 px-4 rounded-full bg-gold hover:bg-amber-400 text-[#050B18] font-bold text-xs transition-all tracking-wider shadow-lg hover:scale-[1.02] cursor-pointer"
                  >
                    Confirm Choice
                  </button>
                  <button
                    onClick={() => setShowPreferences(false)}
                    className="w-full sm:w-auto py-2.5 px-4 rounded-full bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 font-bold text-xs transition-all cursor-pointer"
                  >
                    Back
                  </button>
                </>
              )}
            </div>

          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
