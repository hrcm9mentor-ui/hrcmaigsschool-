import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Mail, 
  Phone, 
  Calendar, 
  Clock, 
  MapPin, 
  Sparkles, 
  ShoppingBag, 
  BookOpen, 
  ShieldCheck, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Edit3, 
  Save, 
  ExternalLink, 
  Lock, 
  FileText, 
  Video, 
  ChevronRight,
  Activity,
  Heart
} from 'lucide-react';
import { 
  auth, 
  db, 
  getUserProfile, 
  updateUserProfile, 
  getUserAppointments, 
  getUserOrders, 
  updateAppointmentStatus,
  getUserWishlist,
  removeFromWishlist
} from '../lib/firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { UserProfile, Appointment, Order, WishlistItem } from '../types';

export default function UserProfileView() {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [wishlist, setWishlist] = useState<WishlistItem[]>([]);
  
  const [activeSubTab, setActiveSubTab] = useState<'details' | 'bookings' | 'orders' | 'courses' | 'wishlist'>('details');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Editable Profile Form State
  const [editMode, setEditMode] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [phone, setPhone] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [birthTime, setBirthTime] = useState('');
  const [birthPlace, setBirthPlace] = useState('');
  const [vastuPreferences, setVastuPreferences] = useState('');

  // Doctor Action States
  const [selectedAppointmentId, setSelectedAppointmentId] = useState<string | null>(null);
  const [meetingLink, setMeetingLink] = useState('');
  const [prescription, setPrescription] = useState('');
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setCurrentUser(firebaseUser);
      if (firebaseUser) {
        try {
          setLoading(true);
          const userProfile = await getUserProfile(firebaseUser.uid);
          if (userProfile) {
            setProfile(userProfile);
            setDisplayName(userProfile.displayName || '');
            setPhone(userProfile.phone || '');
            setBirthDate(userProfile.birthDate || '');
            setBirthTime(userProfile.birthTime || '');
            setBirthPlace(userProfile.birthPlace || '');
            setVastuPreferences(userProfile.vastuPreferences || '');

            // Load related transactions / bookings
            const appts = await getUserAppointments(firebaseUser.uid, userProfile.role === 'doctor' ? 'doctor' : 'user');
            setAppointments(appts);

            const userOrders = await getUserOrders(firebaseUser.uid);
            setOrders(userOrders);

            const userWishlist = await getUserWishlist(firebaseUser.uid);
            setWishlist(userWishlist);
          }
        } catch (err: any) {
          console.error("Error loading user data:", err);
          setErrorMsg("Failed to synchronize account details from Firestore.");
        } finally {
          setLoading(false);
        }
      } else {
        setProfile(null);
        setAppointments([]);
        setOrders([]);
        setWishlist([]);
        setLoading(false);
      }
    });

    return unsubscribe;
  }, []);

  // Helper to re-fetch bookings and orders dynamically
  const refreshUserData = async () => {
    if (!currentUser || !profile) return;
    try {
      const appts = await getUserAppointments(currentUser.uid, profile.role === 'doctor' ? 'doctor' : 'user');
      setAppointments(appts);
      const userOrders = await getUserOrders(currentUser.uid);
      setOrders(userOrders);
      const userWishlist = await getUserWishlist(currentUser.uid);
      setWishlist(userWishlist);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setSaving(true);
    setSuccessMsg('');
    setErrorMsg('');

    try {
      const updates = {
        displayName,
        phone,
        birthDate,
        birthTime,
        birthPlace,
        vastuPreferences
      };
      
      await updateUserProfile(currentUser.uid, updates);
      
      setProfile(prev => prev ? { ...prev, ...updates } : null);
      setSuccessMsg('Your cosmic parameters have been securely aligned and saved.');
      setEditMode(false);
      
      // Auto dismiss success message
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update profile settings.');
    } finally {
      setSaving(false);
    }
  };

  const handleUpdateStatus = async (
    apptId: string, 
    newStatus: 'accepted' | 'rejected' | 'completed'
  ) => {
    setActionLoading(true);
    setErrorMsg('');
    setSuccessMsg('');

    try {
      await updateAppointmentStatus(
        apptId, 
        newStatus, 
        newStatus === 'completed' ? prescription : undefined,
        meetingLink || undefined
      );
      
      setSuccessMsg(`Consultation has been successfully marked as ${newStatus}.`);
      setSelectedAppointmentId(null);
      setMeetingLink('');
      setPrescription('');
      
      // Reload appointment snapshot
      await refreshUserData();
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to change consultation status.');
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 flex flex-col items-center justify-center min-h-[50vh]">
        <div className="w-12 h-12 rounded-full border-4 border-t-gold border-white/10 animate-spin mb-4"></div>
        <p className="font-serif text-slate-300 text-sm tracking-wider animate-pulse">Syncing spiritual registry...</p>
      </div>
    );
  }

  if (!currentUser || !profile) {
    return (
      <div className="max-w-md mx-auto my-16 p-8 rounded-3xl frosted-card border border-white/10 space-y-6 text-center shadow-2xl relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-gold/10 rounded-full blur-3xl -z-10"></div>
        <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-emerald-500/5 rounded-full blur-3xl -z-10"></div>
        
        <div className="w-16 h-16 mx-auto rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-gold shadow-inner">
          <Lock className="w-8 h-8 animate-bounce" />
        </div>
        
        <div className="space-y-2">
          <h2 className="font-serif text-2xl font-bold text-white tracking-wide">
            Access Portal Locked
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            Please sign in using your verified email or Google Identity to view your personalized consultations, order histories, and astrological configurations.
          </p>
        </div>

        <button
          onClick={() => {
            const loginBtn = document.getElementById('login-button');
            if (loginBtn) loginBtn.click();
          }}
          className="w-full py-3 bg-gold hover:bg-amber-400 text-[#050B18] font-bold rounded-xl text-xs tracking-wider uppercase transition-all shadow-lg hover:scale-105 cursor-pointer"
        >
          Sign In Now
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-16 space-y-8 relative">
      
      {/* Visual background accents */}
      <div className="absolute top-10 right-10 w-80 h-80 bg-gold/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>

      {/* Header Profile Summary */}
      <div className="relative rounded-3xl p-6 md:p-8 frosted-card border border-white/10 overflow-hidden flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="flex items-center gap-5">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-gold to-emerald-dark p-[1px] flex items-center justify-center shadow-lg relative">
            <div className="w-full h-full bg-[#050B18] rounded-[15px] flex items-center justify-center text-gold">
              <User className="w-10 h-10" />
            </div>
            <div className="absolute -bottom-2 -right-2 bg-emerald-500 text-white p-1 rounded-full border-2 border-[#050B18] shadow">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-serif text-2xl md:text-3xl font-bold text-white">
                {profile.displayName}
              </h2>
              <span className="text-xs font-mono bg-gold/10 text-gold border border-gold/20 px-2.5 py-0.5 rounded-full uppercase tracking-wider font-bold">
                {profile.role}
              </span>
            </div>
            <p className="text-slate-300 text-sm flex items-center gap-1.5 mt-1">
              <Mail className="w-4 h-4 text-emerald-400" />
              {profile.email}
            </p>
            <p className="text-xs text-gray-400 font-mono mt-1">
              Registry Joined: {new Date(profile.createdAt).toLocaleDateString(undefined, { dateStyle: 'long' })}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              setActiveSubTab('details');
              setEditMode(true);
            }}
            className="px-4 py-2 bg-white/5 hover:bg-white/10 text-slate-200 hover:text-white border border-white/10 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Edit3 className="w-4 h-4 text-gold" />
            Edit Profile
          </button>
          <button
            onClick={refreshUserData}
            className="px-4 py-2 bg-emerald-dark/30 hover:bg-emerald-dark/50 text-emerald-300 border border-emerald-500/20 rounded-xl text-xs font-bold transition-all cursor-pointer"
          >
            Sync Live Status
          </button>
        </div>
      </div>

      {/* Success / Error Alerts */}
      <AnimatePresence>
        {successMsg && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="p-4 bg-emerald-950/40 border border-emerald-500/20 text-emerald-300 rounded-2xl text-xs flex items-center gap-2"
          >
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{successMsg}</span>
          </motion.div>
        )}
        {errorMsg && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="p-4 bg-red-950/40 border border-red-500/20 text-red-300 rounded-2xl text-xs flex items-center gap-2"
          >
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
            <span>{errorMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Profile Sections Nav Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Left Sub-navigation */}
        <div className="lg:col-span-1 space-y-2">
          <button
            onClick={() => { setActiveSubTab('details'); setEditMode(false); }}
            className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all border ${
              activeSubTab === 'details'
                ? 'bg-gradient-to-r from-white/10 to-white/5 border-gold text-gold font-bold shadow-md'
                : 'bg-white/5 border-white/5 text-slate-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-3">
              <User className="w-5 h-5" />
              Account Settings
            </span>
            <ChevronRight className="w-4 h-4 opacity-50" />
          </button>

          <button
            onClick={() => { setActiveSubTab('bookings'); }}
            className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all border ${
              activeSubTab === 'bookings'
                ? 'bg-gradient-to-r from-white/10 to-white/5 border-gold text-gold font-bold shadow-md'
                : 'bg-white/5 border-white/5 text-slate-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-3">
              <Calendar className="w-5 h-5" />
              {profile.role === 'doctor' ? 'Clinical Schedules' : 'Consultations'}
            </span>
            {appointments.length > 0 && (
              <span className="bg-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                {appointments.length}
              </span>
            )}
          </button>

          <button
            onClick={() => { setActiveSubTab('orders'); }}
            className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all border ${
              activeSubTab === 'orders'
                ? 'bg-gradient-to-r from-white/10 to-white/5 border-gold text-gold font-bold shadow-md'
                : 'bg-white/5 border-white/5 text-slate-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-3">
              <ShoppingBag className="w-5 h-5" />
              My Orders
            </span>
            {orders.length > 0 && (
              <span className="bg-gold text-[#050B18] text-[10px] font-bold px-2 py-0.5 rounded-full">
                {orders.length}
              </span>
            )}
          </button>

          <button
            onClick={() => { setActiveSubTab('courses'); }}
            className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all border ${
              activeSubTab === 'courses'
                ? 'bg-gradient-to-r from-white/10 to-white/5 border-gold text-gold font-bold shadow-md'
                : 'bg-white/5 border-white/5 text-slate-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-3">
              <BookOpen className="w-5 h-5" />
              Course Enrollments
            </span>
            <ChevronRight className="w-4 h-4 opacity-50" />
          </button>

          <button
            onClick={() => { setActiveSubTab('wishlist'); }}
            className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all border ${
              activeSubTab === 'wishlist'
                ? 'bg-gradient-to-r from-white/10 to-white/5 border-gold text-gold font-bold shadow-md'
                : 'bg-white/5 border-white/5 text-slate-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-3">
              <Heart className="w-5 h-5 text-red-400" />
              My Wishlist
            </span>
            {wishlist.length > 0 && (
              <span className="bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                {wishlist.length}
              </span>
            )}
          </button>
        </div>

        {/* Right Content Panel */}
        <div className="lg:col-span-3">
          <div className="frosted-card rounded-3xl p-6 md:p-8 border border-white/10 space-y-6">
            
            {/* SUB-TAB: ACCOUNT DETAILS */}
            {activeSubTab === 'details' && (
              <div className="space-y-6">
                <div className="border-b border-white/10 pb-4">
                  <h3 className="font-serif text-xl font-bold text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-gold" />
                    Spiritual & Clinical Identity
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Your cosmological inputs calibrate the planetary calculations and vastu axes.
                  </p>
                </div>

                {!editMode ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-white/5 rounded-2xl border border-white/5 text-xs space-y-1">
                      <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Seeker Display Name</p>
                      <p className="font-semibold text-white text-sm">{profile.displayName}</p>
                    </div>

                    <div className="p-4 bg-white/5 rounded-2xl border border-white/5 text-xs space-y-1">
                      <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Contact Number</p>
                      <p className="font-semibold text-white text-sm">{profile.phone || 'Not provided'}</p>
                    </div>

                    <div className="p-4 bg-white/5 rounded-2xl border border-white/5 text-xs space-y-1">
                      <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Birth Date (Calibrator)</p>
                      <p className="font-semibold text-white text-sm">{profile.birthDate || 'Not provided'}</p>
                    </div>

                    <div className="p-4 bg-white/5 rounded-2xl border border-white/5 text-xs space-y-1">
                      <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Birth Time (Muhurat)</p>
                      <p className="font-semibold text-white text-sm">{profile.birthTime || 'Not provided'}</p>
                    </div>

                    <div className="p-4 bg-white/5 rounded-2xl border border-white/5 text-xs space-y-1 md:col-span-2">
                      <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Birth Place (Astronomical Coordinates)</p>
                      <p className="font-semibold text-white text-sm">{profile.birthPlace || 'Not provided'}</p>
                    </div>

                    <div className="p-4 bg-white/5 rounded-2xl border border-white/5 text-xs space-y-1 md:col-span-2">
                      <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Medical Vastu Alignments / Notes</p>
                      <p className="font-semibold text-white text-sm leading-relaxed">
                        {profile.vastuPreferences || 'No custom spatial configurations entered.'}
                      </p>
                    </div>

                    <div className="md:col-span-2 pt-2">
                      <button
                        onClick={() => setEditMode(true)}
                        className="px-5 py-3 bg-gold text-[#050B18] hover:bg-amber-400 font-bold rounded-xl text-xs uppercase tracking-wider transition-all cursor-pointer"
                      >
                        Edit Information
                      </button>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSaveProfile} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="block text-[10px] text-gray-300 font-bold uppercase tracking-wider">Full Name</label>
                        <input
                          type="text"
                          required
                          value={displayName}
                          onChange={(e) => setDisplayName(e.target.value)}
                          className="w-full px-4 py-3 bg-white/5 rounded-xl border border-white/10 text-xs focus:outline-none focus:border-gold"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="block text-[10px] text-gray-300 font-bold uppercase tracking-wider">Contact Phone</label>
                        <input
                          type="tel"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="e.g. +91 7906596613"
                          className="w-full px-4 py-3 bg-white/5 rounded-xl border border-white/10 text-xs focus:outline-none focus:border-gold"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="block text-[10px] text-gray-300 font-bold uppercase tracking-wider">Birth Date</label>
                        <input
                          type="date"
                          value={birthDate}
                          onChange={(e) => setBirthDate(e.target.value)}
                          className="w-full px-4 py-3 bg-white/5 rounded-xl border border-white/10 text-xs text-white focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="block text-[10px] text-gray-300 font-bold uppercase tracking-wider">Birth Time</label>
                        <input
                          type="time"
                          value={birthTime}
                          onChange={(e) => setBirthTime(e.target.value)}
                          className="w-full px-4 py-3 bg-white/5 rounded-xl border border-white/10 text-xs text-white focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1.5 md:col-span-2">
                        <label className="block text-[10px] text-gray-300 font-bold uppercase tracking-wider">Birth Place</label>
                        <input
                          type="text"
                          value={birthPlace}
                          onChange={(e) => setBirthPlace(e.target.value)}
                          placeholder="e.g. Ghaziabad, Uttar Pradesh, India"
                          className="w-full px-4 py-3 bg-white/5 rounded-xl border border-white/10 text-xs focus:outline-none focus:border-gold"
                        />
                      </div>

                      <div className="space-y-1.5 md:col-span-2">
                        <label className="block text-[10px] text-gray-300 font-bold uppercase tracking-wider">Vastu Spatial Preferences / Chronic Ailments</label>
                        <textarea
                          rows={3}
                          value={vastuPreferences}
                          onChange={(e) => setVastuPreferences(e.target.value)}
                          placeholder="Specify compass sleeping direction, residential anomalies, or general clinical remarks for Dr. Nabin K. Choudhary."
                          className="w-full px-4 py-3 bg-white/5 rounded-xl border border-white/10 text-xs focus:outline-none focus:border-gold resize-none"
                        />
                      </div>
                    </div>

                    <div className="flex gap-3 pt-2">
                      <button
                        type="submit"
                        disabled={saving}
                        className="px-5 py-3 bg-gold hover:bg-amber-400 text-[#050B18] font-bold rounded-xl text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <Save className="w-4 h-4" />
                        {saving ? 'Aligning...' : 'Save Settings'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditMode(false)}
                        className="px-5 py-3 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 rounded-xl text-xs font-bold transition-all cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                )}
              </div>
            )}

            {/* SUB-TAB: BOOKINGS & CONSULTATIONS */}
            {activeSubTab === 'bookings' && (
              <div className="space-y-6">
                <div className="border-b border-white/10 pb-4">
                  <h3 className="font-serif text-xl font-bold text-white flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-gold" />
                    {profile.role === 'doctor' ? 'Clinical Consultations Registry' : 'Doctor Appointments'}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    {profile.role === 'doctor' 
                      ? 'Process incoming consultation requests, schedule virtual portals, and prescribe remedies.'
                      : 'View appointment schedule, virtual telehealth coordinates, and prescriptions issued.'}
                  </p>
                </div>

                {appointments.length === 0 ? (
                  <div className="text-center py-12 bg-white/5 rounded-2xl border border-white/5">
                    <Clock className="w-12 h-12 mx-auto text-slate-400 mb-3 animate-pulse" />
                    <p className="text-xs text-slate-300">No active consultations found in your portal.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {appointments.map((appt) => (
                      <div 
                        key={appt.id} 
                        className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-4 relative overflow-hidden"
                      >
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className={`text-[10px] font-mono font-bold uppercase px-2.5 py-0.5 rounded-full border ${
                                appt.status === 'completed'
                                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                                  : appt.status === 'accepted'
                                  ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                                  : appt.status === 'rejected'
                                  ? 'bg-red-500/10 text-red-400 border-red-500/20'
                                  : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                              }`}>
                                {appt.status}
                              </span>
                              <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded ${
                                appt.paymentStatus === 'paid'
                                  ? 'bg-emerald-500/20 text-emerald-300'
                                  : 'bg-slate-500/20 text-slate-300'
                              }`}>
                                {appt.paymentStatus}
                              </span>
                            </div>
                            <h4 className="font-serif text-base font-bold text-white pt-1">
                              {profile.role === 'doctor' ? `Patient: ${appt.userName}` : `Practitioner: ${appt.doctorName}`}
                            </h4>
                            <p className="text-xs text-emerald-400 font-semibold">{appt.specialty}</p>
                          </div>

                          <div className="text-right md:text-right space-y-1">
                            <div className="text-xs text-white font-semibold flex items-center md:justify-end gap-1.5">
                              <Calendar className="w-3.5 h-3.5 text-gold" />
                              {appt.date}
                            </div>
                            <div className="text-xs text-slate-300 font-mono flex items-center md:justify-end gap-1.5">
                              <Clock className="w-3.5 h-3.5 text-gold" />
                              {appt.time}
                            </div>
                          </div>
                        </div>

                        {/* Prescriptions or Meeting Links */}
                        {(appt.meetingLink || appt.prescription) && (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-3 border-t border-white/5">
                            {appt.meetingLink && (
                              <div className="p-3 rounded-xl bg-blue-500/5 border border-blue-500/20 text-xs">
                                <p className="text-[10px] text-blue-300 font-bold uppercase flex items-center gap-1.5">
                                  <Video className="w-3.5 h-3.5" /> Virtual Telehealth Link
                                </p>
                                <a 
                                  href={appt.meetingLink}
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-blue-400 hover:underline flex items-center gap-1 mt-1 font-mono font-semibold"
                                >
                                  Join Video Call <ExternalLink className="w-3 h-3" />
                                </a>
                              </div>
                            )}
                            {appt.prescription && (
                              <div className="p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/20 text-xs">
                                <p className="text-[10px] text-emerald-300 font-bold uppercase flex items-center gap-1.5">
                                  <FileText className="w-3.5 h-3.5" /> Remediative Prescriptions
                                </p>
                                <p className="text-slate-300 mt-1 italic">
                                  "{appt.prescription}"
                                </p>
                              </div>
                            )}
                          </div>
                        )}

                        {/* DOCTOR ACTION PORTAL PANEL */}
                        {profile.role === 'doctor' && appt.status !== 'completed' && appt.status !== 'rejected' && (
                          <div className="pt-4 border-t border-white/5">
                            {selectedAppointmentId !== appt.id ? (
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => {
                                    setSelectedAppointmentId(appt.id);
                                    setMeetingLink(appt.meetingLink || '');
                                    setPrescription(appt.prescription || '');
                                  }}
                                  className="px-4 py-2 bg-gold hover:bg-amber-400 text-[#050B18] font-bold rounded-xl text-xs uppercase cursor-pointer"
                                >
                                  Manage Appointment
                                </button>
                                {appt.status === 'pending' && (
                                  <>
                                    <button
                                      onClick={() => handleUpdateStatus(appt.id, 'accepted')}
                                      className="px-4 py-2 bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 border border-blue-500/20 rounded-xl text-xs font-bold transition-all cursor-pointer"
                                    >
                                      Accept
                                    </button>
                                    <button
                                      onClick={() => handleUpdateStatus(appt.id, 'rejected')}
                                      className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-300 border border-red-500/20 rounded-xl text-xs font-bold transition-all cursor-pointer"
                                    >
                                      Reject
                                    </button>
                                  </>
                                )}
                              </div>
                            ) : (
                              <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-4">
                                <h5 className="font-serif text-sm font-bold text-white flex items-center gap-1.5">
                                  <Activity className="w-4 h-4 text-gold" />
                                  Cosmic Telehealth Configurations
                                </h5>
                                
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div className="space-y-1">
                                    <label className="block text-[10px] text-gray-300 font-semibold uppercase">Meeting Link (e.g. Google Meet)</label>
                                    <input 
                                      type="url"
                                      value={meetingLink}
                                      onChange={(e) => setMeetingLink(e.target.value)}
                                      placeholder="https://meet.google.com/xyz"
                                      className="w-full px-3 py-2.5 bg-white/5 rounded-lg border border-white/10 text-xs focus:outline-none focus:border-gold"
                                    />
                                  </div>

                                  <div className="space-y-1">
                                    <label className="block text-[10px] text-gray-300 font-semibold uppercase">Prescription Remedies (Rudraksha, Vastu remedies)</label>
                                    <input 
                                      type="text"
                                      value={prescription}
                                      onChange={(e) => setPrescription(e.target.value)}
                                      placeholder="e.g. Sleep with head South; wear 5-Mukhi Rudraksha."
                                      className="w-full px-3 py-2.5 bg-white/5 rounded-lg border border-white/10 text-xs focus:outline-none focus:border-gold"
                                    />
                                  </div>
                                </div>

                                <div className="flex gap-2 pt-2">
                                  <button
                                    onClick={() => handleUpdateStatus(appt.id, 'completed')}
                                    disabled={actionLoading}
                                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-lg text-xs uppercase cursor-pointer disabled:opacity-50"
                                  >
                                    Mark as Completed
                                  </button>
                                  <button
                                    onClick={() => handleUpdateStatus(appt.id, 'accepted')}
                                    disabled={actionLoading}
                                    className="px-4 py-2 bg-blue-700 hover:bg-blue-600 text-white font-bold rounded-lg text-xs uppercase cursor-pointer disabled:opacity-50"
                                  >
                                    Update Details Only
                                  </button>
                                  <button
                                    onClick={() => setSelectedAppointmentId(null)}
                                    className="px-4 py-2 bg-white/5 hover:bg-white/10 text-slate-300 rounded-lg text-xs font-bold cursor-pointer"
                                  >
                                    Back
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        )}

                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* SUB-TAB: ORDER HISTORY */}
            {activeSubTab === 'orders' && (
              <div className="space-y-6">
                <div className="border-b border-white/10 pb-4">
                  <h3 className="font-serif text-xl font-bold text-white flex items-center gap-2">
                    <ShoppingBag className="w-5 h-5 text-gold" />
                    Secure Purchase Invoices
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Receipts and delivery logs for consecrated Rudrakshas, planetary yantras, and digital reports.
                  </p>
                </div>

                {orders.length === 0 ? (
                  <div className="text-center py-12 bg-white/5 rounded-2xl border border-white/5">
                    <ShoppingBag className="w-12 h-12 mx-auto text-slate-400 mb-3 animate-pulse" />
                    <p className="text-xs text-slate-300">No physical or digital purchases registered.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {orders.map((order) => (
                      <div 
                        key={order.id} 
                        className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-4"
                      >
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div>
                            <p className="text-[10px] font-mono text-gold uppercase font-bold">Order ID: {order.id}</p>
                            <p className="text-xs text-gray-400 mt-1">Placed: {new Date(order.createdAt).toLocaleString()}</p>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className={`text-[10px] font-mono font-bold uppercase px-2.5 py-0.5 rounded-full border ${
                              order.status === 'delivered'
                                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                                : order.status === 'shipped'
                                ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                                : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                            }`}>
                              {order.status}
                            </span>
                            <span className="text-sm font-bold text-white">
                              Total: ₹{order.total.toLocaleString()}
                            </span>
                          </div>
                        </div>

                        {/* Order Items */}
                        <div className="divide-y divide-white/5 bg-white/5 rounded-xl border border-white/5 overflow-hidden">
                          {order.items.map((item, idx) => (
                            <div key={idx} className="flex items-center justify-between p-3 gap-3 text-xs">
                              <div className="flex items-center gap-3">
                                {item.imageUrl && (
                                  <img 
                                    src={item.imageUrl} 
                                    alt={item.name} 
                                    className="w-10 h-10 object-cover rounded-lg border border-white/10"
                                    referrerPolicy="no-referrer"
                                  />
                                )}
                                <div>
                                  <p className="font-semibold text-white">{item.name}</p>
                                  <p className="text-[10px] text-slate-400">Qty: {item.quantity}</p>
                                </div>
                              </div>
                              <p className="font-semibold text-slate-300">₹{(item.price * item.quantity).toLocaleString()}</p>
                            </div>
                          ))}
                        </div>

                        {order.address && (
                          <div className="text-xs text-slate-300 p-3 bg-white/5 rounded-xl border border-white/5">
                            <p className="text-[10px] text-gray-400 uppercase font-bold">Delivery Address</p>
                            <p className="mt-1">{order.address}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* SUB-TAB: COURSE ENROLLMENTS */}
            {activeSubTab === 'courses' && (
              <div className="space-y-6">
                <div className="border-b border-white/10 pb-4">
                  <h3 className="font-serif text-xl font-bold text-white flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-gold" />
                    Planetary Academy Portal
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Active certificate masterclasses with Dr. Nabin K. Choudhary.
                  </p>
                </div>

                {profile.role === 'student' || profile.role === 'admin' ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-5 rounded-2xl bg-gradient-to-tr from-white/10 to-white/5 border border-white/10 space-y-4">
                      <div className="flex justify-between items-start">
                        <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full uppercase font-bold">
                          In Progress
                        </span>
                        <span className="text-xs text-gold font-bold">60% Complete</span>
                      </div>
                      <div>
                        <h4 className="font-serif text-base font-bold text-white">Chaldean Numerology Masterclass</h4>
                        <p className="text-xs text-slate-300 mt-1">Instructor: {FOUNDER_INFO.name}</p>
                      </div>
                      <div className="w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                        <div className="bg-gold h-full rounded-full" style={{ width: '60%' }}></div>
                      </div>
                      <button
                        onClick={() => {
                          const courseBtn = document.getElementById('nav-courses');
                          if (courseBtn) courseBtn.click();
                        }}
                        className="w-full py-2 bg-white/5 hover:bg-white/10 text-slate-200 hover:text-white rounded-xl text-xs font-bold transition-all cursor-pointer text-center block"
                      >
                        Resume Lectures
                      </button>
                    </div>

                    <div className="p-5 rounded-2xl bg-gradient-to-tr from-white/10 to-white/5 border border-white/10 space-y-4">
                      <div className="flex justify-between items-start">
                        <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full uppercase font-bold">
                          In Progress
                        </span>
                        <span className="text-xs text-gold font-bold">15% Complete</span>
                      </div>
                      <div>
                        <h4 className="font-serif text-base font-bold text-white">Medical Vastu & Sacred Geometries</h4>
                        <p className="text-xs text-slate-300 mt-1">Instructor: {FOUNDER_INFO.name}</p>
                      </div>
                      <div className="w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                        <div className="bg-gold h-full rounded-full" style={{ width: '15%' }}></div>
                      </div>
                      <button
                        onClick={() => {
                          const courseBtn = document.getElementById('nav-courses');
                          if (courseBtn) courseBtn.click();
                        }}
                        className="w-full py-2 bg-white/5 hover:bg-white/10 text-slate-200 hover:text-white rounded-xl text-xs font-bold transition-all cursor-pointer text-center block"
                      >
                        Resume Lectures
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 bg-white/5 rounded-2xl border border-white/5 space-y-4">
                    <BookOpen className="w-12 h-12 mx-auto text-slate-400 animate-pulse" />
                    <div className="space-y-1">
                      <p className="text-xs text-slate-300">You are not currently enrolled in any master courses.</p>
                      <p className="text-[10px] text-slate-400">To unlock certificates, change your role simulation to "Student" or enroll in courses directly.</p>
                    </div>
                    <button
                      onClick={() => {
                        const courseBtn = document.getElementById('nav-courses');
                        if (courseBtn) courseBtn.click();
                      }}
                      className="px-5 py-2.5 bg-gold hover:bg-amber-400 text-[#050B18] font-bold rounded-xl text-xs uppercase cursor-pointer"
                    >
                      Browse Master Courses
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* SUB-TAB: MY WISHLIST */}
            {activeSubTab === 'wishlist' && (
              <div className="space-y-6">
                <div className="border-b border-white/10 pb-4">
                  <h3 className="font-serif text-xl font-bold text-white flex items-center gap-2">
                    <Heart className="w-5 h-5 text-red-400" />
                    My Sacred Wishlist
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Your collection of persistent, curated cosmic remedies and expert bookstore textbooks.
                  </p>
                </div>

                {wishlist.length === 0 ? (
                  <div className="text-center py-12 bg-white/5 rounded-2xl border border-white/5 space-y-4">
                    <Heart className="w-12 h-12 mx-auto text-slate-500 animate-pulse" />
                    <div className="space-y-1">
                      <p className="text-xs text-slate-300">Your wishlist is currently empty.</p>
                      <p className="text-[10px] text-slate-400">Add genuine altitude Nepal Rudraksha beads or Sri Yantras from our Shop to save them here.</p>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {wishlist.map((item) => (
                      <div 
                        key={item.productId}
                        className="p-4 rounded-2xl bg-gradient-to-tr from-white/10 to-white/5 border border-white/10 flex gap-4 items-center justify-between"
                      >
                        <div className="flex gap-4 items-center">
                          <div className="w-16 h-16 bg-slate-950 rounded-xl overflow-hidden shrink-0">
                            <img 
                              src={item.imageUrl} 
                              alt={item.name} 
                              className="w-full h-full object-cover" 
                              referrerPolicy="no-referrer"
                            />
                          </div>
                          <div>
                            <span className="text-[9px] bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-0.5 rounded uppercase font-mono tracking-wider">
                              {item.category}
                            </span>
                            <h4 className="font-serif text-sm font-bold text-white line-clamp-1 mt-1">{item.name}</h4>
                            <p className="text-xs text-gold font-bold">₹{item.price}</p>
                          </div>
                        </div>

                        <div className="flex flex-col gap-2 shrink-0">
                          <button
                            onClick={async () => {
                              try {
                                await removeFromWishlist(currentUser.uid, item.productId);
                                setWishlist(prev => prev.filter(w => w.productId !== item.productId));
                                setSuccessMsg(`"${item.name}" removed from wishlist.`);
                                setTimeout(() => setSuccessMsg(''), 4000);
                              } catch (err: any) {
                                setErrorMsg(err.message || 'Failed to remove from wishlist.');
                              }
                            }}
                            className="px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded-xl text-[10px] font-bold transition-all cursor-pointer text-center"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

          </div>
        </div>

      </div>

    </div>
  );
}

const FOUNDER_INFO = {
  name: "Dr. Nabin K. Choudhary"
};
