export type UserRole = 'user' | 'doctor' | 'student' | 'admin';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  phone?: string;
  role: UserRole;
  createdAt: string;
  birthDate?: string;
  birthTime?: string;
  birthPlace?: string;
  vastuPreferences?: string;
}

export interface DoctorProfile {
  id: string; // matches uid
  name: string;
  email: string;
  phone: string;
  degree: string;
  specialty: string;
  fees: number;
  bio: string;
  availability: string[]; // e.g. ["Monday 10:00 - 14:00", "Wednesday 15:00 - 18:00"]
  approved: boolean;
  rating: number;
}

export interface CourseVideo {
  id: string;
  title: string;
  duration: string;
  videoUrl: string;
}

export interface CoursePdf {
  id: string;
  title: string;
  pdfUrl: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  answerIndex: number;
}

export interface Course {
  id: string;
  title: string;
  category: 'astrology' | 'numerology' | 'vastu' | 'name_correction' | 'mental_health';
  description: string;
  price: number;
  duration: string;
  instructor: string;
  rating: number;
  videos: CourseVideo[];
  pdfs: CoursePdf[];
  quizzes: QuizQuestion[];
  studentCount: number;
  imageUrl: string;
}

export interface Appointment {
  id: string;
  userId: string;
  userName: string;
  userPhone?: string;
  doctorId: string;
  doctorName: string;
  specialty: string;
  date: string;
  time: string;
  status: 'pending' | 'accepted' | 'rejected' | 'completed';
  paymentStatus: 'pending' | 'paid';
  meetingLink?: string;
  prescription?: string;
  createdAt: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'rudraksha' | 'yantra' | 'gemstone' | 'book' | 'digital_report';
  imageUrl: string;
  stock: number;
  rating: number;
  reviews: {
    userName: string;
    rating: number;
    comment: string;
    date: string;
  }[];
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface WishlistItem {
  productId: string;
  name: string;
  price: number;
  category: string;
  imageUrl: string;
  addedAt: string;
}

export interface Order {
  id: string;
  userId: string;
  userName: string;
  items: {
    productId: string;
    name: string;
    price: number;
    quantity: number;
    category: string;
    imageUrl: string;
  }[];
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  paymentId: string;
  createdAt: string;
  couponCode?: string;
  address?: string;
}

export interface BlogComment {
  id: string;
  userName: string;
  comment: string;
  date: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  imageUrl: string;
  author: string;
  date: string;
  comments: BlogComment[];
  readTime: string;
}
